//
//  MHorseChaseState.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 21..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MState.h"

@interface MHorseChaseState : MState 
{
	int m_iCount;
}

@end
