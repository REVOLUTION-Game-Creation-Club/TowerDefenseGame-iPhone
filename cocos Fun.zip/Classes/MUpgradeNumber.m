//
//  MUpgradeNumber.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 1..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MUpgradeNumber.h"


@implementation MUpgradeNumber

-(id)init
{
	if( (self=[super init] )) 
	{		
		for(int i = 0; i < 10; i++)
		{
			m_sprite[i] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(19*i,0,19,19)];
			m_sprite[i].position = ccp(0,0);
			[self addChild:m_sprite[i] z:0 tag:0];			
		}
		[self setNumber:0];
	}
	
	return self;
}

-(void)setNumber:(int)n
{
	for(int i = 0; i <10; i++)
	{
		if(i == n)
		{
			m_sprite[i].visible = TRUE;
		}
		else 
		{
			m_sprite[i].visible = FALSE;
		}

	}
}
@end
