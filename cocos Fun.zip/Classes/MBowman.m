//
//  Bowman.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 11..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MBowman.h"
#import "MStateMachine.h"
#import "MBowAttackState.h"
#import "MBowWaitState.h"
#import "MBowProduceState.h"
#import "MBowMoveState.h"

@implementation MBowman

-(id) init
{
	if( (self=[super init] )) 
	{
		m_iHealthPoint = 15; // 체력
		m_iHPMax = 15;

		m_iDepencePoint = 1; // 방어력
		m_iAttackPoint = 3; // 공격력
		m_fAttackSpeed = 1;	// 공격속도
		m_iPrice = 150; // 생산가격
		m_fSight = 200;
		
		m_spriteWait[0] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(0,0,32,32)];
		[self addChild:m_spriteWait[0] z:0 tag:0];
		m_spriteWait[1] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(32,0,32,32)];
		[self addChild:m_spriteWait[1] z:0 tag:0];
		m_spriteWait[2] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(64,0,32,32)];
		[self addChild:m_spriteWait[2] z:0 tag:0];
		m_spriteWait[3] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(96,0,32,32)];
		[self addChild:m_spriteWait[3] z:0 tag:0];
		m_spriteWait[4] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(128,0,32,32)];
		[self addChild:m_spriteWait[4] z:0 tag:0];
		
		m_spriteMove[0] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(0,32,32,32)];
		[self addChild:m_spriteMove[0] z:0 tag:0];
		m_spriteMove[1] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(32,32,32,32)];
		[self addChild:m_spriteMove[1] z:0 tag:0];
		m_spriteMove[2] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(64,32,32,32)];
		[self addChild:m_spriteMove[2] z:0 tag:0];
		m_spriteMove[3] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(96,32,32,32)];
		[self addChild:m_spriteMove[3] z:0 tag:0];
		
		m_spriteAttack[0] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(0,64,32,32)];
		[self addChild:m_spriteAttack[0] z:0 tag:0];
		m_spriteAttack[1] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(32,64,32,32)];
		[self addChild:m_spriteAttack[1] z:0 tag:0];
		m_spriteAttack[2] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(64,64,32,32)];
		[self addChild:m_spriteAttack[2] z:0 tag:0];
		m_spriteAttack[3] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(96,64,32,32)];
		[self addChild:m_spriteAttack[3] z:0 tag:0];
		m_spriteAttack[4] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(128,64,32,32)];
		[self addChild:m_spriteAttack[4] z:0 tag:0];
		
		m_spriteDeath[0] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(0,96,32,32)];
		[self addChild:m_spriteDeath[0] z:0 tag:0];
		m_spriteDeath[1] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(32,96,32,32)];
		[self addChild:m_spriteDeath[1] z:0 tag:0];
		m_spriteDeath[2] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(64,96,32,32)];
		[self addChild:m_spriteDeath[2] z:0 tag:0];
		m_spriteDeath[3] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(96,96,32,32)];
		[self addChild:m_spriteDeath[3] z:0 tag:0];
		
		[self unvisibleAll];
		
		for(int i = 0; i <21; i++)
		{
			m_hpSprite[i] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(0,128+2*i,20,2)];
			[m_hpSprite[i] setPosition:CGPointMake(0, 20)];
			[self addChild:m_hpSprite[i] z:1 tag:0];
			m_hpSprite[i].visible = FALSE;
		}
		
		m_hpSprite[0].visible = TRUE;
		
		m_stateMachine = [[MStateMachine alloc] init];
		[m_stateMachine setOwner:self];
		m_moveState = [[MBowMoveState alloc] init];
		m_waitState = [[MBowWaitState alloc] init];
		m_attackState = [[MBowAttackState alloc] init];
		m_produceState = [[MBowProduceState alloc] init];
		[m_produceState Enter:self];
		[m_stateMachine setCurrentState:m_produceState];
		
	}
	return self;
}

-(void) update
{	
	[m_stateMachine update];
}

- (void) dealloc
{
	[m_attackState release];
	[m_waitState release];
	[m_stateMachine release];
	
	[super dealloc];
}

-(void) changeState:(MState*)new_state
{
	[m_stateMachine changeState:new_state];
}

-(BOOL) isInRadius:(CGPoint)pt
{
	float dx = pt.x - self.position.x;
	float dy = pt.y - self.position.y;
	
	if(sqrt(dx*dx+dy*dy) < m_fRadius)
		return TRUE;
	
	return FALSE;
}
-(BOOL) isInSight:(CGPoint)pt
{
	float dx = pt.x - self.position.x;
	float dy = pt.y - self.position.y;
	
	if(sqrt(dx*dx+dy*dy) < m_fSight)
		return TRUE;
	
	return FALSE;
}

-(void)setTargetUnit:(MUnit*)enemy
{
	m_target = enemy;
}

- (MUnit*)getTargetUnit
{
	return m_target;
}

- (void)attack
{
	[self changeState:m_attackState];
}
-(void) setTarget:(CGPoint)pt
{
	m_ptTarget = pt;
}

-(CGPoint) getTarget
{
	return m_ptTarget;
}

-(void) WaitAnimation
{
	static int count = 0;
	
	for(int i = 0; i <5; i++)
	{
		if(i == count)
		{
			m_spriteWait[i].visible = TRUE;
		}
		else 
		{
			m_spriteWait[i].visible = FALSE;
		}
	}
	
	count++;
	if(count == 5)
		count = 0;
}

-(void) MoveAnimation
{
	static int count = 0;
	
	for(int i = 0; i <4; i++)
	{
		if(i == count)
		{
			m_spriteMove[i].visible = TRUE;
		}
		else
		{
			m_spriteMove[i].visible = FALSE;
		}
	}
	
	count++;
	if(count == 4)
		count = 0;
}

-(void) AttackAnimation
{
	static int count = 0;
	
	for(int i = 0; i <5; i++)
	{
		if(i == count)
		{
			m_spriteAttack[i].visible = TRUE;
		}
		else 
		{
			m_spriteAttack[i].visible = FALSE;
		}
	}
	
	count++;
	if(count == 5)
		count = 0;
}

-(void) DeathAnimation
{
	static int count = 0;
	
	for(int i = 0; i <4; i++)
	{
		if(i == count)
		{
			m_spriteDeath[i].visible = TRUE;
		}
		else 
		{
			m_spriteDeath[i].visible = FALSE;
		}
	}
	
	count++;
	if(count == 4)
		count = 0;
}


-(void) unvisibleAll
{
	for(int i = 0; i <5; i++)
	{
		m_spriteWait[i].visible = FALSE;
	}
	for(int i = 0; i <4; i++)
	{
		m_spriteMove[i].visible = FALSE;
	}
	for(int i = 0; i <5; i++)
	{
		m_spriteAttack[i].visible = FALSE;
	}
	for(int i = 0; i <4; i++)
	{
		m_spriteDeath[i].visible = FALSE;
	}
}

-(void) dead
{
	for(int i = 0; i <5; i++)
	{
		[self removeChild:m_spriteWait[i] cleanup:YES];
	}
	for(int i = 0; i <4; i++)
	{
		[self removeChild:m_spriteMove[i] cleanup:YES];
	}
	for(int i = 0; i <5; i++)
	{
		[self removeChild:m_spriteAttack[i] cleanup:YES];
	}
	for(int i = 0; i <4; i++)
	{
		[self removeChild:m_spriteDeath[i] cleanup:YES];
	}
}

-(void) setFlipX:(BOOL)b
{
	for(int i = 0; i <5; i++)
	{
		[m_spriteWait[i] setFlipX:b];
	}
	for(int i = 0; i <4; i++)
	{
		[m_spriteMove[i] setFlipX:b];
	}
	for(int i = 0; i <5; i++)
	{
		[m_spriteAttack[i] setFlipX:b];
	}
	for(int i = 0; i <4; i++)
	{
		[m_spriteDeath[i] setFlipX:b];
	}
}


-(void) changeWaitState
{
	[m_stateMachine changeState:m_waitState];
}

-(NSString*) name
{
	return [m_stateMachine name];
}

-(void) suffer:(int)hp
{
	m_iHealthPoint--;
	int h = m_iHealthPoint*20.0/(float)m_iHPMax;
	
	for(int i = 1; i < 21; i++)
	{
		if( i == h)
		{
			m_hpSprite[20-i].visible = TRUE;
		}
		else 
		{
			m_hpSprite[20-i].visible = FALSE;
		}
	}
}

-(void) wait
{
	[self changeState:m_waitState];
}

-(void) go
{
	if([self name] == @"MBowProduceState")
		return;
	
	[self changeState:m_moveState];
}

-(void) setBackground:(MBackground*)bg
{
	m_background = bg;
}

-(MBackground*)getBackground
{
	return m_background;
}

-(void)setLeftSlot:(MLeftSlot*)slot
{
	m_leftSlot = slot;
}

-(MLeftSlot*)getLeftSlot
{
	return m_leftSlot;
}

@end
