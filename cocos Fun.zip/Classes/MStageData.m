//
//  MStageData.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 28..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MStageData.h"


@implementation MStageData

@synthesize m_iStage1Clear;
@synthesize m_iStage2Clear;
@synthesize m_iStage3Clear;
@synthesize m_iStage4Clear;
@synthesize m_iStage5Clear;
@synthesize m_iStage6Clear;
@synthesize m_iStage7Clear;

@synthesize m_iStageNum;

static MStageData* g_sharedStageData = nil;

+ (MStageData*)sharedStageData 
{
	if (!g_sharedStageData)
		g_sharedStageData = [[MStageData alloc] init];
	
	return g_sharedStageData;
}

-(id)init
{
	if((self = [super init]))
	{
		m_iStage1Clear = FALSE;
		m_iStage2Clear = FALSE;
		m_iStage3Clear = FALSE;
		m_iStage4Clear = FALSE;
		m_iStage5Clear = FALSE;
		m_iStage6Clear = FALSE;
		m_iStage7Clear = FALSE;
			
		m_iStageNum = 0;
		//self = [NSKeyedUnarchiver unarchiveObjectWithData:freezeDried];
	}
	
	return self;
}

@end
