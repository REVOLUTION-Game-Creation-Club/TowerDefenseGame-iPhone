//
//  Boss4.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 19..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Boss4.h"
#import "MStateMachine.h"
#import "Boss4MoveState.h"
#import "Boss4AttackState.h"
//#import "Boss4WaitState.h"
#import "Boss4ChaseState.h"

@implementation Boss4

-(id) init
{
	if( (self=[super init] )) 
	{
		m_bAlive = FALSE;
		
		m_fRadius = 16.0;
		m_fSight = 100.0;
		
		m_iHealthPoint = 12; // 체력
		m_iHPMax = 12;
		
		m_iDepencePoint = 1; // 방어력
		m_iAttackPoint = 5; // 공격력
		m_fAttackSpeed = 1;	// 공격속도
		m_iPrice = 100; // 생산가격
		
		m_spriteWait[0] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(0,0,64,64)];
		[self addChild:m_spriteWait[0] z:0 tag:0];
		m_spriteWait[1] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(64,0,64,64)];
		[self addChild:m_spriteWait[1] z:0 tag:0];
		m_spriteWait[2] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(128,0,64,64)];
		[self addChild:m_spriteWait[2] z:0 tag:0];
		
		m_spriteMove[0] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(0,64,64,64)];
		[self addChild:m_spriteMove[0] z:0 tag:0];
		m_spriteMove[1] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(64,64,64,64)];
		[self addChild:m_spriteMove[1] z:0 tag:0];
		m_spriteMove[2] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(128,64,64,64)];
		[self addChild:m_spriteMove[2] z:0 tag:0];
		m_spriteMove[3] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(192,64,64,64)];
		[self addChild:m_spriteMove[3] z:0 tag:0];
		m_spriteMove[4] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(256,64,64,64)];
		[self addChild:m_spriteMove[4] z:0 tag:0];
		m_spriteMove[5] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(320,64,64,64)];
		[self addChild:m_spriteMove[5] z:0 tag:0];
		m_spriteMove[6] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(384,64,64,64)];
		[self addChild:m_spriteMove[6] z:0 tag:0];
		m_spriteMove[7] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(448,64,64,64)];
		[self addChild:m_spriteMove[7] z:0 tag:0];
		
		m_spriteAttack[0] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(0,128,64,64)];
		[self addChild:m_spriteAttack[0] z:0 tag:0];
		m_spriteAttack[1] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(64,128,64,64)];
		[self addChild:m_spriteAttack[1] z:0 tag:0];
		m_spriteAttack[2] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(128,128,64,64)];
		[self addChild:m_spriteAttack[2] z:0 tag:0];
		
		m_spriteDeath[0] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(0,192,64,64)];
		[self addChild:m_spriteDeath[0] z:0 tag:0];
		m_spriteDeath[1] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(64,192,64,64)];
		[self addChild:m_spriteDeath[1] z:0 tag:0];
		m_spriteDeath[2] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(128,192,64,64)];
		[self addChild:m_spriteDeath[2] z:0 tag:0];
		m_spriteDeath[3] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(192,192,64,64)];
		[self addChild:m_spriteDeath[3] z:0 tag:0];
		
		
		[self unvisibleAll];
		
		for(int i = 0; i <21; i++)
		{
			m_hpSprite[i] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(0,96+2*i,20,2)];
			[m_hpSprite[i] setPosition:CGPointMake(0, 20)];
			[self addChild:m_hpSprite[i] z:1 tag:0];
			m_hpSprite[i].visible = FALSE;
		}
		
		m_hpSprite[0].visible = TRUE;
		
		m_stateMachine = [[MStateMachine alloc] init];
		[m_stateMachine setOwner:self];
		m_moveState = [[Boss4MoveState alloc] init];
		m_attackState = [[Boss4AttackState alloc] init];
//		m_waitState = [[Boss4WaitState alloc] init];
		m_chaseState = [[Boss4ChaseState alloc] init];
		[m_moveState Enter:self];
		[m_stateMachine setCurrentState:m_moveState];
	}
	return self;
}

-(void) update
{	
	[m_stateMachine update];
}

-(void) unvisibleAll
{
	for(int i = 0; i <3; i++)
	{
		m_spriteWait[i].visible = FALSE;
	}
	for(int i = 0; i <8; i++)
	{
		m_spriteMove[i].visible = FALSE;
	}
	for(int i = 0; i <3; i++)
	{
		m_spriteAttack[i].visible = FALSE;
	}
	for(int i = 0; i <4; i++)
	{
		m_spriteDeath[i].visible = FALSE;
	}
}

- (void) dealloc
{
	[m_moveState release];
	[m_attackState release];
	[m_waitState release];
	[m_chaseState release];
	[m_stateMachine release];
	
	[super dealloc];
}

-(void) changeState:(MState*)new_state
{
	[m_stateMachine changeState:new_state];
}

-(BOOL) isInRadius:(CGPoint)pt
{
	float dx = pt.x - self.position.x;
	float dy = pt.y - self.position.y;
	
	if(sqrt(dx*dx+dy*dy) < m_fRadius)
		return TRUE;
	
	return FALSE;
}


-(BOOL) isInSight:(CGPoint)pt
{
	float dx = pt.x - self.position.x;
	float dy = pt.y - self.position.y;
	
	if(sqrt(dx*dx+dy*dy) < m_fSight)
		return TRUE;
	
	return FALSE;
}

-(void) attack
{
	if([self name] == @"MWalkProduceState")
		return;
	if([self name] == @"MWalkAttackState")
		return;
	
	[self changeState:m_attackState];
}

-(void) chase:(CGPoint)pt
{
	if([self name] == @"MWalkProduceState")
		return;
	
	m_ptChasePoint = pt;
	[self changeState:m_chaseState];
}

-(void) suffer:(int)hp;
{
	m_iHealthPoint--;
	int h = m_iHealthPoint*20.0/(float)m_iHPMax;
	
	for(int i = 1; i < 21; i++)
	{
		if( i == h)
		{
			m_hpSprite[20-i].visible = TRUE;
		}
		else 
		{
			m_hpSprite[20-i].visible = FALSE;
		}
	}
}

-(CGPoint) getFleePoint
{
	return m_ptFleePoint;
}

-(CGPoint) getChasePoint
{
	return m_ptChasePoint;
}

-(void) setDeath:(BOOL)bDeath
{
	m_bDeath = bDeath;
}

-(BOOL) getDeath
{
	return m_bDeath;
}

/*
 -(void) setPosition:(CGPoint)pt
 {
 for(int i = 0; i < 2; i++)
 {
 m_sprite[i].position = pt;
 }	
 }
 */

-(void) changeWaitState
{
//	[m_stateMachine changeState:m_waitState];
}

-(void) WaitAnimation
{
	static int count = 0;
	
	for(int i = 0; i <3; i++)
	{
		if(i == count)
		{
			m_spriteWait[i].visible = TRUE;
		}
		else 
		{
			m_spriteWait[i].visible = FALSE;
		}
	}
	
	count++;
	if(count == 3)
		count = 0;
}

-(void) MoveAnimation
{
	static int count = 0;
	
	for(int i = 0; i <8; i++)
	{
		if(i == count)
		{
			m_spriteMove[i].visible = TRUE;
		}
		else 
		{
			m_spriteMove[i].visible = FALSE;
		}
	}
	
	count++;
	if(count == 8)
		count = 0;
}

-(void) AttackAnimation
{
	static int count = 0;
	
	for(int i = 0; i <3; i++)
	{
		if(i == count)
		{
			m_spriteAttack[i].visible = TRUE;
		}
		else 
		{
			m_spriteAttack[i].visible = FALSE;
		}
	}
	
	count++;
	if(count == 3)
		count = 0;
}

-(void) DeathAnimation
{
	static int count = 0;
	
	for(int i = 0; i <4; i++)
	{
		if(i == count)
		{
			m_spriteDeath[i].visible = TRUE;
		}
		else 
		{
			m_spriteDeath[i].visible = FALSE;
		}
	}
	
	count++;
	if(count == 4)
		count = 0;
}

-(void) dead
{
	for(int i = 0; i <3; i++)
	{
		[self removeChild:m_spriteWait[i] cleanup:YES];
	}
	for(int i = 0; i <8; i++)
	{
		[self removeChild:m_spriteMove[i] cleanup:YES];
	}
	for(int i = 0; i <3; i++)
	{
		[self removeChild:m_spriteAttack[i] cleanup:YES];
	}
	for(int i = 0; i <4; i++)
	{
		[self removeChild:m_spriteDeath[i] cleanup:YES];
	}
}

-(void) setFlipX:(BOOL)b
{
	for(int i = 0; i <3; i++)
	{
		[m_spriteWait[i] setFlipX:b];
	}
	for(int i = 0; i <8; i++)
	{
		[m_spriteMove[i] setFlipX:b];
	}
	for(int i = 0; i <3; i++)
	{
		[m_spriteAttack[i] setFlipX:b];
	}
	for(int i = 0; i <4; i++)
	{
		[m_spriteDeath[i] setFlipX:b];
	}
}

-(void) wait
{
	if([self name] == @"MWalkProduceState")
		return;
	
//	[self changeState:m_waitState];
}

-(void) go
{
	if([self name] == @"MWalkProduceState")
		return;
	
	[self changeState:m_moveState];
}

-(NSString*) name
{
	return [m_stateMachine name];
}

-(void) setTargetUnit:(MUnit*)pt
{
	m_target = pt;
}

-(MUnit*) getTargetUnit
{
	return m_target;
}

-(void) setAlive:(BOOL)b
{
	m_bAlive = b;
}

-(BOOL) isAlive
{
	return m_bAlive;
}

@end
