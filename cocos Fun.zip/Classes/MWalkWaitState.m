//
//  MWaitState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 14..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MWalkWaitState.h"
#import "cocos2d.h"
#import "MWalkman.h"
#import "MBackground.h"

@implementation MWalkWaitState

- (void)Enter:(id)owner
{
	m_iCount = 0;
	MWalkman *walkman = owner;
	switch ([walkman getFormation]) 
	{
		case STYLE_NO:
			x = 100;
			y = rand()%220+50;
			break;
		case STYLE_1:
			x = rand()%40+160;
			y = rand()%200+60;
			break;
		case STYLE_2:
			x = rand()%80+160;
			y = rand()%40+140;
			break;
		case STYLE_3:
			x = rand()%60+220;
			y = rand()%120+100;
			break;
		case STYLE_4:
			x = rand()%40+120;
			y = rand()%80+120;
			break;			
	}

	[walkman unvisibleAll];
}

- (void)Execute:(id)owner
{
	MWalkman *walkman = owner;
	if(m_iCount== 0)
	{
		[walkman WaitAnimation];
	}
	m_iCount++;

	if(m_iCount == 30)
		m_iCount = 0;

	//
	
	MWalkman* sprite = owner;
	
	if(( sprite.position.x > x-1)&&(sprite.position.y < y+1)&&
	   ( sprite.position.x < x+1)&&(sprite.position.y > y-1))
	{
		[sprite setFlipX:FALSE];
		[sprite setRotation:0];
		[sprite setPosition:CGPointMake(x, y)];
	}
	
	else 
	{
		float dx = x - sprite.position.x;
		float dy = y - sprite.position.y;
		
		dx=dx/sqrt(dx*dx+dy*dy);
		dy=dy/sqrt(dx*dx+dy*dy);
		if(dx <0)
		{
			[sprite setFlipX:TRUE];
		}
		
		[sprite setRotation:atan(dy/dx)*-180/3.14];
		[sprite setPosition:CGPointMake(sprite.position.x+dx, sprite.position.y+dy)];
	}
}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"MWalkWaitState";
}

@end
