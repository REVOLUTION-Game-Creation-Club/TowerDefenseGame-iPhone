//
//  Tank.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 11..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

//#import <Foundation/Foundation.h>
#import "cocos2d.h"
//@class MState;

@interface MUnit  : CCSpriteSheet//<CCTargetedTouchDelegate>
{
	int m_iHealthPoint; // 체력
	int m_iDepencePoint; // 방어력
	int	m_iAttackPoint; // 공격력
	int m_fAttackSpeed;	// 공격속도
	int m_iPrice; // 생산가격
	
	// 업그레이드 레벨
	int m_iHealthLevel;
	int m_iDepenceLevel;
	int m_iAttackLevel;
	int m_iAttackSpeedLevel;
	int m_iSpeedLevel;
	
	int m_iID;
	
	int m_formation;
}

//@property int m_iHealthPoint;
-(id) init;
-(void) setID:(int)id1;
-(int) getID;
-(void) setHP:(int)hp;
-(int) getHP;

-(void)setFormation:(int)type;
-(int)getFormation;
-(void) update;

-(BOOL) isInRadius:(CGPoint)pt;
-(BOOL) isInSight:(CGPoint)pt;

-(void) attack;
-(void) suffer:(int)hp;

-(void) dead;

-(void) go;
-(void) setTargetUnit:(MUnit*)pt;
-(void) chase:(CGPoint)pt;

//-(void) spriteWithFile:(NSString*)filename rect:(CGRect)rect index:(NSUInteger)i;
//-(void) setPosition:(CGPoint)pt;
//-(void) update;
//-(void) ChangeState:(MState*)new_state;
@end
