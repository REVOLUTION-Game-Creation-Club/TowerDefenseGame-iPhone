//
//  MStore.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 28..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MStore.h"
#import "Menu.h"
#import "MUserData.h"

@implementation MStore

-(id)init
{
	if((self=[super init]))
	{
//		CGSize s = [[CCDirector sharedDirector] winSize];
		// 파일이 있다면 열기를 시도한다.
		MUserData* ud = [MUserData sharedUserData];
		
		//		MUserData* ud = [MUserData sharedUserData];
		
		NSData *data1 = [[NSMutableData alloc] initWithContentsOfFile:[self dataFilePath]];
		NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:data1];
		ud.m_iBow1Level = [unarchiver decodeIntForKey:@"m_iBow1Level"];
		ud.m_iBow2Level = [unarchiver decodeIntForKey:@"m_iBow2Level"];
		ud.m_iBow3Level = [unarchiver decodeIntForKey:@"m_iBow3Level"];
		ud.m_iBow4Level = [unarchiver decodeIntForKey:@"m_iBow4Level"];
		ud.m_iBow5Level = [unarchiver decodeIntForKey:@"m_iBow5Level"];
		
		ud.m_iShield1Level = [unarchiver decodeIntForKey:@"m_iShield1Level"];
		ud.m_iShield2Level = [unarchiver decodeIntForKey:@"m_iShield2Level"];
		ud.m_iShield3Level = [unarchiver decodeIntForKey:@"m_iShield3Level"];
		ud.m_iShield4Level = [unarchiver decodeIntForKey:@"m_iShield4Level"];
		ud.m_iShield5Level = [unarchiver decodeIntForKey:@"m_iShield5Level"];

		ud.m_iSword1Level = [unarchiver decodeIntForKey:@"m_iSword1Level"];
		ud.m_iSword2Level = [unarchiver decodeIntForKey:@"m_iSword2Level"];
		ud.m_iSword3Level = [unarchiver decodeIntForKey:@"m_iSword3Level"];
		ud.m_iSword4Level = [unarchiver decodeIntForKey:@"m_iSword4Level"];
		ud.m_iSword5Level = [unarchiver decodeIntForKey:@"m_iSword5Level"];
		ud.m_iCastleLevel = [unarchiver decodeIntForKey:@"m_iCastleLevel"];
		ud.m_iIronNum = [unarchiver decodeIntForKey:@"m_iIronNum"];
		ud.m_iWoodNum = [unarchiver decodeIntForKey:@"m_iWoodNum"];

		ud.m_bWood1 = [unarchiver decodeBoolForKey:@"m_bWood1"];
		ud.m_bIron1 = [unarchiver decodeBoolForKey:@"m_bIron1"];
		ud.m_bIron2 = [unarchiver decodeBoolForKey:@"m_bIron2"];
		ud.m_bIron3 = [unarchiver decodeBoolForKey:@"m_bIron3"];
		
		ud.m_bWood1Sold = [unarchiver decodeBoolForKey:@"m_bWood1Sold"];
		ud.m_bIron1Sold = [unarchiver decodeBoolForKey:@"m_bIron1Sold"];
		ud.m_bIron2Sold = [unarchiver decodeBoolForKey:@"m_bIron2Sold"];
		ud.m_bIron3Sold = [unarchiver decodeBoolForKey:@"m_bIron3Sold"];
		
		ud.m_iSkill1Level = [unarchiver decodeIntForKey:@"m_iSkill1Level"];
		ud.m_iSkill2Level = [unarchiver decodeIntForKey:@"m_iSkill2Level"];
		ud.m_iSkill3Level = [unarchiver decodeIntForKey:@"m_iSkill3Level"];
		ud.m_iSkill4Level = [unarchiver decodeIntForKey:@"m_iSkill4Level"];
		ud.m_iSkill5Level = [unarchiver decodeIntForKey:@"m_iSkill5Level"];
		ud.m_iSkill6Level = [unarchiver decodeIntForKey:@"m_iSkill6Level"];
						
		ud.m_iQuickSlot1 = [unarchiver decodeIntForKey:@"m_iQuickSlot1"];
		ud.m_iQuickSlot2 = [unarchiver decodeIntForKey:@"m_iQuickSlot2"];
		ud.m_iQuickSlot3 = [unarchiver decodeIntForKey:@"m_iQuickSlot3"];
		
		ud.m_iQuickSlot1Num = [unarchiver decodeIntForKey:@"m_iQuickSlot1Num"];
		ud.m_iQuickSlot2Num = [unarchiver decodeIntForKey:@"m_iQuickSlot2Num"];
		ud.m_iQuickSlot3Num = [unarchiver decodeIntForKey:@"m_iQuickSlot3Num"];
		
		[unarchiver finishDecoding];
		
		[unarchiver release];
		[data1 release];
		
		CCSprite* storeBG = [CCSprite spriteWithFile:@"store.png" rect:CGRectMake(0,0,480,320)];
		storeBG.position = ccp(480/2,320/2);
		[self addChild:storeBG z:0];
		
		CCSprite* bowButton = [CCSprite spriteWithFile:@"bowButton.png" rect:CGRectMake(0,0,109,38)];
		bowButton.position = ccp(67,279);
		[self addChild:bowButton z:0];

		bowButtonOn = [CCSprite spriteWithFile:@"bowButtonOn.png" rect:CGRectMake(0,0,109,38)];
		bowButtonOn.position = ccp(67,279);
		[self addChild:bowButtonOn z:0];
		bowButtonOn.visible = TRUE;
		
	
		CCSprite* shieldButton = [CCSprite spriteWithFile:@"shieldButton.png" rect:CGRectMake(0,0,109,38)];
		shieldButton.position = ccp(196,279);
		[self addChild:shieldButton z:0];

		shieldButtonOn = [CCSprite spriteWithFile:@"shieldButtonOn.png" rect:CGRectMake(0,0,109,38)];
		shieldButtonOn.position = ccp(196,279);
		[self addChild:shieldButtonOn z:0];
		shieldButtonOn.visible = FALSE;
		
		CCSprite* swordButton = [CCSprite spriteWithFile:@"swordButton.png" rect:CGRectMake(0,0,109,38)];
		swordButton.position = ccp(67,216);
		[self addChild:swordButton z:0];

		swordButtonOn = [CCSprite spriteWithFile:@"swordButtonOn.png" rect:CGRectMake(0,0,109,38)];
		swordButtonOn.position = ccp(67,216);
		[self addChild:swordButtonOn z:0];
		swordButtonOn.visible = FALSE;
		
		CCSprite* castleButton = [CCSprite spriteWithFile:@"castleButton.png" rect:CGRectMake(0,0,109,38)];
		castleButton.position = ccp(196,216);
		[self addChild:castleButton z:0];

		castleButtonOn = [CCSprite spriteWithFile:@"castleButtonOn.png" rect:CGRectMake(0,0,109,38)];
		castleButtonOn.position = ccp(196,216);
		[self addChild:castleButtonOn z:0];
		castleButtonOn.visible = FALSE;
		
		CCSprite* combineButton = [CCSprite spriteWithFile:@"combineButton.png" rect:CGRectMake(0,0,109,38)];
		combineButton.position = ccp(67,155);
		[self addChild:combineButton z:0];

		combineButtonOn = [CCSprite spriteWithFile:@"combineButtonOn.png" rect:CGRectMake(0,0,109,38)];
		combineButtonOn.position = ccp(67,155);
		[self addChild:combineButtonOn z:0];
		combineButtonOn.visible = FALSE;
		
		CCSprite* upgradeButton = [CCSprite spriteWithFile:@"upgradeButton.png" rect:CGRectMake(0,0,128,37)];		
		upgradeButton.position = ccp(369,83);
		[self addChild:upgradeButton z:0];

		// 34.40   101.40    168.40 
		quickButton1 = [CCSprite spriteWithFile:@"quickButton.png" rect:CGRectMake(0,0,49,51)];
		quickButton1.position = ccp(61,33);
		[self addChild:quickButton1 z:0];
		
		quickButton1On = [CCSprite spriteWithFile:@"quickButtonOn.png" rect:CGRectMake(0,0,49,51)];
		quickButton1On.position = ccp(61,33);
		[self addChild:quickButton1On z:0];
		quickButton1On.visible = FALSE;

		quickIcon1 = [[MQuickIcon spriteSheetWithFile:@"quickIcon-all.png" capacity:12]init];
		quickIcon1.position = ccp(61,33);
		[self addChild:quickIcon1 z:1];

		quickButton2 = [CCSprite spriteWithFile:@"quickButton.png" rect:CGRectMake(0,0,49,51)];
		quickButton2.position = ccp(129,33);
		[self addChild:quickButton2 z:0];
		
		quickButton2On = [CCSprite spriteWithFile:@"quickButtonOn.png" rect:CGRectMake(0,0,49,51)];
		quickButton2On.position = ccp(129,33);
		[self addChild:quickButton2On z:0];
		quickButton2On.visible = FALSE;

		quickIcon2 = [[MQuickIcon spriteSheetWithFile:@"quickIcon-all.png" capacity:12]init];
		quickIcon2.position = ccp(129,33);
		[self addChild:quickIcon2 z:1];
		
		quickButton3 = [CCSprite spriteWithFile:@"quickButton.png" rect:CGRectMake(0,0,49,51)];
		quickButton3.position = ccp(201,33);
		[self addChild:quickButton3 z:0];
		
		quickButton3On = [CCSprite spriteWithFile:@"quickButtonOn.png" rect:CGRectMake(0,0,49,51)];
		quickButton3On.position = ccp(201,33);
		[self addChild:quickButton3On z:0];
		quickButton3On.visible = FALSE;
		
		quickIcon3 = [[MQuickIcon spriteSheetWithFile:@"quickIcon-all.png" capacity:12]init];
		quickIcon3.position = ccp(201,33);
		[self addChild:quickIcon3 z:1];
		
		CCSprite* goldButton = [CCSprite spriteWithFile:@"goldButton.png" rect:CGRectMake(0,0,127,32)];		
		goldButton.position = ccp(334,27);
		[self addChild:goldButton z:0];
		
		CCSprite* finButton = [CCSprite spriteWithFile:@"finButton.png" rect:CGRectMake(0,0,47,37)];		
		finButton.position = ccp(444,28);
		[self addChild:finButton z:0];
		
		menu1 = [CCSprite spriteWithFile:@"storeMenu1.png" rect:CGRectMake(0, 0, 189, 164)];
		menu1.position = ccp(367,220);
		[self addChild:menu1 z:0];
		menu1.visible = TRUE;

		arrow01 = [CCSprite spriteWithFile:@"arrow01.png" rect:CGRectMake(0, 0, 54, 57)];
		arrow01.position = ccp(305,269);
		[self addChild:arrow01 z:1];
		arrow01.visible = TRUE;
		
		arrow02 = [CCSprite spriteWithFile:@"arrow02.png" rect:CGRectMake(0, 0, 54, 57)];
		arrow02.position = ccp(367,269);
		[self addChild:arrow02 z:1];
		arrow02.visible = TRUE;
		
		arrow03 = [CCSprite spriteWithFile:@"arrow03.png" rect:CGRectMake(0, 0, 54, 57)];
		arrow03.position = ccp(430,269);
		[self addChild:arrow03 z:1];
		arrow03.visible = TRUE;

		arrow04 = [CCSprite spriteWithFile:@"arrow04.png" rect:CGRectMake(0, 0, 54, 57)];
		arrow04.position = ccp(305,189);
		[self addChild:arrow04 z:1];
		arrow04.visible = TRUE;

		arrow05 = [CCSprite spriteWithFile:@"arrow05.png" rect:CGRectMake(0, 0, 54, 57)];
		arrow05.position = ccp(367,189);
		[self addChild:arrow05 z:1];
		arrow05.visible = TRUE;

		arrow01On = [CCSprite spriteWithFile:@"arrow01-2.png" rect:CGRectMake(0, 0, 54, 57)];
		arrow01On.position = ccp(305,269);
		[self addChild:arrow01On z:1];
		arrow01On.visible = FALSE;
		
		arrow02On = [CCSprite spriteWithFile:@"arrow02-2.png" rect:CGRectMake(0, 0, 54, 57)];
		arrow02On.position = ccp(367,269);
		[self addChild:arrow02On z:1];
		arrow02On.visible = FALSE;
		
		arrow03On = [CCSprite spriteWithFile:@"arrow03-2.png" rect:CGRectMake(0, 0, 54, 57)];
		arrow03On.position = ccp(430,269);
		[self addChild:arrow03On z:1];
		arrow03On.visible = FALSE;
		
		arrow04On = [CCSprite spriteWithFile:@"arrow04-2.png" rect:CGRectMake(0, 0, 54, 57)];
		arrow04On.position = ccp(305,189);
		[self addChild:arrow04On z:1];
		arrow04On.visible = FALSE;
		
		arrow05On = [CCSprite spriteWithFile:@"arrow05-2.png" rect:CGRectMake(0, 0, 54, 57)];
		arrow05On.position = ccp(367,189);
		[self addChild:arrow05On z:1];
		arrow05On.visible = FALSE;
		
		arrow1up = [[MUpgradeNumber spriteSheetWithFile:@"upgrade_number.png" capacity:11] init];
		arrow1up.position = ccp(326,245);
		[self addChild:arrow1up z:2];
		[arrow1up setNumber:ud.m_iBow1Level];
		arrow1up.visible = TRUE;

		arrow2up = [[MUpgradeNumber spriteSheetWithFile:@"upgrade_number.png" capacity:11] init];
		arrow2up.position = ccp(388,245);
		[self addChild:arrow2up z:2];
		[arrow2up setNumber:ud.m_iBow2Level];
		arrow2up.visible = TRUE;

		arrow3up = [[MUpgradeNumber spriteSheetWithFile:@"upgrade_number.png" capacity:11] init];
		arrow3up.position = ccp(451,245);
		[self addChild:arrow3up z:2];
		[arrow3up setNumber:ud.m_iBow3Level];
		arrow3up.visible = TRUE;

		arrow4up = [[MUpgradeNumber spriteSheetWithFile:@"upgrade_number.png" capacity:11] init];
		arrow4up.position = ccp(326,165);
		[self addChild:arrow4up z:2];
		[arrow4up setNumber:ud.m_iBow4Level];
		arrow4up.visible = TRUE;
		
		arrow5up = [[MUpgradeNumber spriteSheetWithFile:@"upgrade_number.png" capacity:11] init];
		arrow5up.position = ccp(388,165);
		[self addChild:arrow5up z:2];
		[arrow5up setNumber:ud.m_iBow5Level];
		arrow5up.visible = TRUE;
		
		// 방패
		shield01 = [CCSprite spriteWithFile:@"shield01.png" rect:CGRectMake(0, 0, 54, 57)];
		shield01.position = ccp(305,269);
		[self addChild:shield01 z:1];
		shield01.visible = FALSE;

		shield02 = [CCSprite spriteWithFile:@"shield02.png" rect:CGRectMake(0, 0, 54, 57)];
		shield02.position = ccp(367,269);
		[self addChild:shield02 z:1];
		shield02.visible = FALSE;
		
		shield03 = [CCSprite spriteWithFile:@"shield03.png" rect:CGRectMake(0, 0, 54, 57)];
		shield03.position = ccp(430,269);
		[self addChild:shield03 z:1];
		shield03.visible = FALSE;

		shield04 = [CCSprite spriteWithFile:@"shield04.png" rect:CGRectMake(0, 0, 54, 57)];
		shield04.position = ccp(305,189);
		[self addChild:shield04 z:1];
		shield04.visible = FALSE;

		shield05 = [CCSprite spriteWithFile:@"shield05.png" rect:CGRectMake(0, 0, 54, 57)];
		shield05.position = ccp(367,189);
		[self addChild:shield05 z:1];
		shield05.visible = FALSE;

		shield01On = [CCSprite spriteWithFile:@"shield01-2.png" rect:CGRectMake(0, 0, 54, 57)];
		shield01On.position = ccp(305,269);
		[self addChild:shield01On z:1];
		shield01On.visible = FALSE;
		
		shield02On = [CCSprite spriteWithFile:@"shield02-2.png" rect:CGRectMake(0, 0, 54, 57)];
		shield02On.position = ccp(367,269);
		[self addChild:shield02On z:1];
		shield02On.visible = FALSE;
		
		shield03On = [CCSprite spriteWithFile:@"shield03-2.png" rect:CGRectMake(0, 0, 54, 57)];
		shield03On.position = ccp(430,269);
		[self addChild:shield03On z:1];
		shield03On.visible = FALSE;
		
		shield04On = [CCSprite spriteWithFile:@"shield04-2.png" rect:CGRectMake(0, 0, 54, 57)];
		shield04On.position = ccp(305,189);
		[self addChild:shield04On z:1];
		shield04On.visible = FALSE;
		
		shield05On = [CCSprite spriteWithFile:@"shield05-2.png" rect:CGRectMake(0, 0, 54, 57)];
		shield05On.position = ccp(367,189);
		[self addChild:shield05On z:1];
		shield05On.visible = FALSE;
		
		shield1up = [[MUpgradeNumber spriteSheetWithFile:@"upgrade_number.png" capacity:11] init];
		shield1up.position = ccp(326,245);
		[self addChild:shield1up z:2];
		[shield1up setNumber:ud.m_iShield1Level];
		shield1up.visible = FALSE;
		
		shield2up = [[MUpgradeNumber spriteSheetWithFile:@"upgrade_number.png" capacity:11] init];
		shield2up.position = ccp(388,245);
		[self addChild:shield2up z:2];
		[shield2up setNumber:ud.m_iShield2Level];
		shield2up.visible = FALSE;
		
		shield3up = [[MUpgradeNumber spriteSheetWithFile:@"upgrade_number.png" capacity:11] init];
		shield3up.position = ccp(451,245);
		[self addChild:shield3up z:2];
		[shield3up setNumber:ud.m_iShield3Level];
		shield3up.visible = FALSE;
		
		shield4up = [[MUpgradeNumber spriteSheetWithFile:@"upgrade_number.png" capacity:11] init];
		shield4up.position = ccp(326,165);
		[self addChild:shield4up z:2];
		[shield4up setNumber:ud.m_iShield4Level];
		shield4up.visible = FALSE;
		
		shield5up = [[MUpgradeNumber spriteSheetWithFile:@"upgrade_number.png" capacity:11] init];
		shield5up.position = ccp(388,165);
		[self addChild:shield5up z:2];
		[shield5up setNumber:ud.m_iShield5Level];
		shield5up.visible = FALSE;
		
		sword01 = [CCSprite spriteWithFile:@"sword01.png" rect:CGRectMake(0, 0, 54, 57)];
		sword01.position = ccp(305,269);
		[self addChild:sword01 z:1];
		sword01.visible = FALSE;

		sword02 = [CCSprite spriteWithFile:@"sword02.png" rect:CGRectMake(0, 0, 54, 57)];
		sword02.position = ccp(367,269);
		[self addChild:sword02 z:1];
		sword02.visible = FALSE;
		
		sword03 = [CCSprite spriteWithFile:@"sword03.png" rect:CGRectMake(0, 0, 54, 57)];
		sword03.position = ccp(430,269);
		[self addChild:sword03 z:1];
		sword03.visible = FALSE;

		sword04 = [CCSprite spriteWithFile:@"sword04.png" rect:CGRectMake(0, 0, 54, 57)];
		sword04.position = ccp(305,189);
		[self addChild:sword04 z:1];
		sword04.visible = FALSE;

		sword05 = [CCSprite spriteWithFile:@"sword05.png" rect:CGRectMake(0, 0, 54, 57)];
		sword05.position = ccp(367,189);
		[self addChild:sword05 z:1];
		sword05.visible = FALSE;

		sword01On = [CCSprite spriteWithFile:@"sword01-2.png" rect:CGRectMake(0, 0, 54, 57)];
		sword01On.position = ccp(305,269);
		[self addChild:sword01On z:1];
		sword01On.visible = FALSE;
		
		sword02On = [CCSprite spriteWithFile:@"sword02-2.png" rect:CGRectMake(0, 0, 54, 57)];
		sword02On.position = ccp(367,269);
		[self addChild:sword02On z:1];
		sword02On.visible = FALSE;
		
		sword03On = [CCSprite spriteWithFile:@"sword03-2.png" rect:CGRectMake(0, 0, 54, 57)];
		sword03On.position = ccp(430,269);
		[self addChild:sword03On z:1];
		sword03On.visible = FALSE;
		
		sword04On = [CCSprite spriteWithFile:@"sword04-2.png" rect:CGRectMake(0, 0, 54, 57)];
		sword04On.position = ccp(305,189);
		[self addChild:sword04On z:1];
		sword04On.visible = FALSE;
		
		sword05On = [CCSprite spriteWithFile:@"sword05-2.png" rect:CGRectMake(0, 0, 54, 57)];
		sword05On.position = ccp(367,189);
		[self addChild:sword05On z:1];
		sword05On.visible = FALSE;
	
		sword1up = [[MUpgradeNumber spriteSheetWithFile:@"upgrade_number.png" capacity:11] init];
		sword1up.position = ccp(326,245);
		[self addChild:sword1up z:2];
		[sword1up setNumber:ud.m_iSword1Level];
		sword1up.visible = FALSE;
		
		sword2up = [[MUpgradeNumber spriteSheetWithFile:@"upgrade_number.png" capacity:11] init];
		sword2up.position = ccp(388,245);
		[self addChild:sword2up z:2];
		[sword2up setNumber:ud.m_iSword2Level];
		sword2up.visible = FALSE;
		
		sword3up = [[MUpgradeNumber spriteSheetWithFile:@"upgrade_number.png" capacity:11] init];
		sword3up.position = ccp(451,245);
		[self addChild:sword3up z:2];
		[sword3up setNumber:ud.m_iSword3Level];
		sword3up.visible = FALSE;
		
		sword4up = [[MUpgradeNumber spriteSheetWithFile:@"upgrade_number.png" capacity:11] init];
		sword4up.position = ccp(326,165);
		[self addChild:sword4up z:2];
		[sword4up setNumber:ud.m_iSword4Level];
		sword4up.visible = FALSE;
		
		sword5up = [[MUpgradeNumber spriteSheetWithFile:@"upgrade_number.png" capacity:11] init];
		sword5up.position = ccp(388,165);
		[self addChild:sword5up z:2];
		[sword5up setNumber:ud.m_iSword5Level];
		sword5up.visible = FALSE;
		
		
		castlemenu1 = [CCSprite spriteWithFile:@"castlemenu1.png" rect:CGRectMake(0, 0, 195, 170)];
		castlemenu1.position = ccp(369,212);
		[self addChild:castlemenu1 z:0];
		castlemenu1.visible = FALSE;

		castlemenu2 = [CCSprite spriteWithFile:@"castlemenu2.png" rect:CGRectMake(0, 0, 195, 170)];
		castlemenu2.position = ccp(369,212);
		[self addChild:castlemenu2 z:0];
		castlemenu2.visible = FALSE;

		castlemenu3 = [CCSprite spriteWithFile:@"castlemenu3.png" rect:CGRectMake(0, 0, 195, 170)];
		castlemenu3.position = ccp(369,212);
		[self addChild:castlemenu3 z:0];
		castlemenu3.visible = FALSE;

		castlemenu4 = [CCSprite spriteWithFile:@"castlemenu4.png" rect:CGRectMake(0, 0, 195, 170)];
		castlemenu4.position = ccp(369,212);
		[self addChild:castlemenu4 z:0];
		castlemenu4.visible = FALSE;

		castlemenu5 = [CCSprite spriteWithFile:@"castlemenu5.png" rect:CGRectMake(0, 0, 195, 170)];
		castlemenu5.position = ccp(369,212);
		[self addChild:castlemenu5 z:0];
		castlemenu5.visible = FALSE;
				
		menu2 = [CCSprite spriteWithFile:@"storeMenu2.png" rect:CGRectMake(0, 0, 189, 164)];
		menu2.position = ccp(367,220);
		[self addChild:menu2 z:0];
		menu2.visible = FALSE;

		menu3 = [CCSprite spriteWithFile:@"storeMenu3.png" rect:CGRectMake(0, 0, 189, 164)];
		menu3.position = ccp(367,220);
		[self addChild:menu3 z:0];
		menu3.visible = FALSE;
				
		woodNum = [CCSprite spriteWithFile:@"WoodNum.png" rect:CGRectMake(0, 0, 55, 37)];
		woodNum.position = ccp(305,279);
		[self addChild:woodNum z:1];
		woodNum.visible = FALSE;

		woodNumOn = [CCSprite spriteWithFile:@"WoodNumOn.png" rect:CGRectMake(0, 0, 55, 37)];
		woodNumOn.position = ccp(305,279);
		[self addChild:woodNumOn z:1];
		woodNumOn.visible = FALSE;

		ironNum = [CCSprite spriteWithFile:@"IronNum.png" rect:CGRectMake(0, 0, 55, 37)];
		ironNum.position = ccp(367,279);
		[self addChild:ironNum z:1];
		ironNum.visible = FALSE;

		ironNumOn = [CCSprite spriteWithFile:@"IronNumOn.png" rect:CGRectMake(0, 0, 55, 37)];
		ironNumOn.position = ccp(367,279);
		[self addChild:ironNumOn z:1];
		ironNumOn.visible = FALSE;
		
		woodnumup = [[MUpgradeNumber spriteSheetWithFile:@"upgrade_number.png" capacity:11] init];
		woodnumup.position = ccp(330,265);
		[self addChild:woodnumup z:2];
		[woodnumup setNumber:ud.m_iWoodNum];
		woodnumup.visible = FALSE;
		
		ironnumup = [[MUpgradeNumber spriteSheetWithFile:@"upgrade_number.png" capacity:11] init];
		ironnumup.position = ccp(392,265);
		[self addChild:ironnumup z:2];
		[ironnumup setNumber:ud.m_iIronNum];
		ironnumup.visible = FALSE;
		//
		wood1Dis = [CCSprite spriteWithFile:@"Wood1Dis.png" rect:CGRectMake(0, 0, 55, 34)];
		wood1Dis.position = ccp(305,220);
		[self addChild:wood1Dis z:1];
		wood1Dis.visible = FALSE;
		
		wood1 = [CCSprite spriteWithFile:@"Wood1.png" rect:CGRectMake(0, 0, 55, 34)];
		wood1.position = ccp(305,220);
		[self addChild:wood1 z:1];
		wood1.visible = FALSE;
		
		wood1On = [CCSprite spriteWithFile:@"Wood1On.png" rect:CGRectMake(0, 0, 55, 34)];
		wood1On.position = ccp(305,220);
		[self addChild:wood1On z:1];
		wood1On.visible = FALSE;

		wood1Sold = [CCSprite spriteWithFile:@"wood1Sold.png" rect:CGRectMake(0, 0, 55, 34)];
		wood1Sold.position = ccp(305,220);
		[self addChild:wood1Sold z:1];
		wood1Sold.visible = FALSE;
		
		iron1Dis = [CCSprite spriteWithFile:@"Iron1Dis.png" rect:CGRectMake(0, 0, 55, 34)];
		iron1Dis.position = ccp(367,220);
		[self addChild:iron1Dis z:1];
		iron1Dis.visible = FALSE;
		
		iron1 = [CCSprite spriteWithFile:@"Iron1.png" rect:CGRectMake(0, 0, 55, 34)];
		iron1.position = ccp(367,220);
		[self addChild:iron1 z:1];
		iron1.visible = FALSE;
		
		iron1On = [CCSprite spriteWithFile:@"Iron1On.png" rect:CGRectMake(0, 0, 55, 34)];
		iron1On.position = ccp(367,220);
		[self addChild:iron1On z:1];
		iron1On.visible = FALSE;
		
		iron1Sold = [CCSprite spriteWithFile:@"iron1Sold.png" rect:CGRectMake(0, 0, 55, 34)];
		iron1Sold.position = ccp(367,220);
		[self addChild:iron1Sold z:1];
		iron1Sold.visible = FALSE;
		
		iron2Dis = [CCSprite spriteWithFile:@"Iron2Dis.png" rect:CGRectMake(0, 0, 55, 34)];
		iron2Dis.position = ccp(305,179);
		[self addChild:iron2Dis z:1];
		iron2Dis.visible = FALSE;

		iron2 = [CCSprite spriteWithFile:@"Iron2.png" rect:CGRectMake(0, 0, 55, 34)];
		iron2.position = ccp(305,179);
		[self addChild:iron2 z:1];
		iron2.visible = FALSE;
		
		iron2On = [CCSprite spriteWithFile:@"Iron2On.png" rect:CGRectMake(0, 0, 55, 34)];
		iron2On.position = ccp(305,179);
		[self addChild:iron2On z:1];
		iron2On.visible = FALSE;

		iron2Sold = [CCSprite spriteWithFile:@"iron2Sold.png" rect:CGRectMake(0, 0, 55, 34)];
		iron2Sold.position = ccp(305,179);
		[self addChild:iron2Sold z:1];
		iron2Sold.visible = FALSE;
		
		iron3Dis = [CCSprite spriteWithFile:@"Iron3Dis.png" rect:CGRectMake(0, 0, 55, 34)];
		iron3Dis.position = ccp(367,179);
		[self addChild:iron3Dis z:1];
		iron3Dis.visible = FALSE;
		
		iron3 = [CCSprite spriteWithFile:@"Iron3.png" rect:CGRectMake(0, 0, 55, 34)];
		iron3.position = ccp(367,179);
		[self addChild:iron3 z:1];
		iron3.visible = FALSE;
		
		iron3On = [CCSprite spriteWithFile:@"Iron3On.png" rect:CGRectMake(0, 0, 55, 34)];
		iron3On.position = ccp(367,179);
		[self addChild:iron3On z:1];
		iron3On.visible = FALSE;
		
		iron3Sold = [CCSprite spriteWithFile:@"iron3Sold.png" rect:CGRectMake(0, 0, 55, 34)];
		iron3Sold.position = ccp(367,179);
		[self addChild:iron3Sold z:1];
		iron3Sold.visible = FALSE;
		
		
		skill1 = [CCSprite spriteWithFile:@"skill1.png" rect:CGRectMake(0, 0,54,57)];
		skill1.position = ccp(305,269);
		[self addChild:skill1 z:1];
		skill1.visible = FALSE;
		
		skill1On = [CCSprite spriteWithFile:@"skill1On.png" rect:CGRectMake(0, 0,54,57)];
		skill1On.position = ccp(305,269);
		[self addChild:skill1On z:1];
		skill1On.visible = FALSE;

		skill2 = [CCSprite spriteWithFile:@"skill2.png" rect:CGRectMake(0, 0,54,57)];
		skill2.position = ccp(367,269);
		[self addChild:skill2 z:1];
		skill2.visible = FALSE;
		
		skill2On = [CCSprite spriteWithFile:@"skill2On.png" rect:CGRectMake(0, 0,54,57)];
		skill2On.position = ccp(367,269);
		[self addChild:skill2On z:1];
		skill2On.visible = FALSE;

		skill3 = [CCSprite spriteWithFile:@"skill3.png" rect:CGRectMake(0, 0,54,57)];
		skill3.position = ccp(430,269);
		[self addChild:skill3 z:1];
		skill3.visible = FALSE;
		
		skill3On = [CCSprite spriteWithFile:@"skill3On.png" rect:CGRectMake(0, 0,54,57)];
		skill3On.position = ccp(430,269);
		[self addChild:skill3On z:1];
		skill3On.visible = FALSE;

		skill4 = [CCSprite spriteWithFile:@"skill4.png" rect:CGRectMake(0, 0,54,57)];
		skill4.position = ccp(305,189);
		[self addChild:skill4 z:1];
		skill4.visible = FALSE;
		
		skill4On = [CCSprite spriteWithFile:@"skill4On.png" rect:CGRectMake(0, 0,54,57)];
		skill4On.position = ccp(305,189);
		[self addChild:skill4On z:1];
		skill4On.visible = FALSE;

		skill5 = [CCSprite spriteWithFile:@"skill5.png" rect:CGRectMake(0, 0,54,57)];
		skill5.position = ccp(367,189);
		[self addChild:skill5 z:1];
		skill5.visible = FALSE;
		
		skill5On = [CCSprite spriteWithFile:@"skill5On.png" rect:CGRectMake(0, 0,54,57)];
		skill5On.position = ccp(367,189);
		[self addChild:skill5On z:1];
		skill5On.visible = FALSE;

		skill6 = [CCSprite spriteWithFile:@"skill6.png" rect:CGRectMake(0, 0,54,57)];
		skill6.position = ccp(430,189);
		[self addChild:skill6 z:1];
		skill6.visible = FALSE;
		
		skill6On = [CCSprite spriteWithFile:@"skill6On.png" rect:CGRectMake(0, 0,54,57)];
		skill6On.position = ccp(430,189);
		[self addChild:skill6On z:1];
		skill6On.visible = FALSE;
		
		skill1up = [[MUpgradeNumber spriteSheetWithFile:@"upgrade_number.png" capacity:11] init];
		skill1up.position = ccp(326,245);
		[self addChild:skill1up z:2];
		[skill1up setNumber:ud.m_iSkill1Level];
		skill1up.visible = FALSE;

		skill2up = [[MUpgradeNumber spriteSheetWithFile:@"upgrade_number.png" capacity:11] init];
		skill2up.position = ccp(386,245);
		[self addChild:skill2up z:2];
		[skill2up setNumber:ud.m_iSkill2Level];
		skill2up.visible = FALSE;

		skill3up = [[MUpgradeNumber spriteSheetWithFile:@"upgrade_number.png" capacity:11] init];
		skill3up.position = ccp(451,245);
		[self addChild:skill3up z:2];
		[skill3up setNumber:ud.m_iSkill3Level];
		skill3up.visible = FALSE;

		skill4up = [[MUpgradeNumber spriteSheetWithFile:@"upgrade_number.png" capacity:11] init];
		skill4up.position = ccp(326,160);
		[self addChild:skill4up z:2];
		[skill4up setNumber:ud.m_iSkill4Level];
		skill4up.visible = FALSE;

		skill5up = [[MUpgradeNumber spriteSheetWithFile:@"upgrade_number.png" capacity:11] init];
		skill5up.position = ccp(386,160);
		[self addChild:skill5up z:2];
		[skill5up setNumber:ud.m_iSkill5Level];
		skill5up.visible = FALSE;

		skill6up = [[MUpgradeNumber spriteSheetWithFile:@"upgrade_number.png" capacity:11] init];
		skill6up.position = ccp(451,160);
		[self addChild:skill6up z:2];
		[skill6up setNumber:ud.m_iSkill6Level];
		skill6up.visible = FALSE;
		
		moneyLabel = [[CCLabel alloc] initWithString:@"0" fontName:@"Arial" fontSize:15];
		moneyLabel.anchorPoint = CGPointZero;
		moneyLabel.position = ccp(300,15);
		[self addChild:moneyLabel z:1];
		[self setMoneyLabel:ud.m_iMoney];
	}
	
	return self;
}
/*
- (CGRect)rect
{
//	CGSize s = [self.texture contentSize];
//	return CGRectMake(-s.width/2, -s.height/2, s.width,s.height);
}
*/
- (void)combineVisible
{
	woodNum.visible = TRUE;
	ironNum.visible = TRUE;
	MUserData *ud = [MUserData sharedUserData];

	if(ud.m_bWood1)
	{
		wood1Dis.visible = FALSE;
		wood1.visible = TRUE;
	}
	else
	{
		wood1Dis.visible = TRUE;
		wood1.visible = FALSE;
	}
	if(ud.m_bIron1)
	{
		iron1Dis.visible = FALSE;
		iron1.visible = TRUE;
	}
	else
	{
		iron1Dis.visible = TRUE;
		iron1.visible = FALSE;
	}

	if(ud.m_bIron2)
	{
		iron2Dis.visible = FALSE;
		iron2.visible = TRUE;
	}
	else
	{
		iron2Dis.visible = TRUE;
		iron2.visible = FALSE;
	}
	if(ud.m_bIron3)
	{
		iron3Dis.visible = FALSE;
		iron3.visible = TRUE;
	}
	else 
	{
		iron3Dis.visible = TRUE;
		iron3.visible = TRUE;
	}
	
	if(ud.m_bWood1Sold)
	{
		wood1.visible = FALSE;
		wood1Sold.visible = TRUE;
	}
	if(ud.m_bIron1Sold)
	{
		iron1.visible = FALSE;
		iron1Sold.visible = TRUE;
	}
	if(ud.m_bIron2Sold)
	{
		iron2.visible = FALSE;
		iron2Sold.visible = TRUE;
	}
	if(ud.m_bIron3Sold)
	{
		iron3.visible = FALSE;
		iron3Sold.visible = TRUE;
	}
}

- (void)combineUnvisible
{
	woodNum.visible = FALSE;
	ironNum.visible = FALSE;
	wood1.visible = FALSE;
	iron1.visible = FALSE;
	iron2.visible = FALSE;
	iron3.visible = FALSE;
	woodNumOn.visible = FALSE;
	ironNumOn.visible = FALSE;
	wood1On.visible = FALSE;
	iron1On.visible = FALSE;
	iron2On.visible = FALSE;
	iron3On.visible = FALSE;
	wood1Dis.visible = FALSE;
	iron1Dis.visible = FALSE;
	iron2Dis.visible = FALSE;
	iron3Dis.visible = FALSE;	
}

- (void)arrowUpUnvisible
{
	arrow1up.visible = FALSE;
	arrow2up.visible = FALSE;
	arrow3up.visible = FALSE;
	arrow4up.visible = FALSE;
	arrow5up.visible = FALSE;
}

- (void)arrowUpVisible
{
	arrow1up.visible = TRUE;
	arrow2up.visible = TRUE;
	arrow3up.visible = TRUE;
	arrow4up.visible = TRUE;
	arrow5up.visible = TRUE;
}

- (void)shieldUpUnvisible
{
	shield1up.visible = FALSE;
	shield2up.visible = FALSE;
	shield3up.visible = FALSE;
	shield4up.visible = FALSE;
	shield5up.visible = FALSE;
}

- (void)shieldUpVisible
{
	shield1up.visible = TRUE;
	shield2up.visible = TRUE;
	shield3up.visible = TRUE;
	shield4up.visible = TRUE;
	shield5up.visible = TRUE;
}

- (void)swordUpUnvisible
{
	sword1up.visible = FALSE;
	sword2up.visible = FALSE;
	sword3up.visible = FALSE;
	sword4up.visible = FALSE;
	sword5up.visible = FALSE;
}

- (void)swordUpVisible
{
	sword1up.visible = TRUE;
	sword2up.visible = TRUE;
	sword3up.visible = TRUE;
	sword4up.visible = TRUE;
	sword5up.visible = TRUE;
}

- (void)skillUpUnvisible
{
	skill1up.visible = FALSE;
	skill2up.visible = FALSE;
	skill3up.visible = FALSE;
	skill4up.visible = FALSE;
	skill5up.visible = FALSE;
	skill6up.visible = FALSE;
}

- (void)skillUpVisible
{
	skill1up.visible = TRUE;
	skill2up.visible = TRUE;
	skill3up.visible = TRUE;
	skill4up.visible = TRUE;
	skill5up.visible = TRUE;
	skill6up.visible = TRUE;
}

- (void)combineUpUnvisible
{
	woodnumup.visible = FALSE;
	ironnumup.visible = FALSE;
	wood1Dis.visible = FALSE;
	iron1Dis.visible = FALSE;
	iron2Dis.visible = FALSE;
	iron3Dis.visible = FALSE;
	wood1.visible = FALSE;
	iron1.visible = FALSE;
	iron2.visible = FALSE;
	iron3.visible = FALSE;
	wood1Sold.visible = FALSE;
	iron1Sold.visible = FALSE;
	iron2Sold.visible = FALSE;
	iron3Sold.visible = FALSE;	
}

- (void)combineUpVisible
{
	woodnumup.visible = TRUE;
	ironnumup.visible = TRUE;
	wood1Dis.visible = TRUE;
	iron1Dis.visible = TRUE;
	iron2Dis.visible = TRUE;
	iron3Dis.visible = TRUE;	
}

- (void)skillUnvisible
{
	skill1.visible = FALSE;
	skill1On.visible = FALSE;
	skill2.visible = FALSE;
	skill2On.visible = FALSE;
	skill3.visible = FALSE;
	skill3On.visible = FALSE;
	skill4.visible = FALSE;
	skill4On.visible = FALSE;
	skill5.visible = FALSE;
	skill5On.visible = FALSE;
	skill6.visible = FALSE;
	skill6On.visible = FALSE;
}

- (void)skillVisible
{
	skill1.visible = TRUE;
	skill2.visible = TRUE;
	skill3.visible = TRUE;
	skill4.visible = TRUE;
	skill5.visible = TRUE;
	skill6.visible = TRUE;
}

- (void)onEnter
{
	[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
	[super onEnter];
	//
}	

- (void)onExit
{
	[moneyLabel release];
	//
	[[CCTouchDispatcher sharedDispatcher] removeDelegate:self];
	[super onExit];
}

- (BOOL)containsTouchLocation:(UITouch *)touch
{
	// fin
//	CGPoint pt = [self convertTouchToNodeSpaceAR:touch];
//	NSLog(@"x:%f \ny:%f",pt.x,pt.y);
	return CGRectContainsPoint(CGRectMake(442-240-47/2,35-160-37/2,47,37), [self convertTouchToNodeSpaceAR:touch]);
}

-(void)clickBowButton
{
	menu1.visible = TRUE;
	menu2.visible = FALSE;
	menu3.visible = FALSE;
	
	castlemenu1.visible = FALSE;
	castlemenu2.visible = FALSE;
	castlemenu3.visible = FALSE;
	castlemenu4.visible = FALSE;
	castlemenu5.visible = FALSE;
	
	arrow01.visible = TRUE;
	arrow02.visible = TRUE;
	arrow03.visible = TRUE;
	arrow04.visible = TRUE;
	arrow05.visible = TRUE;
	
	shield01.visible = FALSE;
	shield02.visible = FALSE;
	shield03.visible = FALSE;
	shield04.visible = FALSE;
	shield05.visible = FALSE;
	
	sword01.visible = FALSE;
	sword02.visible = FALSE;
	sword03.visible = FALSE;
	sword04.visible = FALSE;
	sword05.visible = FALSE;

	[self swordOnUnvisible];
	[self shieldOnUnvisible];
	[self arrowOnUnvisible];
	[self arrowUpVisible];
	[self shieldUpUnvisible];
	[self swordUpUnvisible];

	[self combineUpUnvisible];
	
	bowButtonOn.visible = TRUE;
	shieldButtonOn.visible = FALSE;
	swordButtonOn.visible = FALSE;
	castleButtonOn.visible = FALSE;
	combineButtonOn.visible = FALSE;
	
	[self combineUnvisible];	
	[self skillUnvisible];
	[self skillUpUnvisible];
}

-(void) clickShieldButton
{
	menu1.visible = TRUE;
	menu2.visible = FALSE;
	menu3.visible = FALSE;
	
	castlemenu1.visible = FALSE;
	castlemenu2.visible = FALSE;
	castlemenu3.visible = FALSE;
	castlemenu4.visible = FALSE;
	castlemenu5.visible = FALSE;
	
	shield01.visible = TRUE;
	shield02.visible = TRUE;
	shield03.visible = TRUE;
	shield04.visible = TRUE;
	shield05.visible = TRUE;
	
	sword01.visible = FALSE;
	sword02.visible = FALSE;
	sword03.visible = FALSE;
	sword04.visible = FALSE;
	sword05.visible = FALSE;
	
	arrow01.visible = FALSE;
	arrow02.visible = FALSE;
	arrow03.visible = FALSE;
	arrow04.visible = FALSE;
	arrow05.visible = FALSE;

	[self swordOnUnvisible];
	[self shieldOnUnvisible];
	[self arrowOnUnvisible];
	
	[self arrowUpUnvisible];
	[self shieldUpVisible];
	[self swordUpUnvisible];
	[self combineUpUnvisible];
	
	bowButtonOn.visible = FALSE;
	shieldButtonOn.visible = TRUE;
	swordButtonOn.visible = FALSE;
	castleButtonOn.visible = FALSE;
	combineButtonOn.visible = FALSE;
	
	[self combineUnvisible];	
	[self skillUnvisible];
	[self skillUpUnvisible];
}

- (void)clickSwordButton
{
	menu1.visible = TRUE;
	menu2.visible = FALSE;
	menu3.visible = FALSE;
	
	castlemenu1.visible = FALSE;
	castlemenu2.visible = FALSE;
	castlemenu3.visible = FALSE;
	castlemenu4.visible = FALSE;
	castlemenu5.visible = FALSE;
	
	sword01.visible = TRUE;
	sword02.visible = TRUE;
	sword03.visible = TRUE;
	sword04.visible = TRUE;
	sword05.visible = TRUE;
	
	shield01.visible = FALSE;
	shield02.visible = FALSE;
	shield03.visible = FALSE;
	shield04.visible = FALSE;
	shield05.visible = FALSE;
	
	arrow01.visible = FALSE;
	arrow02.visible = FALSE;
	arrow03.visible = FALSE;
	arrow04.visible = FALSE;
	arrow05.visible = FALSE;

	[self swordOnUnvisible];
	[self shieldOnUnvisible];
	[self arrowOnUnvisible];

	[self arrowUpUnvisible];
	[self shieldUpUnvisible];
	[self swordUpVisible];	
	[self combineUpUnvisible];
	
	bowButtonOn.visible = FALSE;
	shieldButtonOn.visible = FALSE;
	swordButtonOn.visible = TRUE;
	castleButtonOn.visible = FALSE;
	combineButtonOn.visible = FALSE;		
	
	[self combineUnvisible];
	[self skillUnvisible];
	[self skillUpUnvisible];

}
-(void) clickCastleButton
{
	MUserData *ud = [MUserData sharedUserData];
	[self setCastleUpgrade:ud.m_iCastleLevel];
	
	menu1.visible = FALSE;
	menu2.visible = FALSE;
	menu3.visible = FALSE;
	
	sword01.visible = FALSE;
	sword02.visible = FALSE;
	sword03.visible = FALSE;
	sword04.visible = FALSE;
	sword05.visible = FALSE;
	
	shield01.visible = FALSE;
	shield02.visible = FALSE;
	shield03.visible = FALSE;
	shield04.visible = FALSE;
	shield05.visible = FALSE;
	
	arrow01.visible = FALSE;
	arrow02.visible = FALSE;
	arrow03.visible = FALSE;
	arrow04.visible = FALSE;
	arrow05.visible = FALSE;
	[self swordOnUnvisible];
	[self shieldOnUnvisible];
	[self arrowOnUnvisible];

	[self arrowUpUnvisible];
	[self shieldUpUnvisible];
	[self swordUpUnvisible];
	[self combineUpUnvisible];

	bowButtonOn.visible = FALSE;
	shieldButtonOn.visible = FALSE;
	swordButtonOn.visible = FALSE;
	castleButtonOn.visible = TRUE;
	combineButtonOn.visible = FALSE;

	
	[self combineUnvisible];
	[self skillUnvisible];
	[self skillUpUnvisible];
}

-(void) clickCombineButton
{
	menu1.visible = FALSE;
	menu2.visible = TRUE;
	menu3.visible = FALSE;
	
	castlemenu1.visible = FALSE;
	castlemenu2.visible = FALSE;
	castlemenu3.visible = FALSE;
	castlemenu4.visible = FALSE;
	castlemenu5.visible = FALSE;
	
	sword01.visible = FALSE;
	sword02.visible = FALSE;
	sword03.visible = FALSE;
	sword04.visible = FALSE;
	sword05.visible = FALSE;
	
	shield01.visible = FALSE;
	shield02.visible = FALSE;
	shield03.visible = FALSE;
	shield04.visible = FALSE;
	shield05.visible = FALSE;
	
	arrow01.visible = FALSE;
	arrow02.visible = FALSE;
	arrow03.visible = FALSE;
	arrow04.visible = FALSE;
	arrow05.visible = FALSE;
	
	[self swordOnUnvisible];
	[self shieldOnUnvisible];
	[self arrowOnUnvisible];

	[self arrowUpUnvisible];
	[self shieldUpUnvisible];
	[self swordUpUnvisible];
	[self combineUpVisible];
	
	bowButtonOn.visible = FALSE;
	shieldButtonOn.visible = FALSE;
	swordButtonOn.visible = FALSE;
	castleButtonOn.visible = FALSE;
	combineButtonOn.visible = TRUE;
	
	[self combineVisible];
	[self skillUnvisible];
	[self skillUpUnvisible];
}

-(void) clickQuick1Button
{
	menu1.visible = FALSE;
	menu2.visible = FALSE;
	menu3.visible = TRUE;
	
	castlemenu1.visible = FALSE;
	castlemenu2.visible = FALSE;
	castlemenu3.visible = FALSE;
	castlemenu4.visible = FALSE;
	castlemenu5.visible = FALSE;
	
	sword01.visible = FALSE;
	sword02.visible = FALSE;
	sword03.visible = FALSE;
	sword04.visible = FALSE;
	sword05.visible = FALSE;
	
	shield01.visible = FALSE;
	shield02.visible = FALSE;
	shield03.visible = FALSE;
	shield04.visible = FALSE;
	shield05.visible = FALSE;
	
	arrow01.visible = FALSE;
	arrow02.visible = FALSE;
	arrow03.visible = FALSE;
	arrow04.visible = FALSE;
	arrow05.visible = FALSE;
	
	[self swordOnUnvisible];
	[self shieldOnUnvisible];
	[self arrowOnUnvisible];
	
	[self arrowUpUnvisible];
	[self shieldUpUnvisible];
	[self swordUpUnvisible];
	[self combineUpUnvisible];
	
	bowButtonOn.visible = FALSE;
	shieldButtonOn.visible = FALSE;
	swordButtonOn.visible = FALSE;
	castleButtonOn.visible = FALSE;
	combineButtonOn.visible = FALSE;
	
	[self combineUnvisible];
	[self skillVisible];
	[self skillUpVisible];

	quickButton1On.visible = TRUE;
	quickButton2On.visible = FALSE;
	quickButton3On.visible = FALSE;
}

-(void) clickQuick2Button
{
	menu1.visible = FALSE;
	menu2.visible = FALSE;
	menu3.visible = TRUE;
	
	castlemenu1.visible = FALSE;
	castlemenu2.visible = FALSE;
	castlemenu3.visible = FALSE;
	castlemenu4.visible = FALSE;
	castlemenu5.visible = FALSE;
	
	sword01.visible = FALSE;
	sword02.visible = FALSE;
	sword03.visible = FALSE;
	sword04.visible = FALSE;
	sword05.visible = FALSE;
	
	shield01.visible = FALSE;
	shield02.visible = FALSE;
	shield03.visible = FALSE;
	shield04.visible = FALSE;
	shield05.visible = FALSE;
	
	arrow01.visible = FALSE;
	arrow02.visible = FALSE;
	arrow03.visible = FALSE;
	arrow04.visible = FALSE;
	arrow05.visible = FALSE;
	
	[self swordOnUnvisible];
	[self shieldOnUnvisible];
	[self arrowOnUnvisible];
	
	[self arrowUpUnvisible];
	[self shieldUpUnvisible];
	[self swordUpUnvisible];
	[self combineUpUnvisible];
	
	bowButtonOn.visible = FALSE;
	shieldButtonOn.visible = FALSE;
	swordButtonOn.visible = FALSE;
	castleButtonOn.visible = FALSE;
	combineButtonOn.visible = FALSE;
	
	[self combineUnvisible];
	[self skillVisible];
	[self skillUpVisible];

	quickButton1On.visible = FALSE;
	quickButton2On.visible = TRUE;
	quickButton3On.visible = FALSE;
}

-(void) clickQuick3Button
{
	menu1.visible = FALSE;
	menu2.visible = FALSE;
	menu3.visible = TRUE;
	
	castlemenu1.visible = FALSE;
	castlemenu2.visible = FALSE;
	castlemenu3.visible = FALSE;
	castlemenu4.visible = FALSE;
	castlemenu5.visible = FALSE;
	
	sword01.visible = FALSE;
	sword02.visible = FALSE;
	sword03.visible = FALSE;
	sword04.visible = FALSE;
	sword05.visible = FALSE;
	
	shield01.visible = FALSE;
	shield02.visible = FALSE;
	shield03.visible = FALSE;
	shield04.visible = FALSE;
	shield05.visible = FALSE;
	
	arrow01.visible = FALSE;
	arrow02.visible = FALSE;
	arrow03.visible = FALSE;
	arrow04.visible = FALSE;
	arrow05.visible = FALSE;
	
	[self swordOnUnvisible];
	[self shieldOnUnvisible];
	[self arrowOnUnvisible];
	
	[self arrowUpUnvisible];
	[self shieldUpUnvisible];
	[self swordUpUnvisible];
	[self combineUpUnvisible];

	bowButtonOn.visible = FALSE;
	shieldButtonOn.visible = FALSE;
	swordButtonOn.visible = FALSE;
	castleButtonOn.visible = FALSE;
	combineButtonOn.visible = FALSE;
	
	[self combineUnvisible];
	[self skillVisible];
	[self skillUpVisible];

	quickButton1On.visible = FALSE;
	quickButton2On.visible = FALSE;
	quickButton3On.visible = TRUE;
	
}

-(void) arrowOnUnvisible
{
	arrow01On.visible = FALSE;
	arrow02On.visible = FALSE;
	arrow03On.visible = FALSE;
	arrow04On.visible = FALSE;
	arrow05On.visible = FALSE;
}

-(void) shieldOnUnvisible
{
	shield01On.visible = FALSE;
	shield02On.visible = FALSE;
	shield03On.visible = FALSE;
	shield04On.visible = FALSE;
	shield05On.visible = FALSE;
}

-(void) swordOnUnvisible
{
	sword01On.visible = FALSE;
	sword02On.visible = FALSE;
	sword03On.visible = FALSE;
	sword04On.visible = FALSE;
	sword05On.visible = FALSE;
}

-(void) setMoneyLabel:(int)n
{
	MUserData *ud = [MUserData sharedUserData];
	NSString *str = [[NSString alloc] initWithFormat:@"%d", ud.m_iMoney];
	[moneyLabel setString:str];
	[str release];
}

-(void) setCastleUpgrade:(int)n
{
	MUserData *ud = [MUserData sharedUserData];
	if(ud.m_iCastleLevel == 0)
	{
		castlemenu1.visible = TRUE;
		castlemenu2.visible = FALSE;
		castlemenu3.visible = FALSE;
		castlemenu4.visible = FALSE;
		castlemenu5.visible = FALSE;
	}
	else if(ud.m_iCastleLevel == 1)
	{
		castlemenu1.visible = FALSE;
		castlemenu2.visible = TRUE;
		castlemenu3.visible = FALSE;
		castlemenu4.visible = FALSE;
		castlemenu5.visible = FALSE;		
	}
	else if(ud.m_iCastleLevel == 2)
	{
		castlemenu1.visible = FALSE;
		castlemenu2.visible = FALSE;
		castlemenu3.visible = TRUE;
		castlemenu4.visible = FALSE;
		castlemenu5.visible = FALSE;		
	}
	else if(ud.m_iCastleLevel == 3)
	{
		castlemenu1.visible = TRUE;
		castlemenu2.visible = FALSE;
		castlemenu3.visible = FALSE;
		castlemenu4.visible = TRUE;
		castlemenu5.visible = FALSE;		
	}
	else if(ud.m_iCastleLevel == 4)
	{
		castlemenu1.visible = FALSE;
		castlemenu2.visible = FALSE;
		castlemenu3.visible = FALSE;
		castlemenu4.visible = FALSE;
		castlemenu5.visible = TRUE;		
	}
	
}

- (NSString*)dataFilePath
{
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	return [documentsDirectory stringByAppendingPathComponent:@"archive"];
}

- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{
	//if ( ![self containsTouchLocation:touch] ) return NO;
	
	// fin 버튼 
	CGPoint touch_pt = [self convertTouchToNodeSpaceAR:touch];
	
	if(CGRectContainsPoint(CGRectMake(442-240-47/2,35-160-37/2,47,37), touch_pt))
	{
		MUserData* ud = [MUserData sharedUserData];

		NSMutableData *data = [[NSMutableData alloc] init];
		NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:data];
		[archiver encodeInt:ud.m_iBow1Level forKey:@"m_iBow1Level"];
		[archiver encodeInt:ud.m_iBow2Level forKey:@"m_iBow2Level"];
		[archiver encodeInt:ud.m_iBow3Level forKey:@"m_iBow3Level"];
		[archiver encodeInt:ud.m_iBow4Level forKey:@"m_iBow4Level"];
		[archiver encodeInt:ud.m_iBow5Level forKey:@"m_iBow5Level"];

		[archiver encodeInt:ud.m_iShield1Level forKey:@"m_iShield1Level"];
		[archiver encodeInt:ud.m_iShield2Level forKey:@"m_iShield2Level"];
		[archiver encodeInt:ud.m_iShield3Level forKey:@"m_iShield3Level"];
		[archiver encodeInt:ud.m_iShield4Level forKey:@"m_iShield4Level"];
		[archiver encodeInt:ud.m_iShield5Level forKey:@"m_iShield5Level"];

		[archiver encodeInt:ud.m_iSword1Level forKey:@"m_iSword1Level"];
		[archiver encodeInt:ud.m_iSword2Level forKey:@"m_iSword2Level"];
		[archiver encodeInt:ud.m_iSword3Level forKey:@"m_iSword3Level"];
		[archiver encodeInt:ud.m_iSword4Level forKey:@"m_iSword4Level"];
		[archiver encodeInt:ud.m_iSword5Level forKey:@"m_iSword5Level"];
		
		[archiver encodeInt:ud.m_iCastleLevel forKey:@"m_iCastleLevel"];
		[archiver encodeInt:ud.m_iIronNum forKey:@"m_iIronNum"];
		[archiver encodeInt:ud.m_iWoodNum forKey:@"m_iWoodNum"];
		
		[archiver encodeBool:ud.m_bWood1 forKey:@"m_bWood1"];
		[archiver encodeBool:ud.m_bIron1 forKey:@"m_bIron1"];
		[archiver encodeBool:ud.m_bIron2 forKey:@"m_bIron2"];
		[archiver encodeBool:ud.m_bIron3 forKey:@"m_bIron3"];
		
		[archiver encodeBool:ud.m_bWood1Sold forKey:@"m_bWood1Sold"];
		[archiver encodeBool:ud.m_bIron1Sold forKey:@"m_bIron1Sold"];
		[archiver encodeBool:ud.m_bIron2Sold forKey:@"m_bIron2Sold"];
		[archiver encodeBool:ud.m_bIron3Sold forKey:@"m_bIron3Sold"];

		[archiver encodeInt:ud.m_iSkill1Level forKey:@"m_iSkill1Level"];
		[archiver encodeInt:ud.m_iSkill2Level forKey:@"m_iSkill2Level"];
		[archiver encodeInt:ud.m_iSkill3Level forKey:@"m_iSkill3Level"];
		[archiver encodeInt:ud.m_iSkill4Level forKey:@"m_iSkill4Level"];
		[archiver encodeInt:ud.m_iSkill5Level forKey:@"m_iSkill5Level"];
		[archiver encodeInt:ud.m_iSkill6Level forKey:@"m_iSkill6Level"];

		[archiver encodeInt:ud.m_iQuickSlot1 forKey:@"m_iQuickSlot1"];
		[archiver encodeInt:ud.m_iQuickSlot2 forKey:@"m_iQuickSlot2"];
		[archiver encodeInt:ud.m_iQuickSlot3 forKey:@"m_iQuickSlot3"];

		[archiver encodeInt:ud.m_iQuickSlot1Num forKey:@"m_iQuickSlot1Num"];
		[archiver encodeInt:ud.m_iQuickSlot2Num forKey:@"m_iQuickSlot2Num"];
		[archiver encodeInt:ud.m_iQuickSlot3Num forKey:@"m_iQuickSlot3Num"];

		[archiver finishEncoding];
		[data writeToFile:[self dataFilePath] atomically:YES];
		[archiver release];
		[data release];
		
		CCScene *s2=[CCScene node];
		[s2 addChild:[Menu node]];
		[[CCDirector sharedDirector] replaceScene:[CCFlipXTransition transitionWithDuration:1 scene:s2]];		
	}
	
	// 화살
	else if(CGRectContainsPoint(CGRectMake(65-240-109/2,287-160-38/2,109,38), touch_pt))
	{
		[self clickBowButton];
	}
	
	// 방패
	else if(CGRectContainsPoint(CGRectMake(194-240-109/2,287-160-38/2,109,38), touch_pt))
	{
		[self clickShieldButton];
	}
	
	// 검
	else if(CGRectContainsPoint(CGRectMake(65-240-109/2,224-160-38/2,109,38), touch_pt))
	{
		[self clickSwordButton];
	}
	
	// 성
	else if(CGRectContainsPoint(CGRectMake(194-240-109/2,224-160-38/2,109,38), touch_pt))
	{
		[self clickCastleButton];
	}
	
	// 조합
	else if(CGRectContainsPoint(CGRectMake(65-240-109/2,163-160-38/2,109,38), touch_pt))
	{
		[self clickCombineButton];
	}
	// 34.40   101.40    168.40 
	// 퀵슬롯1
	else if(CGRectContainsPoint(CGRectMake(61-240-49/2,33-160-51/2,49,51), touch_pt))
	{
		[self clickQuick1Button];
	}
	else if(CGRectContainsPoint(CGRectMake(129-240-49/2,33-160-51/2,49,51), touch_pt))
	{
		[self clickQuick2Button];
	}
	else if(CGRectContainsPoint(CGRectMake(201-240-49/2,33-160-51/2,49,51), touch_pt))
	{
		[self clickQuick3Button];
	}
	
	// 업그레이드 버튼
	else if(CGRectContainsPoint(CGRectMake(373-240-128/2,90-160-37/2,128,37), touch_pt))
	{
		MUserData* ud = [MUserData sharedUserData];
		
		if(bowButtonOn.visible)
		{
			if(arrow01On.visible)
			{
				if(ud.m_iBow1Level == 9)
					return FALSE;
				
				else if(ud.m_iMoney >= 100)
				{
					ud.m_iMoney = ud.m_iMoney - 100;
					[self setMoneyLabel:ud.m_iMoney];
					ud.m_iBow1Level++;
					[arrow1up setNumber:ud.m_iBow1Level];
				}
			}
			else if(arrow02On.visible)
			{
				if(ud.m_iBow2Level == 9)
					return FALSE;
				
				else if(ud.m_iMoney >= 200)
				{
					ud.m_iMoney = ud.m_iMoney - 200;
					[self setMoneyLabel:ud.m_iMoney];
					ud.m_iBow2Level++;
					[arrow2up setNumber:ud.m_iBow2Level];
				}	
			}
			else if(arrow03On.visible)
			{
				if(ud.m_iBow3Level == 9)
					return FALSE;
				
				else if(ud.m_iMoney >= 400)
				{
					ud.m_iMoney = ud.m_iMoney - 400;
					[self setMoneyLabel:ud.m_iMoney];
					ud.m_iBow3Level++;
					[arrow3up setNumber:ud.m_iBow3Level];
				}	
			}
			else if(arrow04On.visible)
			{
				if(ud.m_iBow4Level == 9)
					return FALSE;
				
				else if(ud.m_iMoney >= 800)
				{
					ud.m_iMoney = ud.m_iMoney - 800;
					[self setMoneyLabel:ud.m_iMoney];
					ud.m_iBow4Level++;
					[arrow4up setNumber:ud.m_iBow4Level];
				}
			}
			else if(arrow05On.visible)
			{
				if(ud.m_iBow5Level == 9)
					return FALSE;
				
				else if(ud.m_iMoney >= 1600)
				{
					ud.m_iMoney = ud.m_iMoney - 1600;
					[self setMoneyLabel:ud.m_iMoney];
					ud.m_iBow5Level++;
					[arrow5up setNumber:ud.m_iBow5Level];
				}			
			}
		}
		else if(shieldButtonOn.visible)
		{
			if(shield01On.visible)
			{
				if(ud.m_iShield1Level == 9)
					return FALSE;
				
				else if(ud.m_iMoney >= 100)
				{
					ud.m_iMoney = ud.m_iMoney - 100;
					[self setMoneyLabel:ud.m_iMoney];
					ud.m_iShield1Level++;
					[shield1up setNumber:ud.m_iShield1Level];
				}				
			}
			else if(shield02On.visible)
			{
				if(ud.m_iShield2Level == 9)
					return FALSE;
				
				else if(ud.m_iMoney >= 200)
				{
					ud.m_iMoney = ud.m_iMoney - 200;
					[self setMoneyLabel:ud.m_iMoney];
					ud.m_iShield2Level++;
					[shield2up setNumber:ud.m_iShield2Level];
				}				
			}
			else if(shield03On.visible)
			{
				if(ud.m_iShield3Level == 9)
					return FALSE;
				
				else if(ud.m_iMoney >= 400)
				{
					ud.m_iMoney = ud.m_iMoney - 400;
					[self setMoneyLabel:ud.m_iMoney];
					ud.m_iShield3Level++;
					[shield3up setNumber:ud.m_iShield3Level];
				}
			}
			else if(shield04On.visible)
			{
				if(ud.m_iShield4Level == 9)
					return FALSE;
				
				else if(ud.m_iMoney >= 800)
				{
					ud.m_iMoney = ud.m_iMoney - 800;
					[self setMoneyLabel:ud.m_iMoney];
					ud.m_iShield4Level++;
					[shield4up setNumber:ud.m_iShield4Level];
				}
			}
			else if(shield05On.visible)
			{
				if(ud.m_iShield5Level == 9)
					return FALSE;
				
				else if(ud.m_iMoney >= 1600)
				{
					ud.m_iMoney = ud.m_iMoney - 1600;
					[self setMoneyLabel:ud.m_iMoney];
					ud.m_iShield5Level++;
					[shield5up setNumber:ud.m_iShield5Level];
				}
			}			
		}
		else if(swordButtonOn.visible)
		{
			if(sword01On.visible)
			{
				if(ud.m_iSword1Level == 9)
					return FALSE;
				
				else if(ud.m_iMoney >= 100)
				{
					ud.m_iMoney = ud.m_iMoney - 100;
					[self setMoneyLabel:ud.m_iMoney];
					ud.m_iSword1Level++;
					[sword1up setNumber:ud.m_iSword1Level];
				}
			}
			else if(sword02On.visible)
			{
				if(ud.m_iSword2Level == 9)
					return FALSE;
				
				else if(ud.m_iMoney >= 200)
				{
					ud.m_iMoney = ud.m_iMoney - 200;
					[self setMoneyLabel:ud.m_iMoney];
					ud.m_iSword2Level++;
					[sword2up setNumber:ud.m_iSword2Level];
				}
			}
			else if(sword03On.visible)
			{
				if(ud.m_iSword3Level == 9)
					return FALSE;
				
				else if(ud.m_iMoney >= 400)
				{
					ud.m_iMoney = ud.m_iMoney - 400;
					[self setMoneyLabel:ud.m_iMoney];
					ud.m_iSword3Level++;
					[sword3up setNumber:ud.m_iSword3Level];
				}
			}
			else if(sword04On.visible)
			{
				if(ud.m_iSword4Level == 9)
					return FALSE;
				
				else if(ud.m_iMoney >= 800)
				{
					ud.m_iMoney = ud.m_iMoney - 800;
					[self setMoneyLabel:ud.m_iMoney];
					ud.m_iSword4Level++;
					[sword4up setNumber:ud.m_iSword4Level];
				}
			}
			else if(sword05On.visible)
			{
				if(ud.m_iSword5Level == 9)
					return FALSE;
				
				else if(ud.m_iMoney >= 1600)
				{
					ud.m_iMoney = ud.m_iMoney - 1600;
					[self setMoneyLabel:ud.m_iMoney];
					ud.m_iSword5Level++;
					[sword5up setNumber:ud.m_iSword5Level];
				}
			}		
		}
		else if(castleButtonOn.visible)
		{
			int cost = 0;
			
			if(ud.m_iCastleLevel == 5)
				return FALSE;
			else if(ud.m_iCastleLevel == 0)
			{
				cost = 1000;
			}
			else if(ud.m_iCastleLevel == 1)
			{
				cost = 2000;
			}
			else if(ud.m_iCastleLevel == 2)
			{
				cost = 3000;
			}
			else if(ud.m_iCastleLevel == 3)
			{
				cost = 6000;
			}
			else if(ud.m_iCastleLevel == 4)
			{
				cost = 10000;
			}
			
			if(ud.m_iMoney >= cost)
			{
				ud.m_iMoney = ud.m_iMoney - cost;
				[self setMoneyLabel:ud.m_iMoney];
				ud.m_iCastleLevel++;
				[self setCastleUpgrade:ud.m_iCastleLevel];
			}		
		}
		else if(combineButtonOn.visible)
		{
			if(woodNumOn.visible)
			{
				if(ud.m_iWoodNum == 9)
					return FALSE;
				
				else if(ud.m_iMoney >= 300)
				{
					ud.m_iMoney = ud.m_iMoney - 300;
					[self setMoneyLabel:ud.m_iMoney];
					ud.m_iWoodNum++;
					[woodnumup setNumber:ud.m_iWoodNum];
					
					
					if((ud.m_iWoodNum >= 3)&&(ud.m_iIronNum >= 1))
					{
						ud.m_bWood1 = TRUE;
						wood1Dis.visible = FALSE;
						wood1.visible = TRUE;
					}
					if((ud.m_iWoodNum >= 1)&&(ud.m_iIronNum >= 3))
					{
						ud.m_bIron1 = TRUE;
						iron1Dis.visible = FALSE;
						iron1.visible = TRUE;
					}
					if((ud.m_iWoodNum >= 2)&&(ud.m_iIronNum >= 5))
					{
						ud.m_bIron2 = TRUE;
						iron2Dis.visible = FALSE;
						iron2.visible = TRUE;
					}
					if((ud.m_iWoodNum == 9)&&(ud.m_iIronNum == 9))
					{
						ud.m_bIron3 = TRUE;
						iron3Dis.visible = FALSE;
						iron3.visible = TRUE;
					}
				}
			}
			else if(ironNumOn.visible)
			{
				if(ud.m_iIronNum == 9)
					return FALSE;
				
				else if(ud.m_iMoney >= 300)
				{
					ud.m_iMoney = ud.m_iMoney - 300;
					[self setMoneyLabel:ud.m_iMoney];
					ud.m_iIronNum++;
					[ironnumup setNumber:ud.m_iIronNum];
				}
				if((ud.m_iWoodNum >= 3)&&(ud.m_iIronNum >= 1))
				{
					ud.m_bWood1 = TRUE;
					wood1Dis.visible = FALSE;
					wood1.visible = TRUE;
				}
				if((ud.m_iWoodNum >= 1)&&(ud.m_iIronNum >= 3))
				{
					ud.m_bIron1 = TRUE;
					iron1Dis.visible = FALSE;
					iron1.visible = TRUE;
				}
				if((ud.m_iWoodNum >= 2)&&(ud.m_iIronNum >= 5))
				{
					ud.m_bIron2 = TRUE;
					iron2Dis.visible = FALSE;
					iron2.visible = TRUE;
				}
				if((ud.m_iWoodNum == 9)&&(ud.m_iIronNum == 9))
				{
					ud.m_bIron3 = TRUE;
					iron3Dis.visible = FALSE;
					iron3.visible = TRUE;
				}				
			}
			
			else if(wood1On.visible)
			{
				if((ud.m_iMoney >= 1000) && (ud.m_bWood1Sold == FALSE))
				{
					ud.m_iMoney = ud.m_iMoney - 1000;
					[self setMoneyLabel:ud.m_iMoney];
					ud.m_bWood1Sold = TRUE;
					wood1Sold.visible = TRUE;
				}
			}
			else if(iron1On.visible)
			{
				if((ud.m_iMoney >= 1000) && (ud.m_bIron1Sold == FALSE))
				{
					ud.m_iMoney = ud.m_iMoney - 1000;
					[self setMoneyLabel:ud.m_iMoney];
					ud.m_bIron1Sold = TRUE;
					iron1Sold.visible = TRUE;
				}
			}
			else if(iron2On.visible)
			{
				if((ud.m_iMoney >= 2000) && (ud.m_bIron2Sold == FALSE))
				{
					ud.m_iMoney = ud.m_iMoney - 2000;
					[self setMoneyLabel:ud.m_iMoney];
					ud.m_bIron2Sold = TRUE;
					iron2Sold.visible = TRUE;
				}
			}
			else if(iron3On.visible)
			{
				if((ud.m_iMoney >= 5000) && (ud.m_bIron3Sold == FALSE))
				{
					ud.m_iMoney = ud.m_iMoney - 5000;
					[self setMoneyLabel:ud.m_iMoney];
					ud.m_bIron3Sold = TRUE;
					iron3Sold.visible = TRUE;
				}
			}
		}
		else if((quickButton1On.visible)||(quickButton2On.visible)||(quickButton3On.visible))
		{
			if(skill1On.visible)
			{
				if(ud.m_iSkill1Level == 9)
					return FALSE;
				
				else if(ud.m_iMoney >= 500)
				{
					ud.m_iMoney = ud.m_iMoney - 500;
					[self setMoneyLabel:ud.m_iMoney];
					ud.m_iSkill1Level++;
					[skill1up setNumber:ud.m_iSkill1Level];
				}	
			}
			else if(skill2On.visible)
			{
				if(ud.m_iSkill2Level == 9)
					return FALSE;
				
				else if(ud.m_iMoney >= 1000)
				{
					ud.m_iMoney = ud.m_iMoney - 1000;
					[self setMoneyLabel:ud.m_iMoney];
					ud.m_iSkill2Level++;
					[skill2up setNumber:ud.m_iSkill2Level];
				}				
			}
			else if(skill3On.visible)
			{
				if(ud.m_iSkill3Level == 9)
					return FALSE;
				
				else if(ud.m_iMoney >= 1500)
				{
					ud.m_iMoney = ud.m_iMoney - 1500;
					[self setMoneyLabel:ud.m_iMoney];
					ud.m_iSkill3Level++;
					[skill3up setNumber:ud.m_iSkill3Level];
				}				
			}
			else if(skill4On.visible)
			{
				if(ud.m_iSkill4Level == 9)
					return FALSE;
				
				else if(ud.m_iMoney >= 2000)
				{
					ud.m_iMoney = ud.m_iMoney - 2000;
					[self setMoneyLabel:ud.m_iMoney];
					ud.m_iSkill4Level++;
					[skill4up setNumber:ud.m_iSkill4Level];
				}
			}
			else if(skill5On.visible)
			{
				if(ud.m_iSkill5Level == 9)
					return FALSE;
				
				else if(ud.m_iMoney >= 1500)
				{
					ud.m_iMoney = ud.m_iMoney - 1500;
					[self setMoneyLabel:ud.m_iMoney];
					ud.m_iSkill5Level++;
					[skill5up setNumber:ud.m_iSkill5Level];
				}
			}
			else if(skill6On.visible)
			{
				if(ud.m_iSkill6Level == 9)
					return FALSE;
				
				else if(ud.m_iMoney >= 1000)
				{
					ud.m_iMoney = ud.m_iMoney - 1000;
					[self setMoneyLabel:ud.m_iMoney];
					ud.m_iSkill6Level++;
					[skill6up setNumber:ud.m_iSkill6Level];
				}
			}
		}
	}// 업그래이드 버튼
		
	else 
	{
		if(bowButtonOn.visible)
		{			
			// 화살 1
			if(CGRectContainsPoint(CGRectMake(305-240-54/2,269-160-57/2,54,57), touch_pt))
			{
				arrow01On.visible = TRUE;
				arrow02On.visible = FALSE;
				arrow03On.visible = FALSE;
				arrow04On.visible = FALSE;
				arrow05On.visible = FALSE;				
			}
			// 화살 2
			else if(CGRectContainsPoint(CGRectMake(367-240-54/2,269-160-57/2,54,57), touch_pt))
			{
				arrow01On.visible = FALSE;
				arrow02On.visible = TRUE;
				arrow03On.visible = FALSE;
				arrow04On.visible = FALSE;
				arrow05On.visible = FALSE;								
			}
			// 화살 3
			else if(CGRectContainsPoint(CGRectMake(430-240-54/2,269-160-57/2,54,57), touch_pt))
			{
				arrow01On.visible = FALSE;
				arrow02On.visible = FALSE;
				arrow03On.visible = TRUE;
				arrow04On.visible = FALSE;
				arrow05On.visible = FALSE;				
			}
			// 화살 4
			else if(CGRectContainsPoint(CGRectMake(305-240-54/2,189-160-57/2,54,57), touch_pt))
			{
				arrow01On.visible = FALSE;
				arrow02On.visible = FALSE;
				arrow03On.visible = FALSE;
				arrow04On.visible = TRUE;
				arrow05On.visible = FALSE;								
			}
			// 화살 5
			else if(CGRectContainsPoint(CGRectMake(357-240-54/2,189-160-57/2,54,57), touch_pt))
			{
				arrow01On.visible = FALSE;
				arrow02On.visible = FALSE;
				arrow03On.visible = FALSE;
				arrow04On.visible = FALSE;
				arrow05On.visible = TRUE;					
			}
		}
		else if(shieldButtonOn.visible)
		{
			// 화살 1
			if(CGRectContainsPoint(CGRectMake(305-240-54/2,269-160-57/2,54,57), touch_pt))
			{
				shield01On.visible = TRUE;
				shield02On.visible = FALSE;
				shield03On.visible = FALSE;
				shield04On.visible = FALSE;
				shield05On.visible = FALSE;				
			}
			// 화살 2
			else if(CGRectContainsPoint(CGRectMake(367-240-54/2,269-160-57/2,54,57), touch_pt))
			{
				shield01On.visible = FALSE;
				shield02On.visible = TRUE;
				shield03On.visible = FALSE;
				shield04On.visible = FALSE;
				shield05On.visible = FALSE;				
			}
			// 화살 3
			else if(CGRectContainsPoint(CGRectMake(430-240-54/2,269-160-57/2,54,57), touch_pt))
			{
				shield01On.visible = FALSE;
				shield02On.visible = FALSE;
				shield03On.visible = TRUE;
				shield04On.visible = FALSE;
				shield05On.visible = FALSE;				
			}
			// 화살 4
			else if(CGRectContainsPoint(CGRectMake(305-240-54/2,189-160-57/2,54,57), touch_pt))
			{
				shield01On.visible = FALSE;
				shield02On.visible = FALSE;
				shield03On.visible = FALSE;
				shield04On.visible = TRUE;
				shield05On.visible = FALSE;				
			}
			// 화살 5
			else if(CGRectContainsPoint(CGRectMake(357-240-54/2,189-160-57/2,54,57), touch_pt))
			{
				shield01On.visible = FALSE;
				shield02On.visible = FALSE;
				shield03On.visible = FALSE;
				shield04On.visible = FALSE;
				shield05On.visible = TRUE;				
			}			
		}
		else if(swordButtonOn.visible)
		{
			// 화살 1
			if(CGRectContainsPoint(CGRectMake(305-240-54/2,269-160-57/2,54,57), touch_pt))
			{
				sword01On.visible = TRUE;
				sword02On.visible = FALSE;
				sword03On.visible = FALSE;
				sword04On.visible = FALSE;
				sword05On.visible = FALSE;				
			}
			// 화살 2
			else if(CGRectContainsPoint(CGRectMake(367-240-54/2,269-160-57/2,54,57), touch_pt))
			{
				sword01On.visible = FALSE;
				sword02On.visible = TRUE;
				sword03On.visible = FALSE;
				sword04On.visible = FALSE;
				sword05On.visible = FALSE;				
			}
			// 화살 3
			else if(CGRectContainsPoint(CGRectMake(430-240-54/2,269-160-57/2,54,57), touch_pt))
			{
				sword01On.visible = FALSE;
				sword02On.visible = FALSE;
				sword03On.visible = TRUE;
				sword04On.visible = FALSE;
				sword05On.visible = FALSE;				
			}
			// 화살 4
			else if(CGRectContainsPoint(CGRectMake(305-240-54/2,189-160-57/2,54,57), touch_pt))
			{
				sword01On.visible = FALSE;
				sword02On.visible = FALSE;
				sword03On.visible = FALSE;
				sword04On.visible = TRUE;
				sword05On.visible = FALSE;				
			}
			// 화살 5
			else if(CGRectContainsPoint(CGRectMake(357-240-54/2,189-160-57/2,54,57), touch_pt))
			{
				sword01On.visible = FALSE;
				sword02On.visible = FALSE;
				sword03On.visible = FALSE;
				sword04On.visible = FALSE;
				sword05On.visible = TRUE;				
			}			
		}
		else if(castleButtonOn.visible)
		{
		}
		else if((quickButton1On.visible)||(quickButton2On.visible)||(quickButton3On.visible))
		{
			if(CGRectContainsPoint(CGRectMake(305-240-54/2,269-160-57/2,54,57), touch_pt))
			{
				skill1On.visible = TRUE;
				skill2On.visible = FALSE;
				skill3On.visible = FALSE;
				skill4On.visible = FALSE;
				skill5On.visible = FALSE;
				skill6On.visible = FALSE;
				
				if(quickButton1On.visible)
				{
					[quickIcon1 setIcon:1];
				}
				else if(quickButton2On.visible)
				{
					[quickIcon2 setIcon:1];
				}
				else if(quickButton3On.visible)
				{
					[quickIcon3 setIcon:1];
				}
			}
			else if(CGRectContainsPoint(CGRectMake(367-240-54/2,269-160-57/2,54,57), touch_pt))
			{
				skill1On.visible = FALSE;
				skill2On.visible = TRUE;
				skill3On.visible = FALSE;
				skill4On.visible = FALSE;
				skill5On.visible = FALSE;
				skill6On.visible = FALSE;
				
				if(quickButton1On.visible)
				{
					[quickIcon1 setIcon:2];
				}
				else if(quickButton2On.visible)
				{
					[quickIcon2 setIcon:2];
				}
				else if(quickButton3On.visible)
				{
					[quickIcon3 setIcon:2];
				}		
			}
			else if(CGRectContainsPoint(CGRectMake(430-240-54/2,269-160-57/2,54,57), touch_pt))
			{
				skill1On.visible = FALSE;
				skill2On.visible = FALSE;
				skill3On.visible = TRUE;
				skill4On.visible = FALSE;
				skill5On.visible = FALSE;
				skill6On.visible = FALSE;
				if(quickButton1On.visible)
				{
					[quickIcon1 setIcon:3];
				}
				else if(quickButton2On.visible)
				{
					[quickIcon2 setIcon:3];
				}
				else if(quickButton3On.visible)
				{
					[quickIcon3 setIcon:3];
				}				
			}
			else if(CGRectContainsPoint(CGRectMake(305-240-54/2,189-160-57/2,54,57), touch_pt))
			{
				skill1On.visible = FALSE;
				skill2On.visible = FALSE;
				skill3On.visible = FALSE;
				skill4On.visible = TRUE;
				skill5On.visible = FALSE;
				skill6On.visible = FALSE;
				if(quickButton1On.visible)
				{
					[quickIcon1 setIcon:4];
				}
				else if(quickButton2On.visible)
				{
					[quickIcon2 setIcon:4];
				}
				else if(quickButton3On.visible)
				{
					[quickIcon3 setIcon:4];
				}				
			}
			else if(CGRectContainsPoint(CGRectMake(367-240-54/2,189-160-57/2,54,57), touch_pt))
			{
				skill1On.visible = FALSE;
				skill2On.visible = FALSE;
				skill3On.visible = FALSE;
				skill4On.visible = FALSE;
				skill5On.visible = TRUE;
				skill6On.visible = FALSE;
				if(quickButton1On.visible)
				{
					[quickIcon1 setIcon:5];
				}
				else if(quickButton2On.visible)
				{
					[quickIcon2 setIcon:5];
				}
				else if(quickButton3On.visible)
				{
					[quickIcon3 setIcon:5];
				}
			}
			else if(CGRectContainsPoint(CGRectMake(430-240-54/2,189-160-57/2,54,57), touch_pt))
			{
				skill1On.visible = FALSE;
				skill2On.visible = FALSE;
				skill3On.visible = FALSE;
				skill4On.visible = FALSE;
				skill5On.visible = FALSE;
				skill6On.visible = TRUE;
				
				if(quickButton1On.visible)
				{
					[quickIcon1 setIcon:6];
				}
				else if(quickButton2On.visible)
				{
					[quickIcon2 setIcon:6];
				}
				else if(quickButton3On.visible)
				{
					[quickIcon3 setIcon:6];
				}
			}
		}
		else if(combineButtonOn.visible)
		{
			// 나무
			if(CGRectContainsPoint(CGRectMake(305-240-55/2,279-160-37/2,55,37), touch_pt))
			{
				woodNumOn.visible = TRUE;
				ironNumOn.visible = FALSE;
				wood1On.visible = FALSE;
				iron1On.visible = FALSE;
				iron2On.visible = FALSE;
				iron3On.visible = FALSE;
				
			}
			// 철 
			else if(CGRectContainsPoint(CGRectMake(367-240-55/2,279-160-37/2,55,37), touch_pt))
			{
				woodNumOn.visible = FALSE;
				ironNumOn.visible = TRUE;
				wood1On.visible = FALSE;
				iron1On.visible = FALSE;
				iron2On.visible = FALSE;
				iron3On.visible = FALSE;
			}
						
			// 나무1
			else if(CGRectContainsPoint(CGRectMake(305-240-55/2,220-160-34/2,55,34), touch_pt))
			{
				if(wood1Dis.visible == FALSE)
				{
					wood1On.visible = TRUE;
					iron1On.visible = FALSE;
					iron2On.visible = FALSE;
					iron3On.visible = FALSE;					
					
					woodNumOn.visible = FALSE;
					ironNumOn.visible = FALSE;
				}
			}
			// 철1
			else if(CGRectContainsPoint(CGRectMake(367-240-55/2,220-160-34/2,55,34), touch_pt))
			{
				if(iron1Dis.visible == FALSE)
				{
					wood1On.visible = FALSE;
					iron1On.visible = TRUE;
					iron2On.visible = FALSE;
					iron3On.visible = FALSE;
					
					woodNumOn.visible = FALSE;
					ironNumOn.visible = FALSE;
				}
			}
			// 철2
			else if(CGRectContainsPoint(CGRectMake(305-240-55/2,179-160-34/2,55,34), touch_pt))
			{
				if(iron2Dis.visible == FALSE)
				{
					wood1On.visible = FALSE;
					iron1On.visible = FALSE;
					iron2On.visible = TRUE;
					iron3On.visible = FALSE;
					
					woodNumOn.visible = FALSE;
					ironNumOn.visible = FALSE;
				}
			}
			// 철3
			else if(CGRectContainsPoint(CGRectMake(367-240-55/2,179-160-34/2,55,34), touch_pt))
			{
				if(iron3Dis.visible == FALSE)
				{
					wood1On.visible = FALSE;
					iron1On.visible = FALSE;
					iron2On.visible = FALSE;
					iron3On.visible = TRUE;
					
					woodNumOn.visible = FALSE;
					ironNumOn.visible = FALSE;
				}
   			}
		}
	}


	return YES;
}

- (void)ccTouchMoved:(UITouch *)touch withEvent:(UIEvent *)event
{		
}

- (void)ccTouchEnded:(UITouch *)touch withEvent:(UIEvent *)event
{
}

@end
