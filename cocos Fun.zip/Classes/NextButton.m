//
//  NextButton.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 27..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "NextButton.h"
#import "MStore.h"

@implementation NextButton

-(id) init
{
	if( (self=[super init] )) 
	{
		m_sprite[0] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(0,0,61,37)];
		[self addChild:m_sprite[0] z:0 tag:0];
		m_sprite[1] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(61,0,61,37)];
		[self addChild:m_sprite[1] z:0 tag:0];
		m_sprite[1].visible = FALSE;
	}
	return self;
}

- (CGRect)rect
{
	return CGRectMake(-14, -11, 28, 23);
}

- (void)onEnter
{
	[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
	[super onEnter];
}

- (void)onExit
{
	[[CCTouchDispatcher sharedDispatcher] removeDelegate:self];
	[super onExit];
}

- (BOOL)containsTouchLocation:(UITouch *)touch
{	
	return CGRectContainsPoint(self.rect, [self convertTouchToNodeSpaceAR:touch]);
}


- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{
	if ( ![self containsTouchLocation:touch] ) return NO;
	
	CCScene *s = [CCScene node];
	
	[s addChild:[MStore node]];
	[[CCDirector sharedDirector] replaceScene:[CCFlipXTransition transitionWithDuration:1 scene:s]];
	
	return YES;
}

@end
