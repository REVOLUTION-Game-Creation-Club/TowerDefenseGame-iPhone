//
//  cocos_FunAppDelegate.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 3..
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface cocos_FunAppDelegate : NSObject <UIApplicationDelegate> {
	UIWindow *window;
}

@property (nonatomic, retain) UIWindow *window;

@end
