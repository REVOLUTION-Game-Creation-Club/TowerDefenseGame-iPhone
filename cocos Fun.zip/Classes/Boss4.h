//
//  Boss4.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 19..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MUnit.h"

@class MStateMachine;
@class MState;
@class Boss4MoveState;
@class Boss4AttackState;
@class Boss4DeathState;
@class Boss4WaitState;
@class Boss4ChaseState;


@interface Boss4 : MUnit 
{
	BOOL				m_bAlive;
	BOOL				m_bDeath;
	CGPoint				m_ptFace;
	CGPoint				m_ptFleePoint;
	CGPoint				m_ptChasePoint;
	float				m_fRadius;
	float				m_fSight;
	int					m_iHPMax;
	
	CCSprite*			m_spriteWait[3];
	CCSprite*			m_spriteMove[8];
	CCSprite*			m_spriteAttack[3];
	CCSprite*			m_spriteDeath[4];

	CCSprite*			m_hpSprite[21];
	
	MStateMachine*		m_stateMachine;
	Boss4MoveState*			m_moveState;
	Boss4AttackState*		m_attackState;
	Boss4DeathState*		m_deathState;
	Boss4WaitState*			m_waitState;
	Boss4ChaseState*		m_chaseState;
	
	MUnit*			m_target;	
}

-(id) init;
-(void) update;
-(void) dealloc;

-(void) changeState:(MState*)new_state;
-(BOOL) isInRadius:(CGPoint)pt;
-(BOOL) isInSight:(CGPoint)pt;
-(void) chase:(CGPoint)pt;
-(void) attack;
-(void) suffer:(int)hp;
-(CGPoint) getFleePoint;
-(CGPoint) getChasePoint;
-(void) setDeath:(BOOL)bDeath;
-(BOOL) getDeath;
-(void) changeWaitState;

-(void) WaitAnimation;
-(void) MoveAnimation;
-(void) AttackAnimation;
-(void) DeathAnimation;

-(void) dead;
-(void) setFlipX:(BOOL)b;
-(void) wait;
-(void) go;
-(void) unvisibleAll;
//-(void) setPosition:(CGPoint)pt;
-(NSString*) name;
-(void) setTargetUnit:(MUnit*)pt;
-(MUnit*) getTargetUnit;
-(void) setAlive:(BOOL)b;
-(BOOL) isAlive;
@end
