//
//  GameUI.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 9..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MLeftSlot.h"
#import "MUnitButton.h"
#import "MUnitButton2.h"
#import "MUnitButton3.h"
#import "MUnitButton4.h"
#import "MUnitButton5.h"
#import "MRightSlot.h"
#import "MBackground.h"

@implementation MLeftSlot
/*
static MLeftSlot* g_sharedLeft = nil;

+ (MLeftSlot*)sharedLeft
{
	if (!g_sharedLeft)
		g_sharedLeft = [MLeftSlot spriteWithFile:@"right_slot.png" rect:CGRectMake(0, 0, 40, 40)];

	return g_sharedLeft;
}
*/
-(id)init
{
	if((self=[super init]))
	{
		bFold = TRUE;
		//[self initItem];
	}
	
	return self;
}

-(void)initItem
{
	bar = [CCSprite spriteWithFile:@"left_bar.png" rect:CGRectMake(0, 0, 210, 40)];
	bar.position = ccp(bar.contentSize.width/2-210,bar.contentSize.height/2);
	[self addChild:bar z:1];
	
	item = [[MUnitButton spriteSheetWithFile:@"a-all.png" capacity:15] init];
	[item setBackground:m_background];
	item.position = ccp(18,17);
	[bar addChild:item];
	
	item2 = [[MUnitButton2 spriteSheetWithFile:@"b-all.png" capacity:15]init];
	[item2 setBackground:m_background];
	item2.position = ccp(61,17);
	[bar addChild:item2];
	
	item3 = [[MUnitButton3 spriteSheetWithFile:@"c-all.png" capacity:15]init];
	[item3 setBackground:m_background];
	item3.position = ccp(103,17);
	[bar addChild:item3];

	item4 = [[MUnitButton4 spriteSheetWithFile:@"d-all.png" capacity:15]init];
	[item4 setBackground:m_background];
	item4.position = ccp(145,17);
	[bar addChild:item4];
	
	item5 = [[MUnitButton5 spriteSheetWithFile:@"x0.png" capacity:1]init];
	[item5 setBackground:m_background];
	item5.position = ccp(187,17);
	[bar addChild:item5];
}

- (CGRect)rect
{
	CGSize s = [self.texture contentSize];
	//NSLog(@"rect(%f,%f,%f,%f)\n",-s.width/2, -s.height/2, s.width, s.height);

	return CGRectMake(-s.width/2, -s.height/2, s.width,s.height);
}

- (void)onEnter
{
	[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
	[super onEnter];
}

- (void)onExit
{
	[[CCTouchDispatcher sharedDispatcher] removeDelegate:self];
	[super onExit];
}

- (BOOL)containsTouchLocation:(UITouch *)touch
{
	//NSLog(@"touch(%f,%f",pt.x, pt.y);

	return CGRectContainsPoint(self.rect, [self convertTouchToNodeSpaceAR:touch]);
}

- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{
	if ( ![self containsTouchLocation:touch] ) return NO;
	
	
//	NSLog(@"click\n");
	//TODO: 바를 지우고 자신의 그림을 바꾼다.
	if(bFold)
	{
//		[self removeChild:item2 cleanup:YES];
//		[self removeChild:item cleanup:YES];
//		[self removeChild:bar cleanup:YES];
		[self fold];
	}
	else 
	{
//		[self initItem];
		[self setPosition:CGPointMake(self.contentSize.width/2+210,self.contentSize.height/2)];		
		bFold = TRUE;
		
		//MRightSlot* right = [MRightSlot sharedRight];
		[m_rightSlot fold];
	}

	return YES;
}

-(void)fold
{
	[self setPosition:CGPointMake(self.contentSize.width/2,self.contentSize.height/2)];
	bFold = FALSE;
}
- (void)ccTouchMoved:(UITouch *)touch withEvent:(UIEvent *)event
{
}

- (void)ccTouchEnded:(UITouch *)touch withEvent:(UIEvent *)event
{
}

-(void)item1Produce:(int)percent
{
	[item produce:percent];
}

-(void)item2Produce:(int)percent
{
	[item2 produce:percent];
}

-(void)item3Produce:(int)percent
{
	[item3 produce:percent];	
}

-(void)item4Produce:(int)percent
{
	[item4 produce:percent];	
}

-(void) produce1Complete
{
	[item produceComplete];
}

-(void) produce2Complete
{
	[item2 produceComplete];
}

-(void) produce3Complete
{
	[item3 produceComplete];
}

-(void) produce4Complete
{
	[item4 produceComplete];
}

-(void) setBackground:(MBackground*)bg
{
	m_background = bg;
}

-(void) setRightSlot:(MRightSlot*)slot
{
	m_rightSlot = slot;
}

@end
