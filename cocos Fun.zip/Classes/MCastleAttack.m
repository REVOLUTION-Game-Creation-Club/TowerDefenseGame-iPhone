//
//  MTowerAttack.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 18..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MCastleAttack.h"
#import "MCastle.h"
#import "MBackground.h"
#import "MWalkman.h"

@implementation MCastleAttack
- (id)init
{
	if( (self=[super init] )) 
	{
	}
	
	return self;
}

- (void)Enter:(id)owner
{
	MCastle* castle = owner;
	
	m_arrow = [CCSprite spriteWithFile:@"arrow.png" rect:CGRectMake(0,0,10,1)];
	//MBackground *sBG = [MBackground sharedBG];
	MBackground *bg = [castle getBackground];
	[bg addChild:m_arrow z:3 tag:0];
	
	[m_arrow setPosition:CGPointMake(0.0, 160)];
	m_arrow.visible = TRUE;
}

- (void)Execute:(id)owner
{
	MCastle *tower = owner;
	CGPoint pt = [tower getTarget];
	
	float dx = pt.x - m_arrow.position.x;
	float dy = pt.y - m_arrow.position.y;
	
	dx = dx / 10;
	dy = dy / 10;

	NSLog(@"%f %f \n", dx, dy);

	[m_arrow setPosition:CGPointMake(m_arrow.position.x+dx, m_arrow.position.y+dy)];
	
	if((m_arrow.position.x < pt.x+8)&&(m_arrow.position.x > pt.x-8)&&
	   (m_arrow.position.y < pt.y+8)&&(m_arrow.position.y > pt.y-8))
	{
		[m_arrow setPosition:CGPointMake(0.0, 160)];
		MEWalkman *ewalkman = [tower getTargetUnit];
		if(ewalkman)
		{
			[ewalkman suffer:1];
		}
		m_arrow.visible = FALSE;
		[tower wait];
	}
}

- (void)Exit:(id)owner
{
	//CCSprite* sheet = owner;
	//[sheet removeChild:m_sprite cleanup:YES];
}

- (NSString*)name
{
	return @"MTowerAttack";
}

@end
