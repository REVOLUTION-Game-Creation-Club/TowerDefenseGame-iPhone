//
//  MEWalkWaitState.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 29..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MState.h"

@interface MEWalkWaitState : MState 
{
	float x,y;
	int	m_iCount;
}

@end
