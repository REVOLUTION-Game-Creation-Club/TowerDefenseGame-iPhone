//
//  MRightSlot.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 24..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@class MStyleButton1;
@class MStyleButton2;
@class MStyleButton3;
@class MStyleButton4;
@class MAttackDefenceButton;
@class MBackground;
@class MLeftSlot;

@interface MRightSlot : CCSprite <CCTargetedTouchDelegate>
{
	BOOL bFold;
	CCSprite* bar;
	
	MStyleButton1* style1;
	MStyleButton2* style2;
	MStyleButton3* style3;
	MStyleButton4* style4;
	MAttackDefenceButton* attackDefence;
	
	MBackground* m_background;
	MLeftSlot* m_leftSlot;
}

//+ (MRightSlot*)sharedRight;

-(void)initItem;

-(void)style1Produce:(int)percent;
-(void)style2Produce:(int)percent;
-(void)style3Produce:(int)percent;
-(void)style4Produce:(int)percent;
-(void)attackProduce:(int)percent;
-(void)defenceProduce:(int)percent;
-(void)fold;

-(void) setBackground:(MBackground*)bg;
-(void) setLeftSlot:(MLeftSlot*)slot;

@end