//
//  MEBowAttackState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 27..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MEBowAttackState.h"
#import "MEBowman.h"
#import "MBackground.h"

@implementation MEBowAttackState

- (id)init
{
	if( (self=[super init] )) 
	{
	}
	
	return self;
}

- (void)Enter:(id)owner
{
	MEBowman *bowman = owner;

	m_arrow = [CCSprite spriteWithFile:@"arrow.png" rect:CGRectMake(0,0,10,1)];
	MBackground* bg = [bowman getBackground];
	[bg addChild:m_arrow z:3 tag:0];		
	
	[m_arrow setPosition:CGPointMake(bowman.position.x, bowman.position.y)];
	m_arrow.visible = TRUE;
	m_iCount = 0;
	m_iAttackCount = 0;
	[bowman unvisibleAll];
}

- (void)Execute:(id)owner
{
	MEBowman *ebowman = owner;
	if(m_iCount==0)
	{
		[ebowman AttackAnimation];
	}
	m_iCount++;
	if(m_iCount == 60)
		m_iCount = 0;
	
	
	m_iAttackCount++;
	if(m_iAttackCount < 60)
		return;
	CGPoint pt = [ebowman getTarget];
	
	float dx = pt.x - m_arrow.position.x;
	float dy = pt.y - m_arrow.position.y;
	
	dx = dx / 10;
	dy = dy / 10;
	
//	NSLog(@"%f %f \n", dx, dy);
	[m_arrow setPosition:CGPointMake(m_arrow.position.x+dx, m_arrow.position.y+dy)];
	//	[m_sprite setPosition:CGPointMake(m_sprite.position.x+dx, 160)];
	[m_arrow setRotation:atan(dy/dx)*-180/3.14];
	
	[ebowman setRotation:atan(dy/dx)*-180/3.14];
	
	if((m_arrow.position.x < pt.x+8)&&(m_arrow.position.x > pt.x-8)&&
	   (m_arrow.position.y < pt.y+8)&&(m_arrow.position.y > pt.y-8))
	{
		[m_arrow setPosition:CGPointMake(ebowman.position.x, ebowman.position.y)];

		MUnit *enemy = [ebowman getTargetUnit];
		if(enemy)
		{
			[enemy suffer:1];
		}

		m_arrow.visible = FALSE;
		
		
		[ebowman wait];
	}	
}

- (void)Exit:(id)owner
{
	MEBowman *ebowman = owner;
	[ebowman unvisibleAll];
}

- (NSString*)name
{
	return @"MBowAttackState";
}

@end
