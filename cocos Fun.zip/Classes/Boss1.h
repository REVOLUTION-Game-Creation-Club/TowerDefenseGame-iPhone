//
//  Boss1.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 16..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MUnit.h"

@class MStateMachine;
@class MState;
@class Boss1MoveState;
@class Boss1AttackState;
@class Boss1DeathState;
//@class Boss1WaitState;
@class Boss1ChaseState;
@class MEWalkman;

@interface Boss1 : MUnit
{
	BOOL				m_bAlive;
	CGPoint				m_ptChasePoint;
	float				m_fRadius;
	float				m_fSight;
	int					m_iHPMax;
	
	CCSprite*			m_spriteWait[3];
	CCSprite*			m_spriteMove[8];
	CCSprite*			m_spriteAttack[3];
	CCSprite*			m_spriteDeath[4];
	
	CCSprite*			m_hpSprite[21];
	
	MStateMachine*			m_stateMachine;
	Boss1MoveState*			m_moveState;
	Boss1AttackState*		m_attackState;
	Boss1DeathState*		m_deathState;
//	Boss1WaitState*			m_waitState;
	Boss1ChaseState*		m_chaseState;
	
	MUnit*			m_target;
}

-(id) init;
-(void) update;
-(void) dealloc;

-(void) changeState:(MState*)new_state;
-(BOOL) isInRadius:(CGPoint)pt;
-(BOOL) isInSight:(CGPoint)pt;
-(void) chase:(CGPoint)pt;
-(void) attack;
-(void) suffer:(int)hp;
-(CGPoint) getChasePoint;

-(void) changeWaitState;

-(void) WaitAnimation;
-(void) MoveAnimation;
-(void) AttackAnimation;
-(void) DeathAnimation;

-(void) setFlipX:(BOOL)b;
-(void) wait;
-(void) go;
-(void) unvisibleAll;
-(NSString*) name;
-(void) setTargetUnit:(MUnit*)pt;
-(MUnit*) getTargetUnit;

-(void) setAlive:(BOOL)b;
-(BOOL) isAlive;
@end
