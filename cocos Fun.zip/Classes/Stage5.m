//
//  Stage5.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 22..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Stage5.h"
#import "MGameMain1.h"
#import "MStageData.h"

@implementation Stage5

- (void)onEnter
{
	[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
	[super onEnter];
}

- (void)onExit
{
	[[CCTouchDispatcher sharedDispatcher] removeDelegate:self];
	[super onExit];
}

- (CGRect)rect
{
	//	CGSize s = [self.texture contentSize];
	return CGRectMake(-14, -11, 28, 23);
}

- (BOOL)containsTouchLocation:(UITouch *)touch
{
	//NSLog(@"touch(%f,%f",pt.x, pt.y);
	
	return CGRectContainsPoint(self.rect, [self convertTouchToNodeSpaceAR:touch]);
}

- (NSString*)dataFilePath2
{
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	return [documentsDirectory stringByAppendingPathComponent:@"archive2"];
}

- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{
	if ( ![self containsTouchLocation:touch] ) return NO;
	
	[[SimpleAudioEngine sharedEngine] playEffect:@"dog.aiff"];
	CCScene *s4 = [CCScene node];
	
	MStageData* ud = [MStageData sharedStageData];
	
	NSMutableData *data2 = [[NSMutableData alloc] init];
	NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:data2];
	
	[archiver encodeInt:ud.m_iStage1Clear forKey:@"m_iStage1Clear"];
	[archiver encodeInt:ud.m_iStage2Clear forKey:@"m_iStage2Clear"];
	[archiver encodeInt:ud.m_iStage3Clear forKey:@"m_iStage3Clear"];
	[archiver encodeInt:ud.m_iStage4Clear forKey:@"m_iStage4Clear"];
	[archiver encodeInt:ud.m_iStage5Clear forKey:@"m_iStage5Clear"];
	[archiver encodeInt:ud.m_iStage6Clear forKey:@"m_iStage6Clear"];
	[archiver encodeInt:ud.m_iStage7Clear forKey:@"m_iStage7Clear"];
	[archiver encodeInt:5 forKey:@"m_iStageNum"];
	
	[archiver finishEncoding];
	[data2 writeToFile:[self dataFilePath2] atomically:YES];
	
	[archiver release];
	[data2 release];
	
	[s4 addChild:[MGameMain1 node]];
	[[CCDirector sharedDirector] replaceScene:[CCFlipXTransition transitionWithDuration:1 scene:s4]];

	return YES;	
}

@end
