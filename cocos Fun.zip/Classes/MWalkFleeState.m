//
//  MFleeState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 16..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MWalkFleeState.h"
#import "MWalkman.h"

@implementation MWalkFleeState

- (void)Enter:(id)owner
{
	m_iCount = 0;
	MWalkman *walkman = owner;
	[walkman unvisibleAll];
	[walkman MoveAnimation];
}

- (void)Execute:(id)owner
{	
	MWalkman *walkman = owner;
	if(m_iCount==0)
	{
		[walkman MoveAnimation];
	}
	m_iCount++;
	
	if(m_iCount == 30)
		m_iCount = 0;
	//
	
	CGPoint pt = [walkman getFleePoint];
	float dx = pt.x - walkman.position.x;
	float dy = pt.y - walkman.position.y;
	
	dx=dx/sqrt(dx*dx+dy*dy);
	dy=dy/sqrt(dx*dx+dy*dy);
	
	[walkman setPosition:CGPointMake(walkman.position.x-dx, walkman.position.y-dy)];
	
	if(![walkman isInRadius:CGPointMake(pt.x, pt.y)])
	{
		[walkman wait];
	}
}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"MWalkFleeState";
}

@end
