//
//  Boss2WaitState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 24..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Boss2WaitState.h"
#import "Boss2.h"

@implementation Boss2WaitState

- (void)Enter:(id)owner
{
	m_iCount = 0;
	
	x = 100;
	y = 480/2;
	
	Boss2* boss2 = owner;
	[boss2 unvisibleAll];
}

- (void)Execute:(id)owner
{
	Boss2 *boss2 = owner;
	if(m_iCount== 0)
	{
		[boss2 WaitAnimation];
	}
	m_iCount++;
	if(m_iCount == 30)
		m_iCount = 0;
	
	//
	
	Boss2* sprite = owner;
	
	if(( sprite.position.x > x-1)&&(sprite.position.y < y+1)&&
	   ( sprite.position.x < x+1)&&(sprite.position.y > y-1))
	{
		[sprite setFlipX:FALSE];
		[sprite setRotation:0];
		[sprite setPosition:CGPointMake(x, y)];
	}
	
	else 
	{
		float dx = x - sprite.position.x;
		float dy = y - sprite.position.y;
		
		dx=dx/sqrt(dx*dx+dy*dy);
		dy=dy/sqrt(dx*dx+dy*dy);
		if(dx <0)
		{
			[sprite setFlipX:TRUE];
		}
		
		[sprite setRotation:atan(dy/dx)*-180/3.14];
		[sprite setPosition:CGPointMake(sprite.position.x+dx, sprite.position.y+dy)];
	}
}

- (void)Exit:(id)owner
{
	
}

- (NSString*)name
{
	return @"Boss1WaitState";
}

@end
