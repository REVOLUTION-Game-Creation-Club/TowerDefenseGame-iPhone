//
//  State.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 11..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MState : NSObject
{
}

- (void)Enter:(id)owner;
- (void)Execute:(id)owner;
- (void)Exit:(id)owner;
- (NSString*)name;

@end

