//
//  METankMoveState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 27..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "METankMoveState.h"
#import "METank.h"

@implementation METankMoveState

- (void)Enter:(id)owner
{
}

- (void)Execute:(id)owner
{
	METank *tank = owner;
	if(m_iCount==0)
	{
		[tank MoveAnimation];
	}
	m_iCount++;
	
	if(m_iCount == 30)
		m_iCount = 0;
	
	//CGPoint pt = [sprite getPosition];
	METank* sprite = owner;
	
	float y = sprite.position.y;
	if(sprite.position.y >= (320 -sprite.contentSize.height/2))
	{
		y = 320 - sprite.contentSize.height/2;
	}
	
	[sprite setFlipX:TRUE];
	
	
	[sprite setRotation:0];
	[sprite setPosition:CGPointMake(sprite.position.x-0.33, y)];
}

- (void)Exit:(id)owner
{
	METank* tank = owner;
	[tank unvisibleAll];
}

- (NSString*)name
{
	return @"MMoveState";
}

@end
