//
//  MAttackDefenceButton.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 28..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface MAttackDefenceButton :  CCSpriteSheet <CCTargetedTouchDelegate> 
{
	CCSprite* m_sprite[8];
	BOOL	m_bAttack;
}

-(id) init;
-(void) attackProduce:(int)percent;
-(void) defenceProduce:(int)percent;

-(void)unvisibleAll;

@end
