//
//  MenuMain.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 3..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Menu.h"
#import "Title.h"
#import "MGameMain1.h"
#import "MStore.h"
#import "Manual1.h"
#import "Option.h"
#import "MCredit.h"
#import "StageSelect.h"
#import "MResult.h"
@implementation Menu



-(id)init
{
	if((self=[super init]))
	{
		CGSize s = [[CCDirector sharedDirector] winSize];
		
//		CCColorLayer *layer = [CCColorLayer layerWithColor:ccc4(0xFF,0xFF,0x00,0x80) width:s.width height:s.height];
		//layer.relativeAnchorPoint = YES;
//		layer.position = ccp(s.width/2,s.height/2);
//		[self addChild:layer z:-1];
		CCSprite* menuBG = [CCSprite spriteWithFile:@"menu.png" rect:CGRectMake(0,0,480,320)];
		menuBG.position = ccp(480/2,320/2);
		[self addChild:menuBG z:kTagBG];
		
//		CCLabel* label = [CCLabel labelWithString:@"메뉴 화면" fontName:@"Marker Felt" fontSize:32];
//		CGSize size = [[CCDirector sharedDirector] winSize];
//		label.position = ccp(size.width/2, size.height/2 + 100);
//		[self addChild:label z:1];

		CCSprite* menubarbg = [CCSprite spriteWithFile:@"menubarbg.png" rect:CGRectMake(0,0,168,198)];
		menubarbg.position = ccp(102,119);
		[self addChild:menubarbg z:1];
		CCSprite* menubar1 = [CCSprite spriteWithFile:@"menubar.png" rect:CGRectMake(0,0,164,34)];
		menubar1.position = ccp(102,196);
		[self addChild:menubar1 z:1];
		CCSprite* menubar2 = [CCSprite spriteWithFile:@"menubar.png" rect:CGRectMake(0,0,164,34)];
		menubar2.position = ccp(102,159);
		[self addChild:menubar2 z:1];
		CCSprite* menubar3 = [CCSprite spriteWithFile:@"menubar.png" rect:CGRectMake(0,0,164,34)];
		menubar3.position = ccp(102,119);
		[self addChild:menubar3 z:1];
		CCSprite* menubar4 = [CCSprite spriteWithFile:@"menubar.png" rect:CGRectMake(0,0,164,34)];
		menubar4.position = ccp(102,79);
		[self addChild:menubar4 z:1];
		CCSprite* menubar5 = [CCSprite spriteWithFile:@"menubar.png" rect:CGRectMake(0,0,164,34)];
		menubar5.position = ccp(102,39);
		[self addChild:menubar5 z:1];
		
		// 메뉴 아이콘을 생성한다. 이미지가 없으므로 텍스트로 버튼을 생성한다.
		CCMenuItemFont *item1 = [CCMenuItemFont itemFromString:@"START" target:self selector:@selector(cbMenu:)];
		//[item1 setFontSize:10];
		CCMenuItemFont *item2 = [CCMenuItemFont itemFromString:@"STORE" target:self selector:@selector(cbMenu:)];
		CCMenuItemFont *item3 = [CCMenuItemFont itemFromString:@"MANUAL" target:self selector:@selector(cbMenu:)];
		CCMenuItemFont *item4 = [CCMenuItemFont itemFromString:@"OPTION" target:self selector:@selector(cbMenu:)];
		CCMenuItemFont *item5 = [CCMenuItemFont itemFromString:@"CREDIT" target:self selector:@selector(cbMenu:)];
		
		CCMenu *menu = [CCMenu menuWithItems:item1, item2, item3, item4, item5, nil];
		[menu setPosition:ccp(s.width/2, s.height/2)];

		[item1 setPosition:ccp(-140,38)];
		[item2 setPosition:ccp(-140,-2)];
		[item3 setPosition:ccp(-140,-42)];
		[item4 setPosition:ccp(-140,-82)];
		[item5 setPosition:ccp(-140,-122)];
		
		item1.tag = 0;
		item2.tag = 1;
		item3.tag = 2;
		item4.tag = 3;
		item5.tag = 4;
		
		[self addChild:menu z:2];
		
		// 배경 음악 재생
		[[SimpleAudioEngine sharedEngine] playBackgroundMusic:@"glam.mp3"];
	}
	
	return self;
}

-(void)cbMenu:(id)sender
{
	switch([(CCMenuItemFont*)sender tag])
	{
		case 0: // 게임시작
			// 배경 음악 재생 중지
			//[[SimpleAudioEngine sharedEngine] pauseBackgroundMusic];
			// 효과음 재생
			
			[[SimpleAudioEngine sharedEngine] playEffect:@"dog.aiff"];
			CCScene *s0 = [CCScene node];
			
			[s0 addChild:[StageSelect node]];
			[[CCDirector sharedDirector] replaceScene:[CCFlipXTransition transitionWithDuration:1 scene:s0]];
			
/*
			[s0 addChild:[MGameMain node]];
			[[CCDirector sharedDirector] replaceScene:[CCFlipXTransition transitionWithDuration:1 scene:s0]];
*/
			/*
			CCScene *s0 = [CCScene node];
			
			[s0 addChild:[StageSelect node]];
			[[CCDirector sharedDirector] replaceScene:[CCFlipXTransition transitionWithDuration:1 scene:s0]];
			*/
			
			break;

		case 1: // store
			// 배경 음악 재생 중지
			//[[SimpleAudioEngine sharedEngine] pauseBackgroundMusic];
			// 효과음 재생
			
			[[SimpleAudioEngine sharedEngine] playEffect:@"dog.aiff"];
			CCScene *s1 = [CCScene node];
			[s1 addChild:[MStore node]];
			[[CCDirector sharedDirector] replaceScene:[CCFlipXTransition transitionWithDuration:1 scene:s1]];
			break;
		
		case 2: // manual
			//[[SimpleAudioEngine sharedEngine] pauseBackgroundMusic];
			// 효과음 재생
			[[SimpleAudioEngine sharedEngine] playEffect:@"dog.aiff"];
			CCScene *s2 = [CCScene node];
			
			[s2 addChild:[Manual1 node]];
			[[CCDirector sharedDirector] replaceScene:[CCFlipXTransition transitionWithDuration:1 scene:s2]];
			break;

		case 3: // option
			//[[SimpleAudioEngine sharedEngine] pauseBackgroundMusic];
			// 효과음 재생
			[[SimpleAudioEngine sharedEngine] playEffect:@"dog.aiff"];
			CCScene *s3 = [CCScene node];
			
			[s3 addChild:[Option node]];
			[[CCDirector sharedDirector] replaceScene:[CCFlipXTransition transitionWithDuration:1 scene:s3]];
			break;
		case 4: // credit
			//[[SimpleAudioEngine sharedEngine] pauseBackgroundMusic];
			// 효과음 재생
			[[SimpleAudioEngine sharedEngine] playEffect:@"dog.aiff"];
			CCScene *s4 = [CCScene node];
			
			[s4 addChild:[MCredit node]];
			[[CCDirector sharedDirector] replaceScene:[CCFlipXTransition transitionWithDuration:1 scene:s4]];
			break;
	}
}

@end
