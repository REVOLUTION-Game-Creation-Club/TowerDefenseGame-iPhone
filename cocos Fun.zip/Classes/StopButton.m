//
//  StopButton.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 21..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "StopButton.h"


@implementation StopButton

- (id)init
{
	if((self=[super init] ))
	{
		m_sprite = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(0,0,30,30)];
		[self addChild:m_sprite z:0 tag:0];
		m_sprite.visible = FALSE;
		
		m_spriteOn = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(30,0,30,30)];
		[self addChild:m_spriteOn z:0 tag:0];
		m_spriteOn.visible = TRUE;
		
		m_bPlay = TRUE;
	}
	
	return self;
}

- (void)onEnter
{
	[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
	[super onEnter];
}

- (void)onExit
{
	[[CCTouchDispatcher sharedDispatcher] removeDelegate:self];
	[super onExit];
}

- (CGRect)rect
{
	//	CGSize s = [self.texture contentSize];
	return CGRectMake(-14, -11, 28, 23);
}

- (BOOL)containsTouchLocation:(UITouch *)touch
{
	//NSLog(@"touch(%f,%f",pt.x, pt.y);
	
	return CGRectContainsPoint(self.rect, [self convertTouchToNodeSpaceAR:touch]);
}

- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{
	if ( ![self containsTouchLocation:touch] ) return NO;
		
	if(m_bPlay == TRUE)
	{
		m_sprite.visible = TRUE;
		m_spriteOn.visible = FALSE;
		m_bPlay = FALSE;
		
		[[CCDirector sharedDirector] pause];
	}
	else 
	{
		m_sprite.visible = FALSE;
		m_spriteOn.visible = TRUE;
		m_bPlay = TRUE;

		[[CCDirector sharedDirector] resume];
	}

	return YES;
}

@end
