//
//  MEHorseman.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 28..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MEHorseman.h"
#import "MStateMachine.h"
#import "MEHorseChaseState.h"
#import "MEHorseMoveState.h"
#import "MEHorseWaitState.h"
#import "MEHorseAttackState.h"


@implementation MEHorseman

-(id) init
{
	if( (self=[super init] )) 
	{
		m_iHealthPoint = 15; // 체력
		m_iHPMax = 15;
		
		m_iDepencePoint = 2; // 방어력
		m_iAttackPoint = 4; // 공격력
		m_fAttackSpeed = 1;	// 공격속도
		m_iPrice = 500; // 생산가격
		
		m_fRadius = 30;
		m_fSight = 150;
		
		
		m_spriteWait[0] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(0,0,50,50)];
		[self addChild:m_spriteWait[0] z:0 tag:0];
		m_spriteWait[1] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(50,0,50,50)];
		[self addChild:m_spriteWait[1] z:0 tag:0];
		m_spriteWait[2] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(100,0,50,50)];
		[self addChild:m_spriteWait[2] z:0 tag:0];
		m_spriteWait[3] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(150,0,50,50)];
		[self addChild:m_spriteWait[3] z:0 tag:0];
		
		m_spriteMove[0] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(0,50,50,50)];
		[self addChild:m_spriteMove[0] z:0 tag:0];
		m_spriteMove[1] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(50,50,50,50)];
		[self addChild:m_spriteMove[1] z:0 tag:0];
		m_spriteMove[2] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(100,50,50,50)];
		[self addChild:m_spriteMove[2] z:0 tag:0];
		m_spriteMove[3] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(150,50,50,50)];
		[self addChild:m_spriteMove[3] z:0 tag:0];
		
		m_spriteAttack[0] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(0,100,50,50)];
		[self addChild:m_spriteAttack[0] z:0 tag:0];
		m_spriteAttack[1] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(50,100,50,50)];
		[self addChild:m_spriteAttack[1] z:0 tag:0];
		m_spriteAttack[2] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(100,100,50,50)];
		[self addChild:m_spriteAttack[2] z:0 tag:0];
		m_spriteAttack[3] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(150,100,50,50)];
		[self addChild:m_spriteAttack[3] z:0 tag:0];
		
		m_spriteDeath[0] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(0,150,50,50)];
		[self addChild:m_spriteDeath[0] z:0 tag:0];
		m_spriteDeath[1] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(50,150,50,50)];
		[self addChild:m_spriteDeath[1] z:0 tag:0];
		m_spriteDeath[2] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(100,150,50,50)];
		[self addChild:m_spriteDeath[2] z:0 tag:0];
		m_spriteDeath[3] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(150,150,50,50)];
		[self addChild:m_spriteDeath[3] z:0 tag:0];
		
		[self unvisibleAll];		
		
		for(int i = 0; i <21; i++)
		{
			m_hpSprite[i] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(0,150+2*i,20,2)];
			[m_hpSprite[i] setPosition:CGPointMake(0, 20)];
			[self addChild:m_hpSprite[i] z:1 tag:0];
			m_hpSprite[i].visible = FALSE;
		}
		
		m_hpSprite[0].visible = TRUE;
		
		
		m_stateMachine = [[MStateMachine alloc] init];
		[m_stateMachine setOwner:self];
		m_waitState = [[MEHorseWaitState alloc] init];
		m_attackState = [[MEHorseAttackState alloc] init];
		m_chaseState = [[MEHorseChaseState alloc] init];
		m_moveState = [[MEHorseMoveState alloc] init];
		[m_waitState Enter:self];
		[m_stateMachine setCurrentState:m_waitState];
	}
	return self;
}

-(void) unvisibleAll
{
	for(int i = 0; i <4; i++)
	{
		m_spriteWait[i].visible = FALSE;
	}
	for(int i = 0; i <4; i++)
	{
		m_spriteMove[i].visible = FALSE;
	}
	for(int i = 0; i <4; i++)
	{
		m_spriteAttack[i].visible = FALSE;
	}
	for(int i = 0; i <4; i++)
	{
		m_spriteDeath[i].visible = FALSE;
	}
}

-(void) update
{	
	NSLog(@"%d\n",m_iHealthPoint);
	[m_stateMachine update];
}

- (void) dealloc
{
	[m_attackState release];
	[m_waitState release];
	[m_stateMachine release];
	
	[super dealloc];
}

-(void) changeState:(MState*)new_state
{
	[m_stateMachine changeState:new_state];
}

-(BOOL) isInRadius:(CGPoint)pt
{
	float dx = pt.x - self.position.x;
	float dy = pt.y - self.position.y;
	
	if(sqrt(dx*dx+dy*dy) < m_fRadius)
		return TRUE;
	
	return FALSE;
}

-(BOOL) isInSight:(CGPoint)pt
{
	float dx = pt.x - self.position.x;
	float dy = pt.y - self.position.y;
	
	if(sqrt(dx*dx+dy*dy) < m_fSight)
		return TRUE;
	
	return FALSE;
}

- (void)wait
{
	[self changeState:m_waitState];
}

- (void)attack
{
	[self changeState:m_attackState];
}

-(void) chase:(CGPoint)pt
{
	m_ptChasePoint = pt;
	[self changeState:m_chaseState];
}

-(void) WaitAnimation
{
	static int count = 0;
	
	for(int i = 0; i <4; i++)
	{
		if(i == count)
		{
			m_spriteWait[i].visible = TRUE;
		}
		else 
		{
			m_spriteWait[i].visible = FALSE;
		}
	}
	
	count++;
	if(count == 4)
		count = 0;
}

-(void) MoveAnimation
{
	static int count = 0;
	
	for(int i = 0; i <4; i++)
	{
		if(i == count)
		{
			m_spriteMove[i].visible = TRUE;
		}
		else 
		{
			m_spriteMove[i].visible = FALSE;
		}
	}
	
	count++;
	if(count == 4)
		count = 0;
}

-(void) AttackAnimation
{
	static int count = 0;
	
	for(int i = 0; i <4; i++)
	{
		if(i == count)
		{
			m_spriteAttack[i].visible = TRUE;
		}
		else 
		{
			m_spriteAttack[i].visible = FALSE;
		}
	}
	
	count++;
	if(count == 4)
		count = 0;
}

-(void) DeathAnimation
{
	static int count = 0;
	
	for(int i = 0; i <4; i++)
	{
		if(i == count)
		{
			m_spriteDeath[i].visible = TRUE;
		}
		else 
		{
			m_spriteDeath[i].visible = FALSE;
		}
	}
	
	count++;
	if(count == 4)
		count = 0;
}

-(CGPoint) getChasePoint
{
	return m_ptChasePoint;
}


-(void) setFlipX:(BOOL)b
{
	for(int i = 0; i <4; i++)
	{
		[m_spriteWait[i] setFlipX:b];
	}
	for(int i = 0; i <4; i++)
	{
		[m_spriteMove[i] setFlipX:b];
	}
	for(int i = 0; i <4; i++)
	{
		[m_spriteAttack[i] setFlipX:b];
	}
	for(int i = 0; i <4; i++)
	{
		[m_spriteDeath[i] setFlipX:b];
	}
}

-(void) suffer:(int)hp
{
	m_iHealthPoint--;
	int h = m_iHealthPoint*20.0/(float)m_iHPMax;
	
	for(int i = 1; i < 21; i++)
	{
		if( i == h)
		{
			m_hpSprite[20-i].visible = TRUE;
		}
		else 
		{
			m_hpSprite[20-i].visible = FALSE;
		}
	}
}

-(void) dead
{
	for(int i = 0; i <4; i++)
	{
		[self removeChild:m_spriteWait[i] cleanup:YES];
	}
	for(int i = 0; i <4; i++)
	{
		[self removeChild:m_spriteMove[i] cleanup:YES];
	}
	for(int i = 0; i <4; i++)
	{
		[self removeChild:m_spriteAttack[i] cleanup:YES];
	}
	for(int i = 0; i <4; i++)
	{
		[self removeChild:m_spriteDeath[i] cleanup:YES];
	}
}


-(void) changeWaitState
{
	[m_stateMachine changeState:m_waitState];
}

-(void) go
{
	[self changeState:m_moveState];
}

-(void) setTargetUnit:(MUnit*)pt
{
	m_target = pt;
}

-(MUnit*) getTargetUnit
{
	return m_target;
}

@end
