//
//  MoveState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 11..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MWalkMoveState.h"
#import "MWalkman.h"

@implementation MWalkMoveState

- (void)Enter:(id)owner
{
	m_iCount = 0;
	MWalkman* walkman = owner;
	[walkman unvisibleAll];
}

- (void)Execute:(id)owner
{
	MWalkman *walkman = owner;
	if(m_iCount==0)
	{
		[walkman MoveAnimation];
	}
	m_iCount++;
	
	if(m_iCount == 30)
		m_iCount = 0;
	//
	
	//CGPoint pt = [sprite getPosition];
	
	float y = walkman.position.y;
	if(walkman.position.y >= (320 -walkman.contentSize.height/2))
	{
		y = 320 - walkman.contentSize.height/2;
	}
	
	[walkman setFlipX:FALSE];
	

	[walkman setRotation:0];
	[walkman setPosition:CGPointMake(walkman.position.x+0.33, y)];
}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"MWalkMoveState";
}

@end
