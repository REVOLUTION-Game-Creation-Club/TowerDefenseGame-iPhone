//
//  MGameMain2.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 23..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@class MBackground;
@class QuickButton1;
@class QuickButton2;
@class QuickButton3;

enum {
    kTagBG = 0,
    kTagChar = 1,
    kTagUI = 2,
};

@interface MGameMain2 : CCColorLayer 
{
	CCSprite *moneyImg;
	CCLabel *moneyLabel;
	CCSprite *stageImg;
	CCLabel *stageLabel;
	
	QuickButton1 *quick1;
	QuickButton2 *quick2;
	QuickButton3 *quick3;
	
	int m_skillAnimation1;
	int m_skillAnimation2;
	int m_skillAnimation3;	
}

@property (nonatomic, retain) CCLabel *moneyLabel;
@property (nonatomic, retain) CCLabel *stageLabel;

+(id) scene;
+ (MGameMain2*)sharedGM;
-(void) closeGameMain;
-(void) setGameStageNumber:(int)num;

@end
