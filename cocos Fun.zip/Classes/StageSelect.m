//
//  StageSelect.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 22..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "StageSelect.h"
#import "Stage1.h"
#import "Stage2.h"
#import "Stage3.h"
#import "Stage4.h"
#import "Stage5.h"
#import "Stage6.h"
#import "Stage7.h"
#import "Flag1.h"
#import "Flag2.h"
#import "Flag3.h"
#import "Flag4.h"
#import "Flag5.h"
#import "Flag6.h"
#import "Flag7.h"
#import "MStageData.h"

@implementation StageSelect

-(id)init
{
	if((self=[super init]))
	{
		//CGSize s = [[CCDirector sharedDirector] winSize];
		MStageData* ud = [MStageData sharedStageData];
		
		NSMutableData *data2 = [[NSMutableData alloc] init];
		NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:data2];
		[archiver encodeBool:FALSE forKey:@"m_iStage1Clear"];
		[archiver encodeBool:FALSE forKey:@"m_iStage2Clear"];
		[archiver encodeBool:FALSE forKey:@"m_iStage3Clear"];
		[archiver encodeBool:FALSE forKey:@"m_iStage4Clear"];	
		[archiver encodeBool:FALSE forKey:@"m_iStage5Clear"];
		[archiver encodeBool:FALSE forKey:@"m_iStage6Clear"];
		[archiver encodeBool:FALSE forKey:@"m_iStage7Clear"];
		
		[archiver encodeInt:1 forKey:@"m_iStageNum"];
		
		[archiver finishEncoding];
		[data2 writeToFile:[self dataFilePath2] atomically:YES];
		[archiver release];
		[data2 release];

		///////////////////////////
		CCSprite* menuBG = [CCSprite spriteWithFile:@"stageSelect.png" rect:CGRectMake(0,0,480,320)];
		menuBG.position = ccp(480/2,320/2);
		[self addChild:menuBG z:0];

		Stage1* castle01 = [Stage1 spriteWithFile:@"fc01.png" rect:CGRectMake(0,0,64,64)];
		castle01.position = ccp(99,177);
		[self addChild:castle01 z:0];

		Stage2* castle02 = [Stage2 spriteWithFile:@"fc02.png" rect:CGRectMake(0,0,64,64)];
		castle02.position = ccp(193,177);
		[self addChild:castle02 z:0];

		Stage3* castle03 = [Stage3 spriteWithFile:@"fc03.png" rect:CGRectMake(0,0,64,64)];
		castle03.position = ccp(287,177);
		[self addChild:castle03 z:0];

		Stage4* castle04 = [Stage4 spriteWithFile:@"fc04.png" rect:CGRectMake(0,0,64,64)];
		castle04.position = ccp(387,177);
		[self addChild:castle04 z:0];

		Stage5* castle05 = [Stage5 spriteWithFile:@"fc05.png" rect:CGRectMake(0,0,64,64)];
		castle05.position = ccp(146,62);
		[self addChild:castle05 z:0];

		Stage6* castle06 = [Stage6 spriteWithFile:@"fc06.png" rect:CGRectMake(0,0,64,64)];
		castle06.position = ccp(240,62);
		[self addChild:castle06 z:0];

		Stage7* castle07 = [Stage7 spriteWithFile:@"fc07.png" rect:CGRectMake(0,0,64,64)];
		castle07.position = ccp(334,62);
		[self addChild:castle07 z:0];

		Flag1* flag01 = [[Flag1 spriteSheetWithFile:@"flag01-all.png" capacity:10]init];
		flag01.position = ccp(101+46,232-20);
		[self addChild:flag01 z:0];

		Flag2* flag02 = [[Flag2 spriteSheetWithFile:@"flag02-all.png" capacity:10]init];
		flag02.position = ccp(195+46,232-20);
		[self addChild:flag02 z:0];

		Flag3* flag03 = [[Flag3 spriteSheetWithFile:@"flag03-all.png" capacity:10]init];
		flag03.position = ccp(289+46,232-20);
		[self addChild:flag03 z:0];

		Flag4* flag04 = [[Flag4 spriteSheetWithFile:@"flag04-all.png" capacity:10]init];
		flag04.position = ccp(383+46,232-20);
		[self addChild:flag04 z:0];
		
		Flag5* flag05 = [[Flag5 spriteSheetWithFile:@"flag05-all.png" capacity:10]init];
		flag05.position = ccp(148+46,117-20);
		[self addChild:flag05 z:0];
		
		Flag6* flag06 = [[Flag6 spriteSheetWithFile:@"flag06-all.png" capacity:10]init];
		flag06.position = ccp(242+46,117-20);
		[self addChild:flag06 z:0];

		Flag7* flag07 = [[Flag7 spriteSheetWithFile:@"flag07-all.png" capacity:10]init];
		flag07.position = ccp(336+46,117-20);
		[self addChild:flag07 z:0];

		
		MStageData* ud1 = [MStageData sharedStageData];
		
		NSData *data21 = [[NSMutableData alloc] initWithContentsOfFile:[self dataFilePath2]];
		NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:data21];
		
		ud1.m_iStage1Clear = [unarchiver decodeBoolForKey:@"m_iStage1Clear"];
		ud1.m_iStage2Clear = [unarchiver decodeBoolForKey:@"m_iStage2Clear"];
		ud1.m_iStage3Clear = [unarchiver decodeBoolForKey:@"m_iStage3Clear"];
		ud1.m_iStage4Clear = [unarchiver decodeBoolForKey:@"m_iStage4Clear"];
		ud1.m_iStage5Clear = [unarchiver decodeBoolForKey:@"m_iStage5Clear"];
		ud1.m_iStage6Clear = [unarchiver decodeBoolForKey:@"m_iStage6Clear"];
		ud1.m_iStage7Clear = [unarchiver decodeBoolForKey:@"m_iStage7Clear"];

		ud1.m_iStageNum = [unarchiver decodeIntForKey:@"m_iStageNum"];

		[unarchiver finishDecoding];
		
		[unarchiver release];
		[data21 release];
		
		
		if(ud1.m_iStage1Clear == TRUE)
		{
			[flag01 setClear:TRUE];
		}
		if(ud1.m_iStage2Clear == TRUE)
		{
			[flag02 setClear:TRUE];
		}
		if(ud1.m_iStage3Clear == TRUE)
		{
			[flag03 setClear:TRUE];
		}
		if(ud1.m_iStage4Clear == TRUE)
		{
			[flag04 setClear:TRUE];
		}
		if(ud1.m_iStage5Clear == TRUE)
		{
			[flag05 setClear:TRUE];
		}
		if(ud1.m_iStage6Clear == TRUE)
		{
			[flag06 setClear:TRUE];
		}
		if(ud1.m_iStage7Clear == TRUE)
		{
			[flag07 setClear:TRUE];
		}
	}
	
	return self;
}

- (NSString*)dataFilePath2
{
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	return [documentsDirectory stringByAppendingPathComponent:@"archive2"];
}

@end
