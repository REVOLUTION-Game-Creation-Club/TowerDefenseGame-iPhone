//
//  Tank.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 11..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MUnit.h"
#import "MBackground.h"

@implementation MUnit

//@synthesize m_iHealthPoint;

-(id) init
{
	if( (self=[super init] )) 
	{
		m_iHealthPoint = 0; // 체력
		m_iDepencePoint = 0; // 방어력
		m_iAttackPoint = 0; // 공격력
		m_fAttackSpeed = 0;	// 공격속도
		m_iPrice = 0; // 생산가격
		
		// 업그레이드 레벨
		m_iHealthLevel = 0;
		m_iDepenceLevel = 0;
		m_iAttackLevel = 0;
		m_iAttackSpeedLevel = 0;
		m_iSpeedLevel = 0;
		m_formation = STYLE_1;
	}
	return self;
}

-(void) update
{
}

-(void) setID:(int)id1
{
	m_iID = id1;
}

-(int) getID
{
	return m_iID;
}

-(void) setHP:(int)hp
{
	m_iHealthPoint = hp;
}

-(int) getHP
{
	return m_iHealthPoint;
}

-(void)setFormation:(int)type
{
	m_formation = type;
}

-(int)getFormation
{
	return m_formation;
}

-(BOOL) isInRadius:(CGPoint)pt
{
	return FALSE;
}

-(BOOL) isInSight:(CGPoint)pt
{
	return FALSE;
}

-(void) attack
{
}

-(void) suffer:(int)hp
{
}

-(void) dead
{
}

-(void) go
{
}
-(void) setTargetUnit:(MUnit*)pt
{
}
-(void) chase:(CGPoint)pt
{
}
/*
-(void) spriteWithFile:(NSString*)filename rect:(CGRect)rect index:(NSUInteger)i
{
	[m_ccSprite[i] spriteWithFile:filename rect:rect];
}
*/
/*
-(void) setPosition:(CGPoint)pt
{
	for(int i = 0; i < 2; i++)
	{
		m_sprite[i].position = pt;
	}
}
 */
@end
