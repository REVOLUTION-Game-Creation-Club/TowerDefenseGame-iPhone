//
//  MEWalkAttackState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 27..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MEWalkAttackState.h"
#import "MEWalkman.h"
#
@implementation MEWalkAttackState

- (void)Enter:(id)owner
{
	m_iCount = 0;
	MEWalkman *walkman = owner;
	[walkman unvisibleAll];
}

- (void)Execute:(id)owner
{
	MEWalkman *walkman = owner;
	if(m_iCount == 0)
	{
		[walkman AttackAnimation];
	}
	m_iCount++;	
	
	if(m_iCount == 30)
	{
		m_iCount = 0;
		MUnit *enemy = [walkman getTargetUnit];
		if(enemy)
		{
			[enemy suffer:1];
		}
	}
}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"MWalkAttackState";
}

@end
