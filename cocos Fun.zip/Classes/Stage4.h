//
//  Stage4.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 22..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface Stage4 : CCSprite <CCTargetedTouchDelegate> 
{

}

@end
