//
//  Boss5ChaseState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 24..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Boss5ChaseState.h"
#import "Boss5.h"

@implementation Boss5ChaseState

- (void)Enter:(id)owner
{
	//rot = 0;
	m_iCount = 0;
	Boss5 *boss5 = owner;
	[boss5 unvisibleAll];
}

- (void)Execute:(id)owner
{
	Boss5 *boss5 = owner;
	if(m_iCount == 0)
	{
		[boss5 MoveAnimation];
	}
	m_iCount++;
	
	if(m_iCount == 30)
		m_iCount = 0;
	
	CGPoint pt = [boss5 getChasePoint];
	
	float dx = pt.x - boss5.position.x;
	float dy = pt.y - boss5.position.y;
	
	dx=dx/sqrt(dx*dx+dy*dy);
	dy=dy/sqrt(dx*dx+dy*dy);
	if(dx <0)
	{
		[boss5 setFlipX:FALSE];
	}
	//rot = rot+10;
	//NSLog(@"%f\n",rot);
	//[walkman setAnchorPoint:CGPointMake(0.25, 0.75)];
	//[walkman setRotation:180];
	[boss5 setRotation:atan(dy/dx)*-180/3.14];
	[boss5 setPosition:CGPointMake(boss5.position.x+dx, boss5.position.y+dy)];	
}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"Boss5ChaseState";
}

@end
