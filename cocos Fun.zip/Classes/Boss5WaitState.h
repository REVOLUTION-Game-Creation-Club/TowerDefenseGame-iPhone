//
//  Boss5WaitState.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 24..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MState.h"

@interface Boss5WaitState : MState 
{
	float x,y;
	int	m_iCount;
}

@end
