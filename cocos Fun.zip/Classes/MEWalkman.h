//
//  MEWalkman.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 22..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MUnit.h"

@class MStateMachine;
@class MState;
@class MEWalkMoveState;
@class MEWalkAttackState;
@class MEWalkDeathState;
@class MEWalkWaitState;
@class MEWalkChaseState;
@class MEProduceState;

@interface MEWalkman : MUnit
{
	BOOL				m_bDeath;
	CGPoint				m_ptFace;
	CGPoint				m_ptFleePoint;
	CGPoint				m_ptChasePoint;
	float				m_fRadius;
	float				m_fSight;
	int					m_iHPMax;

	CCSprite*			m_spriteWait[5];
	CCSprite*			m_spriteMove[4];
	CCSprite*			m_spriteAttack[7];
	CCSprite*			m_spriteDeath[4];
	
	CCSprite*			m_hpSprite[21];
	
	MStateMachine*		m_stateMachine;
	MEWalkMoveState*		m_moveState;
	MEWalkAttackState*		m_attackState;
	MEWalkDeathState*		m_deathState;
	MEWalkWaitState*		m_waitState;
	MEWalkChaseState*		m_chaseState;
	
	MUnit*			m_target;
}

-(id) init;
-(void) update;
-(void) dealloc;

-(void) changeState:(MState*)new_state;
-(BOOL) isInRadius:(CGPoint)pt;
-(BOOL) isInSight:(CGPoint)pt;
-(void) chase:(CGPoint)pt;
-(void) attack;
-(void) suffer:(int)hp;
-(CGPoint) getFleePoint;
-(CGPoint) getChasePoint;
-(void) setDeath:(BOOL)bDeath;
-(BOOL) getDeath;
-(void) changeWaitState;

-(void) WaitAnimation;
-(void) MoveAnimation;
-(void) AttackAnimation;
-(void) DeathAnimation;

-(void) dead;
-(void) setFlipX:(BOOL)b;
-(void) unvisibleAll;

-(void) wait;
-(void) go;

-(void) setTargetUnit:(MUnit*)pt;
-(MUnit*) getTargetUnit;

@end

