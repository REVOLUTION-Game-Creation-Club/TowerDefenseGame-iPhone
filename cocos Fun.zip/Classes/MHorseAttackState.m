//
//  MHorseAttackState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 21..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MHorseAttackState.h"
#import "MHorseman.h"

@implementation MHorseAttackState

- (void)Enter:(id)owner
{
	m_iCount = 0;	
}

- (void)Execute:(id)owner
{
	MHorseman *horseman = owner;
	if(m_iCount==0)
	{
		[horseman AttackAnimation];
	}
	m_iCount++;
	
	if(m_iCount == 30)
		m_iCount = 0;
	
	MUnit *enemy = [horseman getTargetUnit];
	if(enemy)
	{
		[enemy suffer:1];
	}
	else 
	{
		[horseman go];
	}
}

- (void)Exit:(id)owner
{

}

- (NSString*)name
{
	return @"MHorseAttackState";
}

@end
