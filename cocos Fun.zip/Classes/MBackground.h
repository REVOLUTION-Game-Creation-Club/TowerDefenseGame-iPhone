//
//  Background.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 7..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

enum UNIT_TYPE
{
	UNIT_WALK = 0,
	UNIT_BOW = 1,
	UNIT_HORSE = 2,
	UNIT_TANK = 3,
	UNIT_BOSS = 4,
	UNIT_MAX,
};

enum STYLE_TYPE
{
	STYLE_NO = 0,
	STYLE_1 = 1,
	STYLE_2 = 2,
	STYLE_3 = 3,
	STYLE_4 = 4,
	STYLE_MAX,
};

@class MCastle;
@class MECastle;

@class Boss1;
@class Boss2;
@class Boss3;
@class Boss4;
@class Boss5;
@class Boss6;
@class Boss7;
@class MGameMain1;
@class MLeftSlot;
@class MRightSlot;
@class MUnit;

@interface MBackground : CCSprite <CCTargetedTouchDelegate>
{
	CGPoint firstPos;
	BOOL firstMove;
	
	NSMutableArray *m_vUnitArray[UNIT_MAX];
	NSMutableArray *m_vEUnitArray[UNIT_MAX];
//	NSMutableArray *m_vEraseArray;
	
	int money;
	MCastle *m_castle;
	MECastle *m_eCastle;

	Boss1 *boss1;
	Boss2 *boss2;
	Boss3 *boss3;
	Boss4 *boss4;
	Boss5 *boss5;
	Boss6 *boss6;
	Boss7 *boss7;
	
	int m_style;
	int m_styleAnimation1;
	int m_styleAnimation2;
	int m_styleAnimation3;
	int m_styleAnimation4;
	int m_attackAnimation;
	int m_defenceAnimation;
	
	int m_enemyStyle;
	
	BOOL m_bEndGame;
	
	MGameMain1 *m_gameMain;

	MLeftSlot *m_leftSlot;
	MRightSlot *m_rightSlot;
	
	int m_iWalkKill;
	int m_iBowKill;
	int m_iHorseKill;
	int m_iTankKill;
	int m_iBossKill;
}


@property(nonatomic, readonly) CGRect rect;

//+ (MBackground*)sharedBG;
-(void) produceMyWalkman;
-(void) produceEnemyWalkman;
-(BOOL) reduceMoney:(int)m;
-(void) produceBoss1;
-(void) produceMyBowman;
-(void) produceMyHorseman;
-(void) produceMyTank;
-(void) produceEnemyBowman;
-(void) produceEnemyHorseman;
-(void) produceEnemyTank;

-(void) setStyle:(int)style;
-(void) setEnemyStyle:(int)style;

-(void) setStyleAnim:(int)type;

-(void) setAttackAnim;
-(void) setDefenceAnim;

-(void) setAttack;
-(void) setDefence;

-(void) setEnemyAttack;
-(void) setEnemyDefence;

-(BOOL) isEndGame;
-(void) resetGame;
-(void) setGameMain:(MGameMain1*)gm;
-(void) setLeftSlot:(MLeftSlot*)slot;
-(void) setRightSlot:(MRightSlot*)slot;

-(MUnit*)getEnemyInRadius:(MUnit*)myUnit;
-(MUnit*)getEnemyInSight:(MUnit*)myUnit;

-(void) produceBoss1;
-(void) produceBoss2;
-(void) produceBoss3;
-(void) produceBoss4;
-(void) produceBoss5;
-(void) produceBoss6;
-(void) produceBoss7;


-(int) getiWalkKill;
-(int) getiBowKill;
-(int) getiHorseKill;
-(int) getiTankKill;
-(int) getiBossKill;
-(int) getiCastleHP;
-(int) getMoney;

@end
