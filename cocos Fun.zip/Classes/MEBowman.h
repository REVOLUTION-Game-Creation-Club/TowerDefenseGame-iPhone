//
//  MEBowman.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 28..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MUnit.h"

@class MEBowWaitState;
@class MStateMachine;
@class MEBowMoveState;
@class MEBowAttackState;
@class MEBowMoveState;
@class MState;
@class MEWalkman;
@class MBackground;

@interface MEBowman : MUnit
{
	CCSprite*			m_spriteWait[5];
	CCSprite*			m_spriteMove[4];
	CCSprite*			m_spriteAttack[5];
	CCSprite*			m_spriteDeath[4];
	
	CCSprite*			m_hpSprite[21];
	float				m_fRadius;
	float				m_fSight;
	int					m_iHPMax;
	MStateMachine*		m_stateMachine;
	MEBowWaitState*		m_waitState;
	MEBowMoveState*		m_moveState;
	MEBowAttackState*	m_attackState;
	MUnit*				m_target;
	CGPoint				m_ptTarget;	
	
	MBackground*		m_background;	
}

-(id) init;
-(void) update;
-(void) dealloc;

-(void) changeState:(MState*)new_state;
-(BOOL) isInRadius:(CGPoint)pt;
-(BOOL) isInSight:(CGPoint)pt;

-(void) setTarget:(CGPoint)pt;
-(CGPoint) getTarget;

-(void)setTargetUnit:(MUnit*)enemy;
- (MUnit*)getTargetUnit;
- (void)wait;
- (void)attack;

-(void) WaitAnimation;
-(void) MoveAnimation;
-(void) AttackAnimation;
-(void) DeathAnimation;

-(void) setFlipX:(BOOL)b;
-(void) unvisibleAll;

-(void) changeWaitState;
-(NSString*) getStateName;
-(void) suffer:(int)hp;

-(void) wait;
-(void) go;

-(void) setBackground:(MBackground*)bg;
-(MBackground*)getBackground;

@end
