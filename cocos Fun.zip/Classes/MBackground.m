//
//  Background.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 7..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MBackground.h"
#import "MWalkman.h"
#import "MCastle.h"
#import "MBowman.h"
#import "MHorseman.h"
#import "MEWalkman.h"
#import "MTank.h"
#import "MRightSlot.h"
#import "MECastle.h"
#import "MEBowman.h"
#import "MEHorseman.h"
#import "METank.h"

#import "Boss1.h"
#import "Boss2.h"
#import "Boss3.h"
#import "Boss4.h"
#import "Boss5.h"
#import "Boss6.h"
#import "Boss7.h"

#import "MResult.h"
#import "MGameMain1.h"

@implementation MBackground

/*
static MBackground* g_sharedBG = nil;

+ (MBackground*)sharedBG 
{
	if (!g_sharedBG)
		g_sharedBG = [MBackground spriteWithFile:@"map.png"];
	
	return g_sharedBG;
}
*/
- (CGRect)rect
{
	CGSize s = [self.texture contentSize];
	return CGRectMake(-s.width/2, -s.height/2, s.width,s.height);
}

- (void)onEnter
{
	[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
	[super onEnter];

	
	m_castle = [[MCastle spriteSheetWithFile:@"castle.png" capacity:15]init];
	[m_castle setBackground:self];
	m_castle.position = ccp(29, 160);
	[self addChild:m_castle z:0];
	
	m_eCastle = [[MECastle spriteSheetWithFile:@"ecastle.png" capacity:15]init];
	[m_eCastle setBackground:self];
	m_eCastle.position = ccp(960-15, 160);
	[self addChild:m_eCastle z:0];
	

	m_vUnitArray[UNIT_TANK] = [[NSMutableArray alloc] initWithCapacity:30];
	m_vUnitArray[UNIT_HORSE] = [[NSMutableArray alloc] initWithCapacity:30];
	m_vUnitArray[UNIT_BOW] = [[NSMutableArray alloc] initWithCapacity:30];
	m_vUnitArray[UNIT_WALK] = [[NSMutableArray alloc] initWithCapacity:30];

	m_vEUnitArray[UNIT_TANK] = [[NSMutableArray alloc] initWithCapacity:30];
	m_vEUnitArray[UNIT_HORSE] = [[NSMutableArray alloc] initWithCapacity:30];
	m_vEUnitArray[UNIT_BOW] = [[NSMutableArray alloc] initWithCapacity:30];
	m_vEUnitArray[UNIT_WALK] = [[NSMutableArray alloc] initWithCapacity:30];
	m_vEUnitArray[UNIT_BOSS] = [[NSMutableArray alloc] initWithCapacity:30];
	
	money = 500;
	
	m_style = STYLE_1;
	m_styleAnimation1 = 0;
	m_styleAnimation2 = 0;
	m_styleAnimation3 = 0;
	m_styleAnimation4 = 0;
	
	m_attackAnimation = 0;
	m_defenceAnimation = 0;
	
	m_enemyStyle = STYLE_1;
	
	m_iWalkKill = 0;
	m_iBowKill = 0;
	m_iHorseKill = 0;
	m_iTankKill = 0;
	m_iBossKill = 0;
	
	[self schedule:@selector(styleAnim:) interval:0.25];
	[self schedule:@selector(makeMoney:) interval:1.0];
	[self schedule:@selector(enemyLogic:) interval:30.0];
	[self schedule:@selector(charMove:) interval:1.0/60.0];
	
}
-(void)enemyLogicState1
{
	static int count = 0;
	
	switch (count) 
	{
			//1
		case 0:
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			count++;
			break;
		case 1:
			[self setEnemyAttack];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			count++;
			break;
		case 2:
			[self setEnemyAttack];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			count++;
			break;
		case 3:
			[self setEnemyAttack];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			count++;
			break;
		case 4:
			[self produceBoss1];
			[self setEnemyAttack];			
			count= -1;
			break;
	}
}

-(void)enemyLogicState2
{
	static int count = 0;
	
	switch (count) 
	{
			//1
		case 0:
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyHorseman];
			count++;
			break;
		case 1:
			[self setEnemyAttack];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyHorseman];
			count++;
			break;
		case 2:
			[self setEnemyAttack];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyHorseman];
			count++;
			break;
		case 3:
			[self setEnemyAttack];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyHorseman];
			count++;
			break;
		case 4:
			[self setEnemyAttack];
			[self produceBoss2];
			count= -1;
			break;
			
	}
}

-(void)enemyLogicState3
{
	static int count = 0;
	
	switch (count) 
	{
			//1
		case 0:
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyHorseman];
			count++;
			break;
		case 1:
			[self setEnemyAttack];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyHorseman];
			[self produceEnemyTank];
			count++;
			break;
		case 2:
			[self setEnemyAttack];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyHorseman];
			count++;
			break;
		case 3:
			[self setEnemyAttack];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyHorseman];
			count= -1;
			break;
		case 4:
			[self produceBoss3];
			[self setEnemyAttack];
			break;
	}
}

-(void)enemyLogicState4
{
	static int count = 0;
	
	switch (count) 
	{
			//1
		case 0:
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyHorseman];
			[self produceEnemyHorseman];
			count++;
			break;
		case 1:
			[self setEnemyAttack];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyHorseman];
			[self produceEnemyHorseman];
			[self produceEnemyTank];
			[self produceBoss2];
			count++;
			break;
		case 2:
			[self setEnemyAttack];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyHorseman];
			[self produceEnemyHorseman];
			count++;
			break;
		case 3:
			[self setEnemyAttack];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyHorseman];
			[self produceEnemyHorseman];
			count++;
			break;
		case 4:
			[self produceBoss4];
			[self setEnemyAttack];
			count= -1;
			break;
			
	}
}

-(void)enemyLogicState5
{
	static int count = 0;
	
	switch (count) 
	{
			//1
		case 0:
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyHorseman];
			[self produceEnemyHorseman];
			count++;
			break;
		case 1:
			[self setEnemyAttack];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyHorseman];
			[self produceEnemyHorseman];
			[self produceEnemyTank];
			[self produceBoss2];
			count++;
			break;
		case 2:
			[self setEnemyAttack];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyHorseman];
			[self produceEnemyHorseman];
			count++;
			break;
		case 3:
			[self setEnemyAttack];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyHorseman];
			[self produceEnemyHorseman];
			count++;
			break;
		case 4:
			[self produceBoss5];
			[self setEnemyAttack];
			count= -1;
			break;	
	}
}

-(void)enemyLogicState6
{
	static int count = 0;
	
	switch (count) 
	{
			//1
		case 0:
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyHorseman];
			[self produceEnemyHorseman];
			[self produceEnemyTank];
			count++;
			break;
		case 1:
			[self setEnemyAttack];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyHorseman];
			[self produceEnemyHorseman];
			[self produceBoss3];
			count++;
			break;
		case 2:
			[self setEnemyAttack];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyHorseman];
			[self produceEnemyHorseman];
			count++;
			break;
		case 3:
			[self setEnemyAttack];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyHorseman];
			[self produceEnemyHorseman];
			count++;
			break;
		case 4:
			[self produceBoss6];
			[self setEnemyAttack];
			count= -1;
			break;		
	}
}

-(void)enemyLogicState7
{
	static int count = 0;
	
	switch (count) 
	{
			//1
		case 0:
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyHorseman];
			[self produceEnemyHorseman];
			[self produceEnemyTank];
			count++;
			break;
		case 1:
			[self setEnemyAttack];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyHorseman];
			[self produceEnemyHorseman];
			[self produceEnemyTank];
			[self produceBoss4];
			count++;
			break;
		case 2:
			[self setEnemyAttack];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyHorseman];
			[self produceEnemyHorseman];
			[self produceEnemyTank];
			[self produceBoss6];
			count++;
			break;
		case 3:
			[self setEnemyAttack];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyWalkman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyBowman];
			[self produceEnemyHorseman];
			[self produceEnemyHorseman];
			[self produceEnemyTank];
			count++;
			break;
		case 4:
			[self produceBoss7];		
			[self setEnemyAttack];
			count = -1;
			break;
	}
}

-(void)enemyLogic:(ccTime)dt
{
//	[self produceEnemyWalkman];
//	[self produceEnemyBowman];
//	[self produceEnemyHorseman];
//	[self produceEnemyTank];
//	[self produceBoss1];
//	[self setEnemyAttack];
	//[self produceEnemyHorseman];
	
	switch([m_gameMain getStageNum])
	{
		case 1:
			[self enemyLogicState1];
			break;
		case 2:
			[self enemyLogicState2];
			break;
		case 3:
			[self enemyLogicState3];
			break;
		case 4:
			[self enemyLogicState4];
			break;
		case 5:
			[self enemyLogicState5];
			break;
		case 6:
			[self enemyLogicState6];
			break;
		case 7:
			[self enemyLogicState7];
			break;
	}
	
}

-(void)makeMoney:(ccTime)dt
{
	money += 100;
}

-(void)styleAnim:(ccTime)dt
{	
	if(m_styleAnimation1 > 0)
	{
		[m_rightSlot style1Produce:m_styleAnimation1-1];
		m_styleAnimation1++;
		if(m_styleAnimation1 == 5)
		{
			[self setStyle:1];
			[m_rightSlot style1Produce:0];
			m_styleAnimation1 = 0;
		}
	}
	
	if(m_styleAnimation2 > 0)
	{
		[m_rightSlot style2Produce:m_styleAnimation2-1];		
		m_styleAnimation2++;
		if(m_styleAnimation2 == 5)
		{
			[self setStyle:2];
			[m_rightSlot style2Produce:0];
			m_styleAnimation2 = 0;
		}
	}
	
	if(m_styleAnimation3 > 0)
	{
		[m_rightSlot style3Produce:m_styleAnimation3-1];
		m_styleAnimation3++;
		if(m_styleAnimation3 == 5)
		{
			[self setStyle:3];
			[m_rightSlot style3Produce:0];
			m_styleAnimation3 = 0;
		}
	}
	
	if(m_styleAnimation4 > 0)
	{
		[m_rightSlot style4Produce:m_styleAnimation4-1];		
		m_styleAnimation4++;
		if(m_styleAnimation4 == 5)
		{
			[self setStyle:4];
			[m_rightSlot style4Produce:0];
			m_styleAnimation4 = 0;
		}
	}

	if(m_attackAnimation > 0)
	{
		[self setAttack];
		//[self setEnemyAttack];
		m_attackAnimation = 0;
	}

	if(m_defenceAnimation > 0)
	{
		[self setDefence];
		//[self setEnemyDefence];
		m_defenceAnimation = 0;
	}
}

-(void) setAttack
{
	//
	for (int i = 0; i < [m_vUnitArray[UNIT_WALK] count]; i++)
	{
		MWalkman *walkman = [m_vUnitArray[UNIT_WALK] objectAtIndex:i];
		[walkman go];
	}
	
	for (int i = 0; i < [m_vUnitArray[UNIT_BOW] count]; i++)
	{
		MBowman *bowman = [m_vUnitArray[UNIT_BOW] objectAtIndex:i];
		[bowman go];
	}
	
	for (int i = 0; i < [m_vUnitArray[UNIT_HORSE] count]; i++)
	{
		MHorseman *horseman = [m_vUnitArray[UNIT_HORSE] objectAtIndex:i];
		[horseman go];
	}
	
	for (int i = 0; i < [m_vUnitArray[UNIT_TANK] count]; i++)
	{
		MTank *tank = [m_vUnitArray[UNIT_TANK] objectAtIndex:i];
		[tank go];
	}
}

-(void) setEnemyAttack
{
	//
	for (int i = 0; i < [m_vEUnitArray[UNIT_WALK] count]; i++)
	{
		MEWalkman *ewalkman = [m_vEUnitArray[UNIT_WALK] objectAtIndex:i];
		[ewalkman go];
	}
	
	for (int i = 0; i < [m_vEUnitArray[UNIT_BOW] count]; i++)
	{
		MEBowman *ebowman = [m_vEUnitArray[UNIT_BOW] objectAtIndex:i];
		[ebowman go];
	}
	
	for (int i = 0; i < [m_vEUnitArray[UNIT_HORSE] count]; i++)
	{
		MEHorseman *ehorseman = [m_vEUnitArray[UNIT_HORSE] objectAtIndex:i];
		[ehorseman go];
	}
	
	for (int i = 0; i < [m_vEUnitArray[UNIT_TANK] count]; i++)
	{
		MTank *etank = [m_vEUnitArray[UNIT_TANK] objectAtIndex:i];
		[etank go];
	}
	
}

-(void) setDefence
{
	for (int i = 0; i < [m_vUnitArray[UNIT_WALK] count]; i++)
	{
		MWalkman *walkman = [m_vUnitArray[UNIT_WALK] objectAtIndex:i];
		[walkman setFormation:m_style];
		[walkman wait];
	}
	
	for (int i = 0; i < [m_vUnitArray[UNIT_BOW] count]; i++)
	{
		MBowman *bowman = [m_vUnitArray[UNIT_BOW] objectAtIndex:i];
		[bowman setFormation:m_style];
		[bowman wait];
	}
	
	for (int i = 0; i < [m_vUnitArray[UNIT_HORSE] count]; i++)
	{
		MHorseman *horseman = [m_vUnitArray[UNIT_HORSE] objectAtIndex:i];
		[horseman setFormation:m_style];
		[horseman wait];
	}
	
	for (int i = 0; i < [m_vUnitArray[UNIT_TANK] count]; i++)
	{
		MTank *tank = [m_vUnitArray[UNIT_TANK] objectAtIndex:i];
		[tank setFormation:m_style];
		[tank wait];
	}
}

-(void) setEnemyDefence
{
	for (int i = 0; i < [m_vEUnitArray[UNIT_WALK] count]; i++)
	{
		MEWalkman *ewalkman = [m_vEUnitArray[UNIT_WALK] objectAtIndex:i];
		[ewalkman setFormation:m_style];
		[ewalkman wait];
	}
	
	for (int i = 0; i < [m_vEUnitArray[UNIT_BOW] count]; i++)
	{
		MEBowman *ebowman = [m_vEUnitArray[UNIT_BOW] objectAtIndex:i];
		[ebowman setFormation:m_style];
		[ebowman wait];
	}
	
	for (int i = 0; i < [m_vEUnitArray[UNIT_HORSE] count]; i++)
	{
		MHorseman *ehorseman = [m_vEUnitArray[UNIT_HORSE] objectAtIndex:i];
		[ehorseman setFormation:m_style];
		[ehorseman wait];
	}
	
	for (int i = 0; i < [m_vEUnitArray[UNIT_TANK] count]; i++)
	{
		MTank *etank = [m_vEUnitArray[UNIT_TANK] objectAtIndex:i];
		[etank setFormation:m_style];
		[etank wait];
	}
}

-(void) removeUnit
{
//	for (int i = 0; i < [m_vUnitArray[UNIT_WALK] count]; i++)
//	{
//		[m_vUnitArray[UNIT_WALK] removeObjectAtIndex:0];
//	}	
}
/*
-(BOOL)isFleeRadius:(MWalkman*)walkman index:(int)i
{
	if([walkman name] == @"MWalkFleeState")
	{
		for(int k = 0; k <[m_vUnitArray[UNIT_WALK] count]; k++)
		{
			if(i != k)
			{
				MWalkman *walkman2 = [m_vUnitArray[UNIT_WALK] objectAtIndex:k];
				if([walkman isInRadius:CGPointMake(walkman2.position.x, walkman.position.y)])
				{
					return TRUE;
				}
			}
		}
	}
	
	return FALSE;
}
*/
-(MUnit*)getMyInSight:(MUnit*)enemy
{
	for(int i = UNIT_WALK; i < UNIT_MAX; i++)
	{
		for (int j = 0; j < [m_vUnitArray[i] count]; j++)
		{
			MUnit *myunit = [m_vUnitArray[i] objectAtIndex:j];
			if([enemy isInSight:CGPointMake(myunit.position.x, myunit.position.y)])
			{
				return myunit;
			}
		}
	}
	
	return nil;
}

-(MUnit*)getMyInRadius:(MUnit*)enemy
{
	for(int i = UNIT_WALK; i < UNIT_MAX; i++)
	{
		for (int j = 0; j < [m_vUnitArray[i] count]; j++)
		{
			MUnit *myunit = [m_vUnitArray[i] objectAtIndex:j];
			if([enemy isInRadius:CGPointMake(myunit.position.x, myunit.position.y)])
			{
				return myunit;
			}
		}
	}
	
	return nil;
}

-(MUnit*)getEnemyInSight:(MUnit*)myUnit
{
	for(int i = UNIT_WALK; i < UNIT_MAX; i++)
	{
		for (int j = 0; j < [m_vEUnitArray[i] count]; j++)
		{
			MUnit *enemy = [m_vEUnitArray[i] objectAtIndex:j];
			if([myUnit isInSight:CGPointMake(enemy.position.x, enemy.position.y)])
			{
				return enemy;
			}
		}
	}
	
	return nil;
}

-(MUnit*)getEnemyInRadius:(MUnit*)myUnit
{
	for(int i = UNIT_WALK; i < UNIT_MAX; i++)
	{
		for (int j = 0; j < [m_vEUnitArray[i] count]; j++)
		{
			MUnit *enemy = [m_vEUnitArray[i] objectAtIndex:j];
			if([myUnit isInRadius:CGPointMake(enemy.position.x, enemy.position.y)])
			{
				return enemy;
			}
		}
	}
	
	return nil;
}

-(void)charMove:(ccTime)dt
{
	for(int j = UNIT_WALK; j < UNIT_MAX; j++)
	{
		for(int i = 0; i <[m_vUnitArray[j] count]; i++)
		{
			MUnit *unit = [m_vUnitArray[j] objectAtIndex:i];
			[unit update];
		}
	}
	
	for(int j = UNIT_WALK; j < UNIT_MAX; j++)
	{
		for(int i = 0; i <[m_vEUnitArray[j] count]; i++)
		{
			MUnit *unit = [m_vEUnitArray[j] objectAtIndex:i];
			[unit update];
		}
	}
/*	
	switch ([m_gameMain getStageNum])
	{
	case 1:
		[boss1 update];
		break;
	case 2:
		[boss2 update];
		break;
	case 3:
		[boss3 update];
		break;
	case 4:
		[boss4 update];
		break;
	case 5:
		[boss5 update];
		break;
	case 6:
		[boss6 update];
		break;
	case 7:
		[boss7 update];
		break;
	}
*/
 //////////////////////////////////////////////////////////////////
	
	
	//밀리 유닛의 성공격(적)
	if( (30 > boss2.position.x) &&[boss2 isAlive])
	{
		[boss2 attack];
		[m_castle suffer:1];
	}
	
	
	for(int i = 0; i < [m_vEUnitArray[UNIT_WALK] count]; i++)
	{
		MEWalkman *ewalkman = [m_vEUnitArray[UNIT_WALK] objectAtIndex:i];
		if(30 > ewalkman.position.x)
		{
			[ewalkman attack];
			[m_castle suffer:1];
		}
	}
	
	for(int i = 0; i < [m_vEUnitArray[UNIT_HORSE] count]; i++)
	{
		MEWalkman *ehorseman = [m_vEUnitArray[UNIT_HORSE] objectAtIndex:i];
		if(30 > ehorseman.position.x)
		{
			[ehorseman attack];
			[m_castle suffer:1];
		}
	}
	
	// 원거리 유닛의 성공격(적)
	for(int i = 0; i < [m_vEUnitArray[UNIT_BOW] count]; i++)
	{
		MEBowman *ebowman = [m_vEUnitArray[UNIT_BOW] objectAtIndex:i];
		if([ebowman isInSight:CGPointMake(30, 320/2)])
		{
			[ebowman setTargetUnit:m_castle];
			[ebowman setTarget:CGPointMake(30, 320/2)];
			[ebowman attack];
		}
	}

	for(int i = 0; i < [m_vEUnitArray[UNIT_TANK] count]; i++)
	{
		METank *etank = [m_vEUnitArray[UNIT_TANK] objectAtIndex:i];
		if([etank isInSight:CGPointMake(30, 320/2)])
		{
			[etank setTargetUnit:m_castle];
			[etank setTarget:CGPointMake(30, 320/2)];
			[etank attack];
		}
	}
/////////////////////////////////////////////////////////////////////
	
	//밀리 유닛의 성공격(아군)
	for(int i = 0; i < [m_vUnitArray[UNIT_WALK] count]; i++)
	{
		MWalkman *walkman = [m_vUnitArray[UNIT_WALK] objectAtIndex:i];
		if(930 < walkman.position.x)
		{
			[walkman setTargetUnit:m_eCastle];
			[walkman attack];
			[m_eCastle suffer:1];
		}
	}
	
	for(int i = 0; i < [m_vUnitArray[UNIT_HORSE] count]; i++)
	{
		MWalkman *horseman = [m_vUnitArray[UNIT_HORSE] objectAtIndex:i];
		if(930 < horseman.position.x)
		{
			[horseman setTargetUnit:m_eCastle];
			[horseman attack];
			[m_eCastle suffer:1];
		}
	}
	
	// 원거리 유닛의 성공격(아군)
	for(int i = 0; i < [m_vUnitArray[UNIT_BOW] count]; i++)
	{
		MBowman *bowman = [m_vUnitArray[UNIT_BOW] objectAtIndex:i];
		if([bowman isInSight:CGPointMake(930, 320/2)])
		{
			[bowman setTargetUnit:m_eCastle];
			[bowman setTarget:CGPointMake(930, 320/2)];
			[bowman attack];
		}
	}
	
	for(int i = 0; i < [m_vUnitArray[UNIT_TANK] count]; i++)
	{
		MTank *tank = [m_vUnitArray[UNIT_TANK] objectAtIndex:i];
		if([tank isInSight:CGPointMake(930, 320/2)])
		{
			[tank setTargetUnit:m_eCastle];
			[tank setTarget:CGPointMake(930, 320/2)];
			[tank attack];
		}
	}
///////////////////////////////////////////////////////////////////////////////	
	//보병의 적에 대한 공격(아군)
	for (int i = 0; i < [m_vUnitArray[UNIT_WALK] count]; i++)
	{
		MWalkman *walkman = [m_vUnitArray[UNIT_WALK] objectAtIndex:i];

		MUnit *enemy = [self getEnemyInRadius:walkman];
		if(enemy)
		{
//			MUnit* target = [walkman getTargetUnit];
//			if(target == nil)
			{
				[walkman setTargetUnit:enemy];
				[walkman attack];
				//[enemy suffer:1];
				//[enemy attack];		
				//[walkman suffer:1];
			}
		}
		else 
		{
			enemy = [self getEnemyInSight:walkman];
			if(enemy)
			{
				[walkman chase:CGPointMake(enemy.position.x, enemy.position.y)];
			}			
		}
	}

	//기병의 적에 대한 공격(아군)
	for (int i = 0; i < [m_vUnitArray[UNIT_HORSE] count]; i++)
	{
		MHorseman *horseman = [m_vUnitArray[UNIT_HORSE] objectAtIndex:i];
		
		MUnit *enemy = [self getEnemyInRadius:horseman];
		if(enemy)
		{
			//			MUnit* target = [walkman getTargetUnit];
			//			if(target == nil)
			{
				[horseman setTargetUnit:enemy];
				[horseman attack];
				//[enemy suffer:1];
				//[enemy attack];		
				//[walkman suffer:1];
			}
		}
		else 
		{
			enemy = [self getEnemyInSight:horseman];
			if(enemy)
			{
				[horseman chase:CGPointMake(enemy.position.x, enemy.position.y)];
			}		
		}
	}
	
////////////////////////////////////////////////////////////////////////////////
	// 궁병 공격(아군)
	for (int i = 0; i < [m_vUnitArray[UNIT_BOW] count]; i++)
	{
		MBowman *bowman = [m_vUnitArray[UNIT_BOW] objectAtIndex:i];

		MUnit *enemy = [self getEnemyInSight:bowman];
		if(enemy)
		{
			[bowman setTargetUnit:enemy];
			[bowman setTarget:CGPointMake(enemy.position.x, enemy.position.y)];
			[bowman attack];
			//[enemy suffer:1];
		}
	}

	// 탱크 공격(아군)
	for (int i = 0; i < [m_vUnitArray[UNIT_TANK] count]; i++)
	{
		MTank *tank = [m_vUnitArray[UNIT_TANK] objectAtIndex:i];
		
		MUnit *enemy = [self getEnemyInSight:tank];
		if(enemy)
		{
			[tank setTargetUnit:enemy];
			[tank setTarget:CGPointMake(enemy.position.x, enemy.position.y)];
			[tank attack];
			//[enemy suffer:1];
		}
	}

///////////////////////////////////////////////////////////////////////////////	
	//적보병의 아군 대한 공격(적군)
	for (int i = 0; i < [m_vEUnitArray[UNIT_WALK] count]; i++)
	{
		MEWalkman *ewalkman = [m_vEUnitArray[UNIT_WALK] objectAtIndex:i];
		
		MUnit *myunit = [self getMyInRadius:ewalkman];
		if(myunit)
		{
			//			MUnit* target = [walkman getTargetUnit];
			//			if(target == nil)
			{
				[ewalkman setTargetUnit:myunit];
				[ewalkman attack];
				//[enemy suffer:1];
				//[enemy attack];		
				//[walkman suffer:1];
			}
		}
		else 
		{
			myunit = [self getMyInSight:ewalkman];
			if(myunit)
			{
				[ewalkman chase:CGPointMake(myunit.position.x, myunit.position.y)];
			}			
		}
	}

	//적기병의 아군에 대한 공격(적군)
	for (int i = 0; i < [m_vEUnitArray[UNIT_HORSE] count]; i++)
	{
		MEHorseman *ehorseman = [m_vEUnitArray[UNIT_HORSE] objectAtIndex:i];
		
		MUnit *myunit = [self getMyInRadius:ehorseman];
		if(myunit)
		{
			//			MUnit* target = [walkman getTargetUnit];
			//			if(target == nil)
			{
				[ehorseman setTargetUnit:myunit];
				[ehorseman attack];
				//[enemy suffer:1];
				//[enemy attack];		
				//[walkman suffer:1];
			}
		}
		else 
		{
			myunit = [self getMyInSight:ehorseman];
			if(myunit)
			{
				[ehorseman chase:CGPointMake(myunit.position.x, myunit.position.y)];
			}		
		}
	}

	//보스의 아군에 대한 공격(적군)
	for (int i = 0; i < [m_vEUnitArray[UNIT_BOSS] count]; i++)
	{
		MUnit *boss = [m_vEUnitArray[UNIT_BOSS] objectAtIndex:i];
		
		MUnit *myunit = [self getMyInRadius:boss];
		if(myunit)
		{
			//			MUnit* target = [walkman getTargetUnit];
			//			if(target == nil)
			{
				[boss setTargetUnit:myunit];
				[boss attack];
				//[enemy suffer:1];
				//[enemy attack];		
				//[walkman suffer:1];
			}
		}
		else 
		{
			myunit = [self getMyInSight:boss];
			if(myunit)
			{
				[boss chase:CGPointMake(myunit.position.x, myunit.position.y)];
			}		
		}
	}
	
////////////////////////////////////////////////////////////////////////////////
	// 적궁병의 아군에대한 공격(적군)
	for (int i = 0; i < [m_vEUnitArray[UNIT_BOW] count]; i++)
	{
		MEBowman *ebowman = [m_vEUnitArray[UNIT_BOW] objectAtIndex:i];
		
		MUnit *myunit = [self getMyInSight:ebowman];
		if(myunit)
		{
			[ebowman setTargetUnit:myunit];
			[ebowman setTarget:CGPointMake(myunit.position.x, myunit.position.y)];
			[ebowman attack];
			//[enemy suffer:1];
		}
	}
	
	// 탱크 공격(적군)
	for (int i = 0; i < [m_vEUnitArray[UNIT_TANK] count]; i++)
	{
		METank *etank = [m_vEUnitArray[UNIT_TANK] objectAtIndex:i];
		
		MUnit *myunit = [self getMyInSight:etank];
		if(myunit)
		{
			[etank setTargetUnit:myunit];
			[etank setTarget:CGPointMake(myunit.position.x, myunit.position.y)];
			[etank attack];
			//[enemy suffer:1];
		}
	}
	
	
//////////////////////////////////////////////////////////////////////////////////

/*
	// 기마병이 적을 검사하여 공격처리를 한다.
	for (int i = 0; i < [m_vUnitArray[UNIT_HORSE] count]; i++)
	{
		MHorseman *horseman = [m_vUnitArray[UNIT_HORSE] objectAtIndex:i];
		
		//	NSLog(@"%d",i);
		
		for (int j = 0; j < [m_vEUnitArray[UNIT_WALK] count]; j++)
		{
			MWalkman *enemy = [m_vEUnitArray[UNIT_WALK] objectAtIndex:j];
			if([horseman isInRadius:CGPointMake(enemy.position.x, enemy.position.y)])
			{
				[horseman attack];
				[enemy suffer:1];
				[enemy attack];
				[horseman suffer:1];
			}
			else if ([horseman isInSight:CGPointMake(enemy.position.x, enemy.position.y)]) 
			{
				[horseman chase:CGPointMake(enemy.position.x, enemy.position.y)];
				break;
			}
		}

		// 기마병의 적 성벽에 대한 공격.
		if([horseman isInRadiusCastle:CGPointMake(m_eCastle.position.x, m_eCastle.position.y)])
		{
			[horseman attack];
			[m_eCastle suffer:1];
		}
		else if([horseman isInSight:CGPointMake(m_eCastle.position.x, m_eCastle.position.y)])
		{
			[horseman chase:CGPointMake(m_eCastle.position.x, m_eCastle.position.y)];
			break;			
		}
	}
	*/
	// 적 보병을 검사하여 우리 성이 공격한다.
	/*
	for(int i = 0; i < [m_vEUnitArray[UNIT_WALK] count]; i++)
	{
		MEWalkman *enemy = [m_vEUnitArray[UNIT_WALK] objectAtIndex:i];
		if([m_castle isInSight:CGPointMake(enemy.position.x, enemy.position.y)])
		{
			[m_castle setTargetUnit:enemy];
			[m_castle setTarget:CGPointMake(enemy.position.x, enemy.position.y)];
			[m_castle attack];
			break;
		}
	}
	*/
	/*
	// 궁병의 공격 처리
	for(int i  = 0; i < [m_vUnitArray[UNIT_BOW] count]; i++)
	{
		MBowman *bowman = [m_vUnitArray[UNIT_BOW] objectAtIndex:i];
		for(int j = 0; j < [m_vEUnitArray[UNIT_WALK] count]; j++)
		{
			MEWalkman *enemy = [m_vEUnitArray[UNIT_WALK] objectAtIndex:j];
			if([bowman isInSight:CGPointMake(enemy.position.x, enemy.position.y)])
			{
				[bowman setTargetUnit:enemy];
				[bowman setTarget:CGPointMake(enemy.position.x, enemy.position.y)];
				[bowman attack];
				break;
			}
		}
	}
	*/
	
////////////////////////////////////////////////////////////////////////////////////////////
	// 적을 검사하여 죽었을 때 처리를 한다.
	for(int k = UNIT_WALK; k < UNIT_MAX; k++)
	{
		for(int i = 0; i < [m_vEUnitArray[k] count]; i++)
		{
			MUnit *enemy = [m_vEUnitArray[k] objectAtIndex:i];
			if([enemy getHP] <= 0)
			{
				switch(k)
				{
					case UNIT_WALK:
						m_iWalkKill++;
						break;
					case UNIT_BOW:
						m_iBowKill++;
						break;
					case UNIT_HORSE:
						m_iHorseKill++;
						break;
					case UNIT_TANK:
						m_iTankKill++;
						break;
					case UNIT_BOSS:
						m_iBossKill++;				
						break;
				}
				
				[enemy dead];
				[m_vEUnitArray[k] removeObjectAtIndex:i];
				[self removeChild:enemy cleanup:YES];
				// 보병
				for(int j = 0; j < [m_vUnitArray[UNIT_WALK] count]; j++)
				{
					MWalkman *walkman = [m_vUnitArray[UNIT_WALK] objectAtIndex:j];
					if([walkman getTargetUnit] == enemy)
					{
						[walkman setTargetUnit:nil];
					}
				}
				// 궁병
				for( int j = 0; j < [m_vUnitArray[UNIT_BOW] count]; j++)
				{
					MBowman *bowman = [m_vUnitArray[UNIT_BOW] objectAtIndex:j];
					if([bowman getTargetUnit] == enemy)
					{
						[bowman setTargetUnit:nil];
					}
				}
				for( int j = 0; j < [m_vUnitArray[UNIT_HORSE] count]; j++)
				{
					MHorseman *horseman = [m_vUnitArray[UNIT_HORSE] objectAtIndex:j];
					if([horseman getTargetUnit] == enemy)
					{
						[horseman setTargetUnit:nil];
					}
				}
				for( int j = 0; j < [m_vUnitArray[UNIT_TANK] count]; j++)
				{
					MTank *tank = [m_vUnitArray[UNIT_TANK] objectAtIndex:j];
					if([tank getTargetUnit] == enemy)
					{
						[tank setTargetUnit:nil];
					}
				}			
				// 성
//				if([m_castle getTargetUnit] == enemy)
//				{
//					[m_castle setTargetUnit:nil];
//				}
			}
		}
	}

	// 아군을 검사하여 죽었을 때 처리를 한다.
	for(int j = UNIT_WALK; j < UNIT_MAX; j++)
	{
		for(int i = 0; i < [m_vUnitArray[j] count]; i++)
		{
			MUnit *myunit = [m_vUnitArray[j] objectAtIndex:i];
			if([myunit getHP] <= 0)
			{
				[myunit dead];
				[m_vUnitArray[j] removeObjectAtIndex:i];
				[self removeChild:myunit cleanup:YES];				
				// 보병
				for(int k = 0; k < [m_vEUnitArray[UNIT_WALK] count]; k++)
				{
					MEWalkman *ewalkman = [m_vEUnitArray[UNIT_WALK] objectAtIndex:k];
					if([ewalkman getTargetUnit] == myunit)
					{
						[ewalkman setTargetUnit:nil];
					}
				}
				// 궁병
				for( int k = 0; k < [m_vEUnitArray[UNIT_BOW] count]; k++)
				{
					MEBowman *ebowman = [m_vEUnitArray[UNIT_BOW] objectAtIndex:k];
					if([ebowman getTargetUnit] == myunit)
					{
						[ebowman setTargetUnit:nil];
					}
				}
				for( int k = 0; k < [m_vEUnitArray[UNIT_HORSE] count]; k++)
				{
					MEHorseman *ehorseman = [m_vEUnitArray[UNIT_HORSE] objectAtIndex:k];
					if([ehorseman getTargetUnit] == myunit)
					{
						[ehorseman setTargetUnit:nil];
					}
				}
				for( int k = 0; k < [m_vEUnitArray[UNIT_TANK] count]; k++)
				{
					METank *etank = [m_vEUnitArray[UNIT_TANK] objectAtIndex:k];
					if([etank getTargetUnit] == myunit)
					{
						[etank setTargetUnit:nil];
					}
				}			
				// 성
//				if([m_eCastle getTargetUnit] == enemy)
//				{
//					[m_castle setTargetUnit:nil];
//				}
			}
		}
	}
	/*
	//hp를 검사하여 죽었을 때 처리를 한다.
	// 보병
	for(int i = 0; i < [m_vUnitArray[UNIT_WALK] count]; i++)
	{
		MWalkman *walkman = [m_vUnitArray[UNIT_WALK] objectAtIndex:i];
		if([walkman getHP] <= 0)
		{
			[walkman dead];
			[m_vUnitArray[UNIT_WALK] removeObjectAtIndex:i];
			[self removeChild:walkman cleanup:YES];
		}
	}
	*/
/////////////////////////////////////////////////////////////////////////////////////////////////////
	
/*
	// 기마병
	for(int i = 0; i < [m_vUnitArray[UNIT_HORSE] count]; i++)
	{
		MHorseman *horseman = [m_vUnitArray[UNIT_HORSE] objectAtIndex:i];
		if([horseman getHP] <= 0)
		{
			[horseman dead];
			[m_vUnitArray[UNIT_HORSE] removeObjectAtIndex:i];
			[self removeChild:horseman cleanup:YES];
		}
	}
	*/
	// 성벽에 대한 hp를 검사하여 게임종료를 처리한다.
/////////////////////////////////////////////////////////////////////////////////////////////////////
	// 적성
	if([m_eCastle getHP] <= 0)
	{
		[self unschedule:@selector(styleAnim:)];
		[self unschedule:@selector(makeMoney:)];
		[self unschedule:@selector(charLogic:)];
		[self unschedule:@selector(charMove:)];
/*		
		for(int i = 0; i < [m_vUnitArray[UNIT_WALK] count]; i++)
		{
			MWalkman *walkman = [m_vUnitArray[UNIT_WALK] objectAtIndex:i];
			[walkman dead];
			[m_vUnitArray[UNIT_WALK] removeObjectAtIndex:i];
			[self removeChild:walkman cleanup:<#(BOOL)doCleanup#>
		}
*/		
		m_bEndGame = TRUE;
		[m_gameMain WinGame];
	}
	// 아군성
	if([m_castle getHP] <= 0)
	{
		[self unschedule:@selector(styleAnim:)];
		[self unschedule:@selector(makeMoney:)];
		[self unschedule:@selector(charLogic:)];
		[self unschedule:@selector(charMove:)];
		/*		
		 for(int i = 0; i < [m_vUnitArray[UNIT_WALK] count]; i++)
		 {
		 MWalkman *walkman = [m_vUnitArray[UNIT_WALK] objectAtIndex:i];
		 [walkman dead];
		 [m_vUnitArray[UNIT_WALK] removeObjectAtIndex:i];
		 [self removeChild:walkman cleanup:<#(BOOL)doCleanup#>
		 }
		 */		
		m_bEndGame = TRUE;
		[m_gameMain WinGame];
	}	
}

-(void) produceMyWalkman
{
	MWalkman *walkman = [[MWalkman spriteSheetWithFile:@"fhp-all.png" capacity:10] init];
	[walkman setLeftSlot:m_leftSlot];

	[walkman setFormation:m_style];
	[m_vUnitArray[UNIT_WALK] addObject:walkman];
	[self addChild:walkman z:0 tag:0];
}

-(void) produceEnemyWalkman
{	
	MEWalkman *ewalkman = [MEWalkman spriteSheetWithFile:@"efhp-all.png" capacity:10];
	[ewalkman setFormation:m_enemyStyle];
	[ewalkman init];
	
	ewalkman.position = ccp(960-33, 160);
	[m_vEUnitArray[UNIT_WALK] addObject:ewalkman];
	[self addChild:ewalkman z:0];
}

-(void) produceBoss1
{	
	boss1 = [[Boss1 spriteSheetWithFile:@"eb01hp-all.png" capacity:10] init];
//	[boss1 setBackground:self];
	boss1.position = ccp(960-33, 160);
	[m_vEUnitArray[UNIT_BOSS] addObject:boss1];
	[self addChild:boss1 z:0];
}

-(void) produceBoss2
{	
	boss2 = [[Boss2 spriteSheetWithFile:@"eb02hp-all.png" capacity:10] init];
//	[boss2 setBackground:self];
	boss2.position = ccp(960-33, 160);
	[m_vEUnitArray[UNIT_BOSS] addObject:boss2];
	[self addChild:boss2 z:0];
}

-(void) produceBoss3
{	
	boss3 = [[Boss3 spriteSheetWithFile:@"eb03hp-all.png" capacity:10] init];
//	[boss3 setBackground:self];
	boss3.position = ccp(960-33, 160);
	[m_vEUnitArray[UNIT_BOSS] addObject:boss3];
	[self addChild:boss3 z:0];
}

-(void) produceBoss4
{	
	boss4 = [[Boss4 spriteSheetWithFile:@"eb04hp-all.png" capacity:10] init];
//	[boss4 setBackground:self];
	boss4.position = ccp(960-33, 160);
	[m_vEUnitArray[UNIT_BOSS] addObject:boss4];
	[self addChild:boss4 z:0];
}

-(void) produceBoss5
{	
	boss5 = [[Boss5 spriteSheetWithFile:@"eb05hp-all.png" capacity:10] init];
//	[boss5 setBackground:self];
	boss5.position = ccp(960-33, 160);
	[m_vEUnitArray[UNIT_BOSS] addObject:boss5];
	[self addChild:boss5 z:0];
}

-(void) produceBoss6
{	
	boss6 = [[Boss6 spriteSheetWithFile:@"eb06hp-all.png" capacity:10] init];
//	[boss6 setBackground:self];
	boss6.position = ccp(960-33, 160);
	[m_vEUnitArray[UNIT_BOSS] addObject:boss6];
	[self addChild:boss6 z:0];
}

-(void) produceBoss7
{	
	boss7 = [[Boss7 spriteSheetWithFile:@"eb07hp-all.png" capacity:10] init];
//	[boss7 setBackground:self];
	boss7.position = ccp(960-33, 160);
	[m_vEUnitArray[UNIT_BOSS] addObject:boss7];
	[self addChild:boss7 z:0];
}

-(void) produceEnemyBowman
{	
	MEBowman *ebowman = [MEBowman spriteSheetWithFile:@"eahp-all.png" capacity:10];
	[ebowman setFormation:m_enemyStyle];
	[ebowman setBackground:self];
	[ebowman init];
	
	ebowman.position = ccp(960-33, 160);
	[m_vEUnitArray[UNIT_BOW] addObject:ebowman];
	[self addChild:ebowman z:0];
}

-(void) produceEnemyHorseman
{	
	MEHorseman *ehorseman = [MEHorseman spriteSheetWithFile:@"ehhp-all.png" capacity:10];
	[ehorseman setFormation:m_enemyStyle];
	[ehorseman init];
	ehorseman.position = ccp(960-33, 160);
	[m_vEUnitArray[UNIT_HORSE] addObject:ehorseman];
	[self addChild:ehorseman z:0];
}

-(void) produceEnemyTank
{	
	METank *etank = [METank spriteSheetWithFile:@"echp-all.png" capacity:10];
	[etank setBackground:self];
	[etank setFormation:m_enemyStyle];
	[etank init];
	
	etank.position = ccp(960-33, 160);
	[m_vEUnitArray[UNIT_TANK] addObject:etank];
	[self addChild:etank z:0];
}

-(BOOL) reduceMoney:(int)m
{
	if(money >= m)
	{
		money -= m;
		return TRUE;
	}
	return FALSE;
}

-(void) produceMyBowman
{
	MBowman *bowman = [[MBowman spriteSheetWithFile:@"ahp-all.png" capacity:10] init];
	[bowman setBackground:self];
	[bowman setLeftSlot:m_leftSlot];
	[bowman setFormation:m_style];

	[m_vUnitArray[UNIT_BOW] addObject:bowman];
	[self addChild:bowman z:0];
}


-(void) produceMyHorseman
{
	MHorseman *horseman = [[MHorseman spriteSheetWithFile:@"hhp-all.png" capacity:10] init];
	[horseman setLeftSlot:m_leftSlot];
	[horseman setFormation:m_style];

	[m_vUnitArray[UNIT_HORSE] addObject:horseman];
	[self addChild:horseman z:0];
}

-(void) produceMyTank
{
	MTank *tank = [[MTank spriteSheetWithFile:@"chp-all.png" capacity:10] init];
	[tank setBackground:self];
	[tank setLeftSlot:m_leftSlot];
	[tank setFormation:m_style];
	[m_vUnitArray[UNIT_TANK] addObject:tank];
	[self addChild:tank z:0];
}

- (void)onExit
{
	[m_vUnitArray[UNIT_WALK] release];
	[m_vEUnitArray[UNIT_WALK] release];
	[[CCTouchDispatcher sharedDispatcher] removeDelegate:self];
	[super onExit];
}

- (BOOL)containsTouchLocation:(UITouch *)touch
{
	return CGRectContainsPoint(self.rect, [self convertTouchToNodeSpaceAR:touch]);
}

- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{
//	NSLog(@"Background");
	if ( ![self containsTouchLocation:touch] ) return NO;
	
//	CGPoint old_pt = self.position;
//	self.position = ccp(self.position.x,320/2);
	firstPos = self.position;
//	NSLog(@"first point:(%f)\n",self.position.x);
	firstMove = TRUE;

	
	return YES;
}

- (void)ccTouchMoved:(UITouch *)touch withEvent:(UIEvent *)event
{		
	CGPoint touchPoint = [touch locationInView:[touch view]];
	touchPoint = [[CCDirector sharedDirector] convertToGL:touchPoint];
	
	if(firstMove)
	{
		firstPos.x = touchPoint.x;
		firstMove = FALSE;
	}
	
	float x, y, z;
	[[self camera] eyeX:&x eyeY:&y eyeZ:&z];
	
	float scrollX = (firstPos.x-touchPoint.x)*0.1;
	if ( x+scrollX< 0)
	{
		[[self camera] setEyeX:0 eyeY:y eyeZ:z];
	}
	else if( x+scrollX > 480)
	{
		[[self camera] setEyeX:480 eyeY:y eyeZ:z];
	}
	else 
	{
		[[self camera] setEyeX:x+scrollX eyeY:y eyeZ:z];
	}

	[[self camera] centerX:&x centerY:&y centerZ:&z];
	if (x+scrollX < 0)
	{
		[[self camera] setCenterX:0 centerY:y centerZ:z];
	}
	else if( x+scrollX > 480)
	{
		[[self camera] setCenterX:480 centerY:y centerZ:z]; 
	}
	else 
	{
		[[self camera] setCenterX:x+scrollX centerY:y centerZ:z];
	}

	
//	self.position = CGPointMake(self.position.x +firstPos.x-touchPoint.x, self.position.y);
//	if (self.position.x < 0) 
//	{
//		self.position = CGPointMake(0.0f,self.position.y);
//	}
//	
//	else if(self.position.x > 480.0f)
//	{
//		self.position = CGPointMake(480.0f,self.position.y);
//	}
	
	//NSLog(@"self.positioin,firstPos,touchPoint:(%f,%f,%f)",self.position.x,firstPos.x,touchPoint.x);	
}

- (void)ccTouchEnded:(UITouch *)touch withEvent:(UIEvent *)event
{
//	lastPos = self.position;
//	NSLog(@"last point:(%f)\n",self.position.x);
	
//	self.position = CGPointMake(self.position.x+lastPos.x - firstPos.x,self.position.y);
}

-(int) getMoney
{
	return money;
}

-(void) setStyle:(int)style
{
	m_style = style;
}

-(void) setEnemyStyle:(int)style
{
	m_enemyStyle = style;
}

-(void) setStyleAnim:(int)type
{
	switch (type) 
	{
		case 1:
			m_styleAnimation1 = 1;
			break;
		case 2:
			m_styleAnimation2 = 1;
			break;
		case 3:
			m_styleAnimation3 = 1;
			break;
		case 4:
			m_styleAnimation4 = 1;
			break;
		default:
			break;
	}
}

-(void) setAttackAnim
{
	m_attackAnimation = 1;
}

-(void) setDefenceAnim
{
	m_defenceAnimation = 1;
}

-(BOOL) isEndGame
{
	return m_bEndGame;
}

-(void) resetGame
{
	m_bEndGame = FALSE;
}

-(void) setGameMain:(MGameMain1*)gm
{
	m_gameMain = gm;
}

-(void) setLeftSlot:(MLeftSlot*)slot
{
	m_leftSlot = slot;
}

-(void) setRightSlot:(MRightSlot*)slot
{
	m_rightSlot = slot;	
}

-(int) getiWalkKill
{
	return m_iWalkKill;
}

-(int) getiBowKill
{
	return m_iBowKill;
}

-(int) getiHorseKill
{
	return m_iHorseKill;
}

-(int) getiTankKill
{
	return m_iTankKill;
}

-(int) getiBossKill
{
	return m_iBossKill;
}

-(int) getiCastleHP
{
	return [m_castle getHP];
}

@end
