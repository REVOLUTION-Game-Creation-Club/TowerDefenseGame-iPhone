//
//  Vector2D.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 11..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Vector2D : NSObject 
{
	double x;

	double y;
}

- (void) zero;
- (bool) isZero;
- (double) length;
- (double) lengthSq;
@end
