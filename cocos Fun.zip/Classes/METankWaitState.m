//
//  METankWaitState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 27..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "METankWaitState.h"
#import "METank.h"
#import "MBackground.h"

@implementation METankWaitState

- (void)Enter:(id)owner
{
	m_iCount = 0;
	METank *tank = owner;
	switch ([tank getFormation]) 
	{
		case STYLE_NO:
			x = 960-100;
			y = rand()%220+50;
			break;
		case STYLE_1:
			x = 960-(rand()%40+80);
			y = rand()%80+80;
			break;
		case STYLE_2:
			x = 960-(rand()%40+80);
			y = rand()%80+80;
			break;
		case STYLE_3:
			x = 960-(rand()%40+80);
			y = rand()%80+80;
			break;
		case STYLE_4:
			x = 960-(rand()%40+80);
			y = rand()%80+80;
			break;			
	}	
}

- (void)Execute:(id)owner
{
	METank *tank = owner;
	if(m_iCount== 0)
	{
		[tank WaitAnimation];
	}
	m_iCount++;
	if(m_iCount == 60)
		m_iCount = 0;
	
	//
	
	METank* sprite = owner;
	
	if(( sprite.position.x > x-1)&&(sprite.position.y < y+1)&&
	   ( sprite.position.x < x+1)&&(sprite.position.y > y-1))
	{
		//[sprite setFlipX:FALSE];
		[sprite setRotation:0];
		[sprite setPosition:CGPointMake(x, y)];
	}
	
	else 
	{
		float dx = x - sprite.position.x;
		float dy = y - sprite.position.y;
		
		dx=dx/sqrt(dx*dx+dy*dy);
		dy=dy/sqrt(dx*dx+dy*dy);
		if(dx <0)
		{
			[sprite setFlipX:TRUE];
		}
		
		[sprite setRotation:atan(dy/dx)*-180/3.14];
		[sprite setPosition:CGPointMake(sprite.position.x+dx, sprite.position.y+dy)];
	}
}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"MTankWaitState";
}

@end
