//
//  Boss7DeathState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 24..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Boss7DeathState.h"
#import "Boss7.h"

@implementation Boss7DeathState

- (void)Enter:(id)owner
{
	m_iCount = 0;
	Boss7 *boss7 = owner;
	[boss7 unvisibleAll];
}

- (void)Execute:(id)owner
{
	Boss7 *boss7 = owner;
	if(m_iCount == 0)
	{
		[boss7 DeathAnimation];
	}
	m_iCount++;
	
	if(m_iCount == 30)
		m_iCount = 0;
	
}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"Boss1DeathState";
}

@end
