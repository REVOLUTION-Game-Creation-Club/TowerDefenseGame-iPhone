//
//  Boss1AttackState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 24..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Boss1AttackState.h"
#import "Boss1.h"
#import "MWalkman.h"

@implementation Boss1AttackState

- (void)Enter:(id)owner
{
	m_iCount = 0;
	Boss1 *boss1 = owner;
	[boss1 unvisibleAll];
}

- (void)Execute:(id)owner
{
	Boss1 *boss1 = owner;
	if(m_iCount == 0)
	{
		[boss1 AttackAnimation];
	}
	m_iCount++;	
	
	if(m_iCount == 30)
	{
		m_iCount = 0;
		MUnit *enemy = [boss1 getTargetUnit];
		if(enemy)
		{
			//[enemy suffer:1];
		}
	}
	
	[boss1 setFlipX:TRUE];
}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"Boss1AttackState";
}

@end
