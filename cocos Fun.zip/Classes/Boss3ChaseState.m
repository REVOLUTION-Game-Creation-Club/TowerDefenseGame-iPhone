//
//  Boss3ChaseState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 24..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Boss3ChaseState.h"
#import "Boss3.h"

@implementation Boss3ChaseState

- (void)Enter:(id)owner
{
	//rot = 0;
	m_iCount = 0;
	Boss3 *boss3 = owner;
	[boss3 unvisibleAll];
}

- (void)Execute:(id)owner
{
	Boss3 *boss3 = owner;
	if(m_iCount == 0)
	{
		[boss3 MoveAnimation];
	}
	m_iCount++;
	
	if(m_iCount == 30)
		m_iCount = 0;
	
	CGPoint pt = [boss3 getChasePoint];
	
	float dx = pt.x - boss3.position.x;
	float dy = pt.y - boss3.position.y;
	
	dx=dx/sqrt(dx*dx+dy*dy);
	dy=dy/sqrt(dx*dx+dy*dy);
	if(dx <0)
	{
		[boss3 setFlipX:FALSE];
	}
	//rot = rot+10;
	//NSLog(@"%f\n",rot);
	//[walkman setAnchorPoint:CGPointMake(0.25, 0.75)];
	//[walkman setRotation:180];
	[boss3 setRotation:atan(dy/dx)*-180/3.14];
	[boss3 setPosition:CGPointMake(boss3.position.x+dx, boss3.position.y+dy)];	
}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"Boss1ChaseState";
}

@end
