//
//  MStore.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 28..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "cocos2d.h"
#import "MUpgradeNumber.h"
#import "MQuickIcon.h"

@interface MStore : CCLayer <CCTargetedTouchDelegate>
{	
	CCSprite* bowButtonOn;
	CCSprite* shieldButtonOn;
	CCSprite* swordButtonOn;
	CCSprite* castleButtonOn;
	CCSprite* combineButtonOn;
	CCSprite* quickButton1;
	CCSprite* quickButton1On;
	CCSprite* quickButton2;
	CCSprite* quickButton2On;
	CCSprite* quickButton3;
	CCSprite* quickButton3On;
	
	CCSprite* menu1;
	CCSprite* menu2;
	CCSprite* menu3;
	
	CCSprite* arrow01;
	CCSprite* arrow02;
	CCSprite* arrow03;
	CCSprite* arrow04;
	CCSprite* arrow05;
	CCSprite* arrow01On;
	CCSprite* arrow02On;
	CCSprite* arrow03On;
	CCSprite* arrow04On;
	CCSprite* arrow05On;
	
	CCSprite* shield01;
	CCSprite* shield02;
	CCSprite* shield03;
	CCSprite* shield04;
	CCSprite* shield05;
	CCSprite* shield01On;
	CCSprite* shield02On;
	CCSprite* shield03On;
	CCSprite* shield04On;
	CCSprite* shield05On;
	
	CCSprite* sword01;
	CCSprite* sword02;
	CCSprite* sword03;
	CCSprite* sword04;
	CCSprite* sword05;
	CCSprite* sword01On;
	CCSprite* sword02On;
	CCSprite* sword03On;
	CCSprite* sword04On;
	CCSprite* sword05On;
	
	CCSprite* castlemenu1;
	CCSprite* castlemenu2;
	CCSprite* castlemenu3;
	CCSprite* castlemenu4;
	CCSprite* castlemenu5;

	CCSprite* woodNum;
	CCSprite* woodNumOn;
	CCSprite* ironNum;
	CCSprite* ironNumOn;
	CCSprite* wood1Dis;
	CCSprite* wood1;
	CCSprite* wood1On;
	CCSprite* wood1Sold;
	CCSprite* iron1Dis;
	CCSprite* iron1;
	CCSprite* iron1On;
	CCSprite* iron1Sold;
	CCSprite* iron2Dis;
	CCSprite* iron2;
	CCSprite* iron2On;
	CCSprite* iron2Sold;
	CCSprite* iron3Dis;
	CCSprite* iron3;
	CCSprite* iron3On;
	CCSprite* iron3Sold;
	
	MUpgradeNumber* arrow1up;
	MUpgradeNumber* arrow2up;
	MUpgradeNumber* arrow3up;
	MUpgradeNumber* arrow4up;
	MUpgradeNumber* arrow5up;

	MUpgradeNumber* shield1up;
	MUpgradeNumber* shield2up;
	MUpgradeNumber* shield3up;
	MUpgradeNumber* shield4up;
	MUpgradeNumber* shield5up;

	MUpgradeNumber* sword1up;
	MUpgradeNumber* sword2up;
	MUpgradeNumber* sword3up;
	MUpgradeNumber* sword4up;
	MUpgradeNumber* sword5up;

	MUpgradeNumber* woodnumup;
	MUpgradeNumber* ironnumup;
	
	CCSprite* skill1;
	CCSprite* skill1On;
	CCSprite* skill2;
	CCSprite* skill2On;
	CCSprite* skill3;
	CCSprite* skill3On;
	CCSprite* skill4;
	CCSprite* skill4On;
	CCSprite* skill5;
	CCSprite* skill5On;
	CCSprite* skill6;
	CCSprite* skill6On;

	MUpgradeNumber* skill1up;
	MUpgradeNumber* skill2up;
	MUpgradeNumber* skill3up;
	MUpgradeNumber* skill4up;
	MUpgradeNumber* skill5up;
	MUpgradeNumber* skill6up;
	
	MQuickIcon* quickIcon1;
	MQuickIcon* quickIcon2;
	MQuickIcon* quickIcon3;
	
	CCLabel *moneyLabel;
	
	NSData *freezeDried;
}

-(id)init;
-(void) swordOnUnvisible;
-(void) shieldOnUnvisible;
-(void) arrowOnUnvisible;
-(void) setMoneyLabel:(int)n;
-(void) setCastleUpgrade:(int)n;
- (NSString*)dataFilePath;

@end
