//
//  HelloWorldLayer.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 3..
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//


// When you import this file, you import all the cocos2d classes
#import "cocos2d.h"

// HelloWorld Layer
@interface Title : CCLayer
{
}

// returns a Scene that contains the HelloWorld as the only child
+(id) scene;
-(void)cbTimer; // 콜백 함수를 추가
@end
