//
//  HelloWorldLayer.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 3..
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

// Import the interfaces
#import "Title.h"
#import "Menu.h"

// HelloWorld implementation
@implementation Title

+(id) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];	// CScene 생성
	
	// 'layer' is an autorelease object.
	Title *layer = [Title node];	// CScene에 올릴 layer를 생성함
	
	// add layer as a child to scene
	[scene addChild: layer];	// 생성한 layer를 scene에 add시킵니다.
	
	// return the scene
	return scene;
}

// on "init" you need to initialize your instance
-(id) init
{
	// always call "super" init
	// Apple recommends to re-assign "self" with the "super" return value
	if( (self=[super init] )) 
	{
		// Scene을 생성하면서 layer를 생성하게 되는데 생성을 하면 여기로 옵니다.
		// 그래서 타이틀화면에 layer를 올려서 값을 넘겨주면 됩니다.
		
		// 화면 사이즈를 구한다.
		CGSize size = [[CCDirector sharedDirector] winSize];
		
		CCColorLayer *layer = [CCColorLayer layerWithColor:ccc4(0xFF,0x00,0x00,0x08) width:size.width height:size.height];
		//layer.relativeAnchorPoint =  YES;
		layer.position = ccp(size.width/2,size.height/2); // 좌표 이동
		[self addChild:layer z:-1];	// CCLayer에 Add를 시킨다. z버퍼를 지원하기 때문에 값을 입력하면 알아서 화면에 정렬되어 보여진다.
		// 플러스일 수록 화면 위에 뿌려집니다
		
		// 이미지로 배경에 뿌려준다. 우선 이미지가 없기 때문에 cocos에서 사용하는 Default.png파일을 사용하였습니다.
		CCSprite *sBg = [[CCSprite spriteWithFile:@"Default.png"] retain];
		[self addChild:sBg z:0];
		sBg.position = ccp(size.width/2, size.height/2);
		
		// 처음 프로젝트 생성시 있던 라벨을 참조하여 화면에 뿌린 것입니다.
//		CCLabel* label = [CCLabel labelWithString:@"타이틀 화면" fontName:@"Marker Felt" fontSize:32];
//		//CGSize size = [[CCDirector sharedDirector] winSize];
//		label.position = ccp(size.width/2, size.height/2);
//		[self addChild:label z:1];
		
		// 추가: 이 함수는 일정시간이 지나게 되면 콜백을 부르는 함수. 1초후에 cbTimer함수를 부르게 됩니다.
		[self performSelector:@selector(cbTimer) withObject:nil afterDelay:1];
	}
	return self;
}

-(void) cbTimer
{
	// 여기서는 메뉴화면을 넘어가야 한다.
	// 넘어가기 전에 scene애니메이션을 시켜준다.
	CCScene *s2 = [CCScene node]; // CCScene을 생성하고
	[s2 addChild:[Menu node]]; // 생성한 CCScene에 Layer클래스를 넣어준다.
	// MenuMain으로 넘어가니 MenuMain 레이어를 넣어준다.
	[[CCDirector sharedDirector] replaceScene:[CCFlipXTransition transitionWithDuration:1 scene:s2]];
}

// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
	// in case you have something to dealloc, do it in this method
	// in this particular example nothing needs to be released.
	// cocos2d will automatically release all the children (Label)
	
	// don't forget to call "super dealloc"
	[super dealloc];
}

@end
