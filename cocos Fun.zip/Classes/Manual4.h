//
//  Manual4.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 15..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface Manual4 : CCLayer <CCTargetedTouchDelegate> 
{
	CCSprite* m_sprite;
}

@end
