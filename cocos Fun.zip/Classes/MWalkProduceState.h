//
//  MProduceState.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 14..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MState.h"

@interface MWalkProduceState : MState 
{
	int m_iProduceTime;
}

- (void)Enter:(id)owner;
- (void)Execute:(id)owner;
- (void)Exit:(id)owner;
- (NSString*)name;

@end
