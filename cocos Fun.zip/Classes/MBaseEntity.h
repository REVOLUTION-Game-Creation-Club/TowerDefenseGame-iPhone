//
//  BaseEntity.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 11..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

enum ENTITY_TYPE
{
	DEFALUT_ENTITY_TYPE = -1,
};

@class Vector2D;

@interface MBaseEntity : NSObject 
{
	int m_iID;
	int m_iType;
	bool m_bTag;
	// static int m_iNextValidID;
//	Vector2D m_vPosition;
//	Vector2D m_vScale;
	double m_dBoundingRadius;
}

- (void) update;
- (BOOL) handleMesage;
+ (int) getNextValidID;
+ (void) resetNextValidID;
//- (Vector2D) pos;
- (void) setPos;
- (double) BRadius;
- (void) setBRadius;
- (int) ID;

- (bool) isTagged;
- (void) Tag;
- (void) UnTag;

//- (Vector2D) scale;
//- (void) setScale:(Vector2D)val;
//- (void) setScale:(double)val;

- (int) entityType;
- (void) setEntityType:(int)newType;
@end
