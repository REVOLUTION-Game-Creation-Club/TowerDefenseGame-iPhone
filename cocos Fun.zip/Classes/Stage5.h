//
//  Stage5.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 22..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface Stage5 : CCSprite <CCTargetedTouchDelegate> 
{

}

@end
