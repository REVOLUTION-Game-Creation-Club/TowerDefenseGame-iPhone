//
//  Flag3.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 26..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"


@interface Flag3 : CCSpriteSheet 
{
	CCSprite* m_sprite[6];
	CCSprite* m_clear[4];
	
	BOOL m_bClear;
}

-(void)setClear:(BOOL)b;
-(void)FlagSelectAnim;
-(void)FlagClearAnim;
-(void)unVisibleAll;

@end
