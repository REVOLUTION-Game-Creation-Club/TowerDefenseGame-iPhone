//
//  MGameMain4.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 23..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MGameMain4.h"
#import "MBackground.h"
#import "MGameUI.h"
#import "MRightSlot.h"
#import "MUserData.h"
#import "QuickButton1.h"
#import "QuickButton2.h"
#import "QuickButton3.h"
#import "AttackButton.h"
#import "DefenceButton.h"
#import "StopButton.h"

@implementation MGameMain4

@synthesize moneyLabel;
@synthesize stageLabel;

static MGameMain4* g_sharedGM4 = nil;

+ (MGameMain4*)sharedGM 
{
	if (!g_sharedGM4)
		g_sharedGM4 = [MGameMain4 node];
	
	return g_sharedGM4;
}

+(id) scene
{
	// CScene 생성
	CCScene *scene = [CCScene node];
	
	// CScene에 올릴 layer를 생성함
	MGameMain4 *layer = [MGameMain4 node];
	
	// 씬에 차일드로 레이어를 추가
	[scene addChild:layer];
	
	return scene;
}

-(void)spriteMoveFinished:(id)sender
{
	CCSprite *sprite = (CCSprite *)sender;
	[self removeChild:sprite cleanup:YES];
}

-(void)addTarget
{
	CCSprite *target = [CCSprite spriteWithFile:@"mamos.png" rect:CGRectMake(0,0,70,70)];
	
	// 맘모스의 Y축 위치 결정
	CGSize winSize = [[CCDirector sharedDirector] winSize];
	int minY = target.contentSize.height/2;
	int maxY = winSize.height - target.contentSize.height/2;
	int rangeY = maxY - minY;
	int actualY = (arc4random() % rangeY) + minY;
	
	// 오른쪽 끝 화면 밖에 X축 위치와 위에서 결정한 Y축으로 타켓의 포지션 결정
	target.position = ccp(winSize.width + (target.contentSize.width/2), actualY);
	
	[self addChild:target];
	
	// 타겟의 속도 결정
	int minDuration = 2.0;
	int maxDuration = 4.0;
	int rangeDuration = maxDuration - minDuration;
	int actualDuration = (arc4random() % rangeDuration) + minDuration;
	
	// 액션 생성
	id actionMove = [CCMoveTo actionWithDuration:actualDuration position:ccp(-target.contentSize.width/2, actualY)];
	id actionMoveDone = [CCCallFuncN actionWithTarget:self selector:@selector(spriteMoveFinished:)];
	[target runAction:[CCSequence actions:actionMove, actionMoveDone, nil]];
}

-(void)gameLogic:(ccTime)dt
{
	//[self addTarget];
	MBackground *sBG = [MBackground sharedBG];
	int money = [sBG getMoney];
	NSString *str = [[NSString alloc] initWithFormat:@"%d", money];
    [self.moneyLabel setString:str];
    [str release];
	
	//
	if(m_skillAnimation1 > 0)
	{
		//		[right style1Produce:m_styleAnimation1-1];
		m_skillAnimation1++;
		if(m_skillAnimation1 == 5)
		{
			//			[self setStyle:1];
			[quick1 produce:0];
			m_skillAnimation1 = 0;
		}
	}
	
	if(m_skillAnimation2 > 0)
	{
		//		[right style1Produce:m_styleAnimation1-1];
		m_skillAnimation2++;
		if(m_skillAnimation2 == 5)
		{
			//			[self setStyle:1];
			//			[quick style1Produce:0];
			m_skillAnimation2 = 0;
		}
	}
	
	if(m_skillAnimation3 > 0)
	{
		//		[right style1Produce:m_styleAnimation1-1];
		m_skillAnimation3++;
		if(m_skillAnimation3 == 5)
		{
			//			[self setStyle:1];
			//			[quick style1Produce:0];
			m_skillAnimation3 = 0;
		}
	}	
}

- (NSString*)dataFilePath
{
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	return [documentsDirectory stringByAppendingPathComponent:@"archive"];
}

-(id)init
{
	if( (self=[super initWithColor:ccc4(0,255,255,255)] ))
	{
		srand(time(NULL));
		
		MBackground* sBg = [MBackground sharedBG ];
		sBg.position = ccp(480,320/2);
		[self addChild:sBg z:kTagBG];
		
		quick1 = [[QuickButton1 spriteSheetWithFile:@"sk-all.png" capacity:40]init];
		quick1.position = ccp(51, 278);
		[self addChild:quick1 z:kTagUI];
		[quick1 setItem:1];
		
		quick2 = [[QuickButton2 spriteSheetWithFile:@"sk-all.png" capacity:40]init];
		quick2.position = ccp(51, 241);
		[self addChild:quick2 z:kTagUI];
		[quick2 setItem:2];
		
		quick3 = [[QuickButton3 spriteSheetWithFile:@"sk-all.png" capacity:40]init];
		quick3.position = ccp(51, 204);
		[self addChild:quick3 z:kTagUI];
		[quick3 setItem:3];
		
		AttackButton *attackButton = [[AttackButton spriteSheetWithFile:@"go-all.png" capacity:2]init];
		attackButton.position = ccp(457,252);
		[self addChild:attackButton z:kTagUI];
		
		DefenceButton *defenceButton = [[DefenceButton spriteSheetWithFile:@"back-all.png" capacity:2]init];
		defenceButton.position = ccp(457,206);
		[self addChild:defenceButton z:kTagUI];
		
		StopButton *stopButton = [[StopButton spriteSheetWithFile:@"stop-all.png" capacity:2]init];
		stopButton.position = ccp(464,304);
		[self addChild:stopButton z:kTagUI];
		
		//		CGSize winSize = [[CCDirector sharedDirector] winSize];
		//		CCSprite *player = [CCSprite spriteWithFile:@"player.png" rect:CGRectMake(0, 0, 50, 55)];
		//		player.position = ccp(player.contentSize.width/2, winSize.height/2);
		//		[self addChild:player z:kTagChar];
		
		CLeftSlot *leftSlot = [CLeftSlot sharedLeft];
		leftSlot.position = ccp(leftSlot.contentSize.width/2+210,leftSlot.contentSize.height/2);
		[self addChild:leftSlot z:kTagUI];
		
		MRightSlot *rightSlot = [MRightSlot sharedRight];
		rightSlot.position = ccp(480-rightSlot.contentSize.width/2,rightSlot.contentSize.height/2);
		[self addChild:rightSlot z:kTagUI];
		
		
		// 머니라벨
		moneyImg = [CCSprite spriteWithFile:@"gold-coin.png" rect:CGRectMake(0, 0, 19, 19)];
		moneyImg.position = ccp(11,310);
		[self addChild:moneyImg z:1];
		
		CCLabel* label = [[CCLabel alloc] initWithString:@"0" fontName:@"Arial" fontSize:13];
		self.moneyLabel = label;
		self.moneyLabel.anchorPoint = CGPointZero;
		self.moneyLabel.position = ccp(20,300);
		[self addChild:self.moneyLabel z:1];
		[label release];
		
		// 스테이지
		stageImg = [CCSprite spriteWithFile:@"stage-1.png" rect:CGRectMake(0, 0, 53, 14)];
		stageImg.position = ccp(236,310);
		[self addChild:stageImg z:1];
		
		MUserData* ud = [MUserData sharedUserData];
		
		NSData *data1 = [[NSMutableData alloc] initWithContentsOfFile:[self dataFilePath]];
		NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:data1];
		ud.m_iStageNum = [unarchiver decodeIntForKey:@"m_iStageNum"];
		[unarchiver finishDecoding];
		
		[unarchiver release];
		[data1 release];
		
		[self setGameStageNumber:ud.m_iStageNum];
		
		[self schedule:@selector(gameLogic:) interval:0.1];
		
		
		//		MUserData* ud = [MUserData sharedUserData];
		/*
		 NSMutableData *data = [[NSMutableData alloc] init];
		 NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:data];
		 [archiver encodeInt:0 forKey:@"m_iBow1Level"];
		 [archiver encodeInt:0 forKey:@"m_iBow2Level"];
		 [archiver encodeInt:0 forKey:@"m_iBow3Level"];
		 [archiver encodeInt:0 forKey:@"m_iBow4Level"];
		 [archiver encodeInt:0 forKey:@"m_iBow5Level"];
		 
		 [archiver encodeInt:0 forKey:@"m_iShield1Level"];
		 [archiver encodeInt:0 forKey:@"m_iShield2Level"];
		 [archiver encodeInt:0 forKey:@"m_iShield3Level"];
		 [archiver encodeInt:0 forKey:@"m_iShield4Level"];
		 [archiver encodeInt:0 forKey:@"m_iShield5Level"];
		 
		 [archiver encodeInt:0 forKey:@"m_iSword1Level"];
		 [archiver encodeInt:0 forKey:@"m_iSword2Level"];
		 [archiver encodeInt:0 forKey:@"m_iSword3Level"];
		 [archiver encodeInt:0 forKey:@"m_iSword4Level"];
		 [archiver encodeInt:0 forKey:@"m_iSword5Level"];
		 
		 [archiver encodeInt:0 forKey:@"m_iCastleLevel"];
		 [archiver encodeInt:0 forKey:@"m_iIronNum"];
		 [archiver encodeInt:0 forKey:@"m_iWoodNum"];
		 
		 [archiver encodeBool:FALSE forKey:@"m_bWood1"];
		 [archiver encodeBool:FALSE forKey:@"m_bIron1"];
		 [archiver encodeBool:FALSE forKey:@"m_bIron2"];
		 [archiver encodeBool:FALSE forKey:@"m_bIron3"];
		 
		 [archiver encodeBool:FALSE forKey:@"m_bWood1Sold"];
		 [archiver encodeBool:FALSE forKey:@"m_bIron1Sold"];
		 [archiver encodeBool:FALSE forKey:@"m_bIron2Sold"];
		 [archiver encodeBool:FALSE forKey:@"m_bIron3Sold"];
		 
		 [archiver encodeInt:0 forKey:@"m_iSkill1Level"];
		 [archiver encodeInt:0 forKey:@"m_iSkill2Level"];
		 [archiver encodeInt:0 forKey:@"m_iSkill3Level"];
		 [archiver encodeInt:0 forKey:@"m_iSkill4Level"];
		 [archiver encodeInt:0 forKey:@"m_iSkill5Level"];
		 [archiver encodeInt:0 forKey:@"m_iSkill6Level"];
		 
		 [archiver encodeInt:0 forKey:@"m_iQuickSlot1"];
		 [archiver encodeInt:0 forKey:@"m_iQuickSlot2"];
		 [archiver encodeInt:0 forKey:@"m_iQuickSlot3"];
		 
		 [archiver encodeInt:0 forKey:@"m_iQuickSlot1Num"];
		 [archiver encodeInt:0 forKey:@"m_iQuickSlot2Num"];
		 [archiver encodeInt:0 forKey:@"m_iQuickSlot3Num"];
		 
		 [archiver finishEncoding];
		 [data writeToFile:[self dataFilePath] atomically:YES];
		 [archiver release];
		 [data release];
		 */
		
		m_skillAnimation1 = 0;
		m_skillAnimation2 = 0;
		m_skillAnimation3 = 0;
	}
	
	return self;
}

-(void) setGameStageNumber:(int)num
{
	CCLabel* label1;
	if(num == 1)
	{
		label1 = [[CCLabel alloc] initWithString:@"01" fontName:@"Arial" fontSize:13];
	}
	else if(num == 2)
	{
		label1 = [[CCLabel alloc] initWithString:@"02" fontName:@"Arial" fontSize:13];
	}
	else if(num == 3)
	{
		label1 = [[CCLabel alloc] initWithString:@"03" fontName:@"Arial" fontSize:13];
	}
	else if(num == 4)
	{
		label1 = [[CCLabel alloc] initWithString:@"04" fontName:@"Arial" fontSize:13];
	}	
	else if(num == 5)
	{
		label1 = [[CCLabel alloc] initWithString:@"05" fontName:@"Arial" fontSize:13];
	}
	else if(num == 6)
	{
		label1 = [[CCLabel alloc] initWithString:@"06" fontName:@"Arial" fontSize:13];
	}
	else if(num == 7)
	{
		label1 = [[CCLabel alloc] initWithString:@"07" fontName:@"Arial" fontSize:13];
	}
	
	self.stageLabel = label1;
	self.stageLabel.anchorPoint = CGPointZero;
	self.stageLabel.position = ccp(265,300);
	[self addChild:self.stageLabel z:1];
	[label1 release];	
}
-(void) closeGameMain
{
	[moneyLabel release];
	[self unschedule:@selector(gameLogic:)];
	[[CCTextureCache sharedTextureCache] removeUnusedTextures];
}

-(void) dealloc
{
	[super dealloc];
}

-(void) setSkillAnim:(int)type
{
	switch (type) 
	{
		case 1:
			m_skillAnimation1 = 1;
			break;
		case 2:
			m_skillAnimation2 = 1;
			break;
		case 3:
			m_skillAnimation3 = 1;
			break;
		default:
			break;
	}
}

@end
