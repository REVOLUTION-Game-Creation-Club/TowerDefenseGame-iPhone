//
//  MHorseProduceState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 22..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MHorseProduceState.h"
#import "MLeftSlot.h"
#import "MHorseman.h"

@implementation MHorseProduceState

- (void)Enter:(id)owner
{
	m_iProduceTime = 0;
	MHorseman *horseman = owner;
	[horseman setPosition:CGPointMake(58,160)];
}

- (void)Execute:(id)owner
{
	//
	MHorseman *horseman = owner;
	MLeftSlot *left = [horseman getLeftSlot];
	
	m_iProduceTime++;
	for(int i = 1; i < 13; i++)
	{
		if(m_iProduceTime <5*i*10)
		{
			[left item3Produce:i];
			break;
		}
	}
	if(m_iProduceTime == 60*10)
	{
		MHorseman *horseman = owner;
		m_iProduceTime = 0;
		[left item3Produce:0];
		[horseman changeWaitState];
		[left produce3Complete];
	}
}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"MHorseProduceState";
}

@end
