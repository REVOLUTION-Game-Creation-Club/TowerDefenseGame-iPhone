//
//  BaseEntity.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 11..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MBaseEntity.h"


@implementation MBaseEntity
- (void) update
{

}

- (BOOL) handleMesage
{
	return TRUE;
}

+ (int) getNextValidID
{
	return -1;
}

+ (void) resetNextValidID
{

}

//- (Vector2D) pos
//{
//	return Vector2D(0.0,0.0);
//}

- (void) setPos
{
	
}

- (double) BRadius
{
	return -0.1;
}

- (void) setBRadius
{
	
}

- (int) ID
{
	return -1;
}

- (bool) isTagged
{
	
	return true;
}

- (void) Tag
{
	
}

- (void) UnTag
{
	
}

//- (Vector2D) scale
//{
//	return Vector2D
//}

//- (void) setScale:(Vector2D)val
//{
//	
//}

- (void) setScale:(double)val
{
	
}

- (int) entityType
{
	return -1.0;
}

- (void) setEntityType:(int)newType
{
}

@end
