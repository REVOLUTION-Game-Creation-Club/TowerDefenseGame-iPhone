//
//  MBowProduceState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 22..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MBowProduceState.h"
#import "MLeftSlot.h"
#import "MBowman.h"

@implementation MBowProduceState

- (void)Enter:(id)owner
{
	m_iProduceTime = 0;
	MBowman *bowman = owner;
	[bowman setPosition:CGPointMake(58,160)];
}

- (void)Execute:(id)owner
{
	//
	MBowman* bowman = owner;
	MLeftSlot *left = [bowman getLeftSlot];
	
	for(int i = 0; i < 13; i++)
	{
		if(m_iProduceTime <= 5*4*i)
		{
			[left item2Produce:i];
			break;
		}
	}

	m_iProduceTime++;

	if(m_iProduceTime == 60*4)
	{
		MBowman *bowman = owner;
		m_iProduceTime = 0;
		[left item2Produce:0];
		[bowman changeWaitState];
		[left produce2Complete];
	}

}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"MBowProduceState";
}

@end
