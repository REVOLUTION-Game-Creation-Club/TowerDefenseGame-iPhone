//
//  MRightSlot.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 24..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MRightSlot.h"
#import "MLeftSlot.h"
#import "MStyleButton1.h"
#import "MStyleButton2.h"
#import "MStyleButton3.h"
#import "MStyleButton4.h"
#import "MAttackDefenceButton.h"

@implementation MRightSlot

/*
static MRightSlot* g_sharedRight = nil;

+ (MRightSlot*)sharedRight
{
	if (!g_sharedRight)
		g_sharedRight = [MRightSlot spriteWithFile:@"left_slot.png" rect:CGRectMake(0, 0, 40, 40)];
	
	return g_sharedRight;
}
*/
-(id)init
{
	if((self=[super init]))
	{
		bFold = TRUE;
		//[self initItem];
	}
	
	return self;
}

-(void)initItem
{
	bar = [CCSprite spriteWithFile:@"right_bar.png" rect:CGRectMake(0, 0, 210, 40)];
	bar.position = ccp(bar.contentSize.width/2+self.contentSize.width+0, bar.contentSize.height/2);
	[self addChild:bar z:0];
	
	style1 = [[MStyleButton1 spriteSheetWithFile:@"am1-all.png" capacity:15] init];
	[style1 setBackground:m_background];
	style1.position = ccp(23,17);
	[bar addChild:style1];
	
	style2 = [[MStyleButton2 spriteSheetWithFile:@"am2-all.png" capacity:15]init];
	[style2 setBackground:m_background];
	style2.position = ccp(66,17);
	[bar addChild:style2];
	
	style3 = [[MStyleButton3 spriteSheetWithFile:@"am3-all.png" capacity:15]init];
	[style3 setBackground:m_background];
	style3.position = ccp(108,17);
	[bar addChild:style3];
	
	style4 = [[MStyleButton4 spriteSheetWithFile:@"am4-all.png" capacity:15]init];
	[style4 setBackground:m_background];
	style4.position = ccp(150,17);
	[bar addChild:style4];

	/*
	attackDefence = [[MAttackDefenceButton spriteSheetWithFile:@"am56-all.png" capacity:15]init];
	attackDefence.position = ccp(192,17);
	[bar addChild:attackDefence];
	*/
}

- (CGRect)rect
{
	CGSize s = [self.texture contentSize];
	//NSLog(@"rect(%f,%f,%f,%f)\n",-s.width/2, -s.height/2, s.width, s.height);
	
	return CGRectMake(-s.width/2, -s.height/2, s.width,s.height);
}

- (void)onEnter
{
	[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
	[super onEnter];
}

- (void)onExit
{
	[[CCTouchDispatcher sharedDispatcher] removeDelegate:self];
	[super onExit];
}

- (BOOL)containsTouchLocation:(UITouch *)touch
{
	//NSLog(@"touch(%f,%f",pt.x, pt.y);
	
	return CGRectContainsPoint(self.rect, [self convertTouchToNodeSpaceAR:touch]);
}

- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{
	if ( ![self containsTouchLocation:touch] ) return NO;
	
	
	//	NSLog(@"click\n");
	//TODO: 바를 지우고 자신의 그림을 바꾼다.
	if(bFold)
	{
		//		[self removeChild:item2 cleanup:YES];
		//		[self removeChild:item cleanup:YES];
		//		[self removeChild:bar cleanup:YES];
		[self fold];
	}
	
	else
	{
		//		[self initItem];
		[self setPosition:CGPointMake(480-self.contentSize.width/2-170,self.contentSize.height/2)];
		bFold = TRUE;
		//MLeftSlot* left = [MLeftSlot sharedLeft];
		[m_leftSlot fold];
	}
	
	return YES;
}

- (void)fold
{
	[self setPosition:CGPointMake(480-self.contentSize.width/2,self.contentSize.height/2)];
	bFold = FALSE;	
}

- (void)ccTouchMoved:(UITouch *)touch withEvent:(UIEvent *)event
{
	
}

- (void)ccTouchEnded:(UITouch *)touch withEvent:(UIEvent *)event
{
	
}

-(void)style1Produce:(int)percent
{
	[style1 produce:percent];
}

-(void)style2Produce:(int)percent
{
	[style2 produce:percent];
}

-(void)style3Produce:(int)percent
{
	[style3 produce:percent];	
}

-(void)style4Produce:(int)percent
{
	[style4 produce:percent];	
}

-(void)attackProduce:(int)percent
{
	[attackDefence attackProduce:percent];	
}

-(void)defenceProduce:(int)percent
{
	[attackDefence defenceProduce:percent];	
}

-(void) setBackground:(MBackground*)bg
{
	m_background = bg;
}

-(void) setLeftSlot:(MLeftSlot*)slot
{
	m_leftSlot = slot;
}

@end
