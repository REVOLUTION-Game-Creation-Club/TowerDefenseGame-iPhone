//
//  Boss5DeathState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 24..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Boss5DeathState.h"
#import "Boss5.h"

@implementation Boss5DeathState

- (void)Enter:(id)owner
{
	m_iCount = 0;
	Boss5 *boss5 = owner;
	[boss5 unvisibleAll];
}

- (void)Execute:(id)owner
{
	Boss5 *boss5 = owner;
	if(m_iCount == 0)
	{
		[boss5 DeathAnimation];
	}
	m_iCount++;
	
	if(m_iCount == 30)
		m_iCount = 0;

}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"Boss1DeathState";
}

@end
