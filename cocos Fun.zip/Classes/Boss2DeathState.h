//
//  Boss2DeathState.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 24..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MState.h"

@interface Boss2DeathState : MState 
{
	int m_iCount;
}

- (void)Enter:(id)owner;
- (void)Execute:(id)owner;
- (void)Exit:(id)owner;
- (NSString*)name;

@end
