//
//  BowWaitState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 21..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MEBowWaitState.h"
#import "MEBowman.h"
#import "MBackground.h"

@implementation MEBowWaitState

- (void)Enter:(id)owner
{
	m_iCount = 0;
	MEBowman *bowman = owner;
	switch ([bowman getFormation]) 
	{
		case STYLE_NO:
			x = 960-100;
			y = rand()%220+50;
			break;
		case STYLE_1:
			x = 960-(rand()%40+120);
			y = rand()%300+10;
			break;
		case STYLE_2:
			x = 960-(rand()%40+120);
			if(rand()%2 == 0)
				y = rand()%130+10;
			else 
				y = rand()%130+180;
			break;
		case STYLE_3:
			switch (rand()%6) 
			{
				case 0:
					x = 960-(rand()%100+180);
					y = rand()%50+10;
					break;
				case 1:
					x = 960-(rand()%120+120);
					y = rand()%40+60;
					break;
				case 2:
					x = 960-(rand()%60+120);
					y = rand()%40+100;
					break;
				case 3:
					x = 960-(rand()%60+120);
					y = rand()%40+180;
					break;
				case 4:
					x = 960-(rand()%100+120);
					y = rand()%40+220;
					break;
				case 5:
					x = 960-(rand()%100+180);
					y = rand()%50+260;
					break;
			}
			break;
		case STYLE_4:
			if(rand()%2== 0)
			{
				x = 960-(rand()%40+120);
				y = rand()%110+10;
			}
			else 
			{
				x = 960-(rand()%40+120);
				y = rand()%110+200;
			}

			break;
	}
	
	[bowman unvisibleAll];
}

- (void)Execute:(id)owner
{
	MEBowman *bowman = owner;
	if(m_iCount== 0)
	{
		[bowman WaitAnimation];
	}
	m_iCount++;
	if(m_iCount == 60)
		m_iCount = 0;
	
	//
	
	MEBowman* sprite = owner;
	
	if(( sprite.position.x > x-1)&&(sprite.position.y < y+1)&&
	   ( sprite.position.x < x+1)&&(sprite.position.y > y-1))
	{
		[sprite setRotation:0];
		[sprite setPosition:CGPointMake(x, y)];
	}
	
	else 
	{
		float dx = x - sprite.position.x;
		float dy = y - sprite.position.y;
		
		dx=dx/sqrt(dx*dx+dy*dy);
		dy=dy/sqrt(dx*dx+dy*dy);
		if(dx <=0)
		{
			[sprite setFlipX:TRUE];
		}
		
		[sprite setRotation:atan(dy/dx)*-180/3.14];
		[sprite setPosition:CGPointMake(sprite.position.x+dx, sprite.position.y+dy)];
	}
}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"MEBowWaitState";
}


@end
