//
//  MAttackState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 14..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MWalkAttackState.h"
#import "MWalkman.h"

@implementation MWalkAttackState

- (void)Enter:(id)owner
{
	m_iCount = 0;
	MWalkman *walkman = owner;
	[walkman unvisibleAll];
}

- (void)Execute:(id)owner
{
	MWalkman *walkman = owner;
	if(m_iCount == 0)
	{
		[walkman AttackAnimation];
	}
	m_iCount++;	

	if(m_iCount == 30)
	{
		m_iCount = 0;
	}

	MUnit *enemy = [walkman getTargetUnit];
	if(enemy)
	{
		[enemy suffer:1];
	}
	else 
	{
		[walkman go];
	}
}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"MWalkAttackState";
}

@end
