//
//  MStyleButton2.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 24..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@class MBackground;


@interface MStyleButton2 : CCSpriteSheet <CCTargetedTouchDelegate> 
{
	CCSprite* m_sprite[4];
	
	MBackground* m_background;
}

-(id) init;
-(void) produce:(int)percent;
-(void)unvisibleAll;

-(void) setBackground:(MBackground*)bg;

@end
