//
//  Boss1MoveState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 24..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Boss1MoveState.h"
#import "Boss1.h"

@implementation Boss1MoveState

- (void)Enter:(id)owner
{
	m_iCount = 0;
	Boss1* boss1 = owner;
	[boss1 unvisibleAll];
}

- (void)Execute:(id)owner
{
	Boss1 *boss1 = owner;
	if(m_iCount==0)
	{
		[boss1 MoveAnimation];
	}
	m_iCount++;
	
	if(m_iCount == 30)
		m_iCount = 0;
	//
	
	//CGPoint pt = [sprite getPosition];
	
	float y = boss1.position.y;
	if(boss1.position.y >= (320-boss1.contentSize.height/2))
	{
		y = 320 - boss1.contentSize.height/2;
	}
	
//	[boss1 setFlipX:FALSE];
	
	[boss1 setRotation:0];
	[boss1 setPosition:CGPointMake(boss1.position.x-0.33, y)];
}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"Boss1MoveState";
}

@end
