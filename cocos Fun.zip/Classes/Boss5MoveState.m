//
//  Boss5MoveState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 24..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Boss5MoveState.h"
#import "Boss5.h"

@implementation Boss5MoveState

- (void)Enter:(id)owner
{
	m_iCount = 0;
	Boss5* boss5 = owner;
	[boss5 unvisibleAll];
}

- (void)Execute:(id)owner
{
	Boss5 *boss5 = owner;
	if(m_iCount==0)
	{
		[boss5 MoveAnimation];
	}
	m_iCount++;
	
	if(m_iCount == 30)
		m_iCount = 0;
	//
	
	//CGPoint pt = [sprite getPosition];
	
	float y = boss5.position.y;
	if(boss5.position.y >= (320-boss5.contentSize.height/2))
	{
		y = 320 - boss5.contentSize.height/2;
	}
	
	//[boss5 setFlipX:FALSE];
	
	[boss5 setRotation:0];
	[boss5 setPosition:CGPointMake(boss5.position.x-0.33, y)];	
}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"Boss1MoveState";
}

@end
