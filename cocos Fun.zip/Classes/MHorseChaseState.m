//
//  MHorseChaseState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 21..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MHorseChaseState.h"
#import "MHorseman.h"

@implementation MHorseChaseState

- (void)Enter:(id)owner
{
	m_iCount = 0;
}

- (void)Execute:(id)owner
{
	MHorseman *horseman = owner;

	if(m_iCount==0)
	{
		[horseman MoveAnimation];
	}
	m_iCount++;
	if(m_iCount == 30)
		m_iCount = 0;
	
	
	CGPoint pt = [horseman getChasePoint];
	
	float dx = pt.x - horseman.position.x;
	float dy = pt.y - horseman.position.y;
	
	dx=dx/sqrt(dx*dx+dy*dy);
	dy=dy/sqrt(dx*dx+dy*dy);
//	if(dx <0)
//	{
//		[horseman setFlipX:TRUE];
//	}
	
	if(dx != 0)
	{
		[horseman setRotation:atan(dy/dx)*-90/3.14];
	}
	
	[horseman setPosition:CGPointMake(horseman.position.x+dx*1.5, horseman.position.y+dy*1.5)];	
}

- (void)Exit:(id)owner
{
	MHorseman *horseman = owner;
	[horseman unvisibleAll];
}

- (NSString*)name
{
	return @"MChaseState";
}

@end
