//
//  StateMachine.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 11..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MStateMachine.h"
#import "MWalkMoveState.h"

@implementation MStateMachine

-(id) init
{
	if( (self=[super init] )) 
	{
		//m_pOwner = nil;
		m_pCurrentState = nil;	// 이 인스턴스를 소유한 에이전트의 포인터
		m_pPreviousState = nil;	// 에이전트가 있었던 최근 상태의 기록
		m_pGlobalState = nil;		// FSM이 업데이트될때 항상 호출된다.		
	}
	return self;
}

-(void) setOwner:(id)owner
{
	m_pOwner = owner;
}

-(void) setCurrentState:(MState*)state
{
	m_pCurrentState = state;
}

-(void) setGlobalState:(MState*)state
{
	m_pGlobalState = state;
}

-(void) setPreviousState:(MState*)state
{	
	m_pPreviousState = state;
}

-(void) update
{
	if (m_pGlobalState)
	{
		[m_pGlobalState Execute:m_pOwner];
	}
	
	if (m_pCurrentState)
	{
		[m_pCurrentState Execute:m_pOwner];
	}
}

-(void) changeState:(MState*)new_state
{
	if ([[m_pCurrentState name] isEqualToString:[new_state name]])
		return;
	if (new_state)
	{
		m_pPreviousState = m_pCurrentState;
		
		[m_pCurrentState Exit:m_pOwner];

		m_pCurrentState = new_state;
	
		[m_pCurrentState Enter:m_pOwner];
	}
}

-(void) RevertToPreviousState
{
	[self changeState:m_pPreviousState];
}

-(BOOL) isInState:(MState*)state
{
	//if(m_pCurrent->typeid == state->typeid)
	// return TRUE;
	
	return FALSE;
}

-(MState*) CurrentState
{
	return m_pCurrentState;
}

-(MState*) GlobalState
{
	return m_pGlobalState;
}
-(MState*) PreviousState
{
	return m_pPreviousState;
}

-(NSString*) name
{
	return [m_pCurrentState name];
}

@end
