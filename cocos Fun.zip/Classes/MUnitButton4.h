//
//  MUnitButton4.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 24..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@class MBackground;

@interface MUnitButton4 : CCSpriteSheet <CCTargetedTouchDelegate> 
{
	BOOL bProudceOK;
	CCSprite* m_sprite[13];
	
	MBackground* m_background;
}

-(id) init;
-(void) produce:(int)percent;
-(void)unvisibleAll;
-(void) produceComplete;
-(void) setBackground:(MBackground*)bg;


@end
