//
//  MBowState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 21..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MBowAttackState.h"
#import "MBackground.h"
#import "MEWalkman.h"
#import "MBowman.h"
#import "MBackground.h"

@implementation MBowAttackState

- (id)init
{
	if( (self=[super init] )) 
	{
	}
	
	return self;
}

- (void)Enter:(id)owner
{
	MBowman *bowman = owner;

	m_arrow = [CCSprite spriteWithFile:@"arrow.png" rect:CGRectMake(0,0,10,1)];
	//MBackground *sBG = [MBackground sharedBG];
	MBackground* bg = [bowman getBackground];
	[bg addChild:m_arrow z:3 tag:0];
	
	[m_arrow setPosition:CGPointMake(bowman.position.x, bowman.position.y)];
	m_arrow.visible = TRUE;
	m_iCount = 0;
	m_iAttackCount = 0;
	[bowman unvisibleAll];
}

- (void)Execute:(id)owner
{
	MBowman *bowman = owner;
	if(m_iCount==0)
	{
		[bowman AttackAnimation];
	}
	m_iCount++;
	if(m_iCount == 60)
		m_iCount = 0;
	
	
	m_iAttackCount++;
	if(m_iAttackCount < 60)
		return;
	CGPoint pt = [bowman getTarget];
	
	float dx = pt.x - m_arrow.position.x;
	float dy = pt.y - m_arrow.position.y;
	
	dx = dx / 10;
	dy = dy / 10;
	
	NSLog(@"%f %f \n", dx, dy);
	[m_arrow setPosition:CGPointMake(m_arrow.position.x+dx, m_arrow.position.y+dy)];
	//	[m_sprite setPosition:CGPointMake(m_sprite.position.x+dx, 160)];
	[m_arrow setRotation:atan(dy/dx)*-180/3.14];
	
	[bowman setRotation:atan(dy/dx)*-180/3.14];

	if((m_arrow.position.x < pt.x+8)&&(m_arrow.position.x > pt.x-8)&&
	   (m_arrow.position.y < pt.y+8)&&(m_arrow.position.y > pt.y-8))
	{
		m_arrow.visible = FALSE;
		[m_arrow setPosition:CGPointMake(bowman.position.x, bowman.position.y)];
		MUnit *enemy = [bowman getTargetUnit];

		if(enemy)
		{
			[enemy suffer:1];
		}
		else 
		{
			[bowman go];
		}
		
		[self Enter:owner];
	}	
}

- (void)Exit:(id)owner
{
	MBowman *bowman = owner;
	[bowman unvisibleAll];
}

- (NSString*)name
{
	return @"MBowAttackState";
}

@end
