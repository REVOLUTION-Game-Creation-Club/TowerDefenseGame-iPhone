//
//  MEProduceState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 22..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MEProduceState.h"
#import "MEWalkman.h"

@implementation MEProduceState

- (void)Enter:(id)owner
{
	m_iProduceTime = 0;
}

- (void)Execute:(id)owner
{	
	m_iProduceTime++;
	
	if(m_iProduceTime == 60)
	{
		MEWalkman *walkman = owner;
		m_iProduceTime = 0;
		[walkman changeWaitState];
	}
}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"MEProduceState";
}


@end
