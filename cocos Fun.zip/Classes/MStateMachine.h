//
//  StateMachine.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 11..
//  Copyright t __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MState;

@interface MStateMachine : NSObject 
{
	id			m_pOwner;
	MState*		m_pCurrentState;	// 이 인스턴스를 소유한 에이전트의 포인터
	MState*		m_pPreviousState;	// 에이전트가 있었던 최근 상태의 기록
	MState*		m_pGlobalState;		// FSM이 업데이트될때 항상 호출된다.
}

-(void) setOwner:(id)owner;
-(void) setCurrentState:(MState*)state;
-(void) setGlobalState:(MState*)state;
-(void) setPreviousState:(MState*)state;
-(void) update;
-(void) changeState:(MState*)new_state;
-(void) RevertToPreviousState;
-(BOOL) isInState:(MState*)state;

-(MState*) CurrentState;
-(MState*) GlobalState;
-(MState*) PreviousState;
-(NSString*) name;

@end