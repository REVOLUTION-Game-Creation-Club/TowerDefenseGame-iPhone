//
//  Boss6MoveState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 24..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Boss6MoveState.h"
#import "Boss6.h"

@implementation Boss6MoveState

- (void)Enter:(id)owner
{
	m_iCount = 0;
	Boss6* boss6 = owner;
	[boss6 unvisibleAll];
}

- (void)Execute:(id)owner
{
	Boss6 *boss6 = owner;
	if(m_iCount==0)
	{
		[boss6 MoveAnimation];
	}
	m_iCount++;
	
	if(m_iCount == 30)
		m_iCount = 0;
	//
	
	//CGPoint pt = [sprite getPosition];
	
	float y = boss6.position.y;
	if(boss6.position.y >= (320-boss6.contentSize.height/2))
	{
		y = 320 - boss6.contentSize.height/2;
	}
	
	//[boss6 setFlipX:FALSE];
	
	[boss6 setRotation:0];
	[boss6 setPosition:CGPointMake(boss6.position.x-0.33, y)];
}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"Boss1MoveState";
}

@end
