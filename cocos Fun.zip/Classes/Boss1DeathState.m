//
//  Boss1DeathState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 24..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Boss1DeathState.h"
#import "Boss1.h"

@implementation Boss1DeathState

- (void)Enter:(id)owner
{
	m_iCount = 0;
	Boss1 *boss1 = owner;
	[boss1 unvisibleAll];
}

- (void)Execute:(id)owner
{
	Boss1 *boss1 = owner;
	if(m_iCount == 0)
	{
		[boss1 DeathAnimation];
	}
	m_iCount++;
	
	if(m_iCount == 30)
		m_iCount = 0;
}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"Boss1DeathState";
}

@end
