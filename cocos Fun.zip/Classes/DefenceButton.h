//
//  DefenceButton.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 17..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@class MBackground;

@interface DefenceButton : CCSpriteSheet <CCTargetedTouchDelegate> 
{
	CCSprite* m_sprite;
	CCSprite* m_spriteOn;

	MBackground *m_background;
}

-(void) setBackground:(MBackground*)bg;

@end
