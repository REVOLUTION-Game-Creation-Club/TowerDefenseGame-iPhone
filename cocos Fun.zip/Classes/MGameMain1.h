//
//  GameMain.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 4..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@class MBackground;
@class QuickButton1;
@class QuickButton2;
@class QuickButton3;
@class MBackground;
@class MLeftSlot;
@class MRightSlot;

enum {
    kTagBG = 0,
    kTagChar = 1,
    kTagUI = 2,
};


@interface MGameMain1 : CCColorLayer 
{
	CCSprite *moneyImg;
	CCLabel *moneyLabel;
	CCSprite *stageImg;
	CCLabel *stageLabel;
	
	QuickButton1 *quick1;
	QuickButton2 *quick2;
	QuickButton3 *quick3;
	
	int m_skillAnimation1;
	int m_skillAnimation2;
	int m_skillAnimation3;
	
	MBackground* m_background;
	
	MLeftSlot *leftSlot;
	MRightSlot *rightSlot;
	
	int m_iStageNum;
}

@property (nonatomic, retain) CCLabel *moneyLabel;
@property (nonatomic, retain) CCLabel *stageLabel;

+(id) scene;
//+ (MGameMain1*)sharedGM;

//-(void)clearGM;

-(void) setGameStageNumber:(int)num;
-(void) setSkillAnim:(int)type;
-(void) WinGame;
-(int) getStageNum;

- (NSString*)dataFilePath1;
- (NSString*)dataFilePath2;
@end
