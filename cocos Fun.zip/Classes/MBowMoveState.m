//
//  MBowMoveState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 28..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MBowMoveState.h"
#import "MBowman.h"

@implementation MBowMoveState

- (void)Enter:(id)owner
{
	MBowman *bowman = owner;

	m_iCount = 0;
	
	[bowman unvisibleAll];
}

- (void)Execute:(id)owner
{
	MBowman *bowman = owner;
	if(m_iCount==0)
	{
		[bowman MoveAnimation];
	}
	m_iCount++;

	if(m_iCount == 30)
		m_iCount = 0;

	//CGPoint pt = [sprite getPosition];
	MBowman* sprite = owner;
	
	float y = sprite.position.y;
	if(sprite.position.y >= (320 -sprite.contentSize.height/2))
	{
		y = 320 - sprite.contentSize.height/2;
	}
	
	[sprite setFlipX:FALSE];
	
	
	[sprite setRotation:0];
	[sprite setPosition:CGPointMake(sprite.position.x+0.33, y)];
}

- (void)Exit:(id)owner
{
	MBowman* bowman = owner;
	[bowman unvisibleAll];
}

- (NSString*)name
{
	return @"MMoveState";
}

@end
