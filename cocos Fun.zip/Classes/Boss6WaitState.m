//
//  Boss6WaitState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 24..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Boss6WaitState.h"
#import "Boss6.h"

@implementation Boss6WaitState

- (void)Enter:(id)owner
{
	m_iCount = 0;
	
	x = 100;
	y = 480/2;
	
	Boss6* boss6 = owner;
	[boss6 unvisibleAll];
}

- (void)Execute:(id)owner
{
	Boss6 *boss6 = owner;
	if(m_iCount== 0)
	{
		[boss6 WaitAnimation];
	}
	m_iCount++;
	if(m_iCount == 30)
		m_iCount = 0;
	
	//
	
	Boss6* sprite = owner;
	
	if(( sprite.position.x > x-1)&&(sprite.position.y < y+1)&&
	   ( sprite.position.x < x+1)&&(sprite.position.y > y-1))
	{
		[sprite setFlipX:FALSE];
		[sprite setRotation:0];
		[sprite setPosition:CGPointMake(x, y)];
	}
	
	else 
	{
		float dx = x - sprite.position.x;
		float dy = y - sprite.position.y;
		
		dx=dx/sqrt(dx*dx+dy*dy);
		dy=dy/sqrt(dx*dx+dy*dy);
		if(dx <0)
		{
			[sprite setFlipX:TRUE];
		}
		
		[sprite setRotation:atan(dy/dx)*-180/3.14];
		[sprite setPosition:CGPointMake(sprite.position.x+dx, sprite.position.y+dy)];
	}
}

- (void)Exit:(id)owner
{
	
}

- (NSString*)name
{
	return @"Boss1WaitState";
}

@end
