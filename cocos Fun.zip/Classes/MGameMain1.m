//
//  GameMain.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 4..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MGameMain1.h"
#import "MBackground.h"
#import "MLeftSlot.h"
#import "MRightSlot.h"
#import "MUserData.h"
#import "QuickButton1.h"
#import "QuickButton2.h"
#import "QuickButton3.h"
#import "AttackButton.h"
#import "DefenceButton.h"
#import "StopButton.h"
#import "MResult.h"
#import "MStageData.h"

@implementation MGameMain1

@synthesize moneyLabel;
@synthesize stageLabel;


/*
static MGameMain1* g_sharedGM = nil;

+ (MGameMain1*)sharedGM 
{
	if (!g_sharedGM)
		g_sharedGM = [MGameMain1 node];
	
	return g_sharedGM;
}
*/

/*
-(void)clearGM
{
	g_sharedGM = nil;
}
*/

+(id) scene
{
	// CScene 생성
	CCScene *scene = [CCScene node];
	
	// CScene에 올릴 layer를 생성함
	MGameMain1 *layer = [MGameMain1 node];
	
	// 씬에 차일드로 레이어를 추가
	[scene addChild:layer];
	
	return scene;
}

-(void)spriteMoveFinished:(id)sender
{
	CCSprite *sprite = (CCSprite *)sender;
	[self removeChild:sprite cleanup:YES];
}
/*
-(void)addTarget
{
	CCSprite *target = [CCSprite spriteWithFile:@"mamos.png" rect:CGRectMake(0,0,70,70)];
	
	// 맘모스의 Y축 위치 결정
	CGSize winSize = [[CCDirector sharedDirector] winSize];
	int minY = target.contentSize.height/2;
	int maxY = winSize.height - target.contentSize.height/2;
	int rangeY = maxY - minY;
	int actualY = (arc4random() % rangeY) + minY;
	
	// 오른쪽 끝 화면 밖에 X축 위치와 위에서 결정한 Y축으로 타켓의 포지션 결정
	target.position = ccp(winSize.width + (target.contentSize.width/2), actualY);
	
	[self addChild:target];
	
	// 타겟의 속도 결정
	int minDuration = 2.0;
	int maxDuration = 4.0;
	int rangeDuration = maxDuration - minDuration;
	int actualDuration = (arc4random() % rangeDuration) + minDuration;
	
	// 액션 생성
	id actionMove = [CCMoveTo actionWithDuration:actualDuration position:ccp(-target.contentSize.width/2, actualY)];
	id actionMoveDone = [CCCallFuncN actionWithTarget:self selector:@selector(spriteMoveFinished:)];
	[target runAction:[CCSequence actions:actionMove, actionMoveDone, nil]];
}
*/
-(void)gameLogic:(ccTime)dt
{
	//[self addTarget];
	int money = [m_background getMoney];
	
	
	NSString *str = [[NSString alloc] initWithFormat:@"%d", money];
    [self.moneyLabel setString:str];
    [str release];
	
	//
	if(m_skillAnimation1 > 0)
	{
		if(m_skillAnimation1 == 1)
		{
			[quick1 trigger];
		}
		
		[quick1 produce:m_skillAnimation1];
		m_skillAnimation1++;
		
		if(m_skillAnimation1 == 10)
		{
			[quick1 produce:0];
			m_skillAnimation1 = 0;
		}
	}

	if(m_skillAnimation2 > 0)
	{
		if(m_skillAnimation2 == 1)
		{
			[quick2 trigger];
		}
		
		[quick2 produce:m_skillAnimation2];
		m_skillAnimation2++;
		
		if(m_skillAnimation2 == 11)
		{
			[quick2 produce:0];
			m_skillAnimation2 = 0;
		}
	}
	
	if(m_skillAnimation3 > 0)
	{
		if(m_skillAnimation3 == 1)
		{
			[quick3 trigger];
		}
		
		[quick3 produce:m_skillAnimation3];
		m_skillAnimation3++;
		
		if(m_skillAnimation3 == 10)
		{
			[quick3 produce:0];
			m_skillAnimation3 = 0;
		}
	}
}

- (NSString*)dataFilePath1
{
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	return [documentsDirectory stringByAppendingPathComponent:@"archive"];
}

- (NSString*)dataFilePath2
{
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	return [documentsDirectory stringByAppendingPathComponent:@"archive2"];
}

-(id)init
{
	if( (self=[super initWithColor:ccc4(0,255,255,255)] ))
	{

		MStageData* ud = [MStageData sharedStageData];
		
		NSData *data2 = [[NSMutableData alloc] initWithContentsOfFile:[self dataFilePath2]];
		NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:data2];
		
//		ud.m_iStage1Clear = [unarchiver decodeBoolForKey:@"m_iStage1Clear"];
//		ud.m_iStage2Clear = [unarchiver decodeBoolForKey:@"m_iStage2Clear"];
//		ud.m_iStage3Clear = [unarchiver decodeBoolForKey:@"m_iStage3Clear"];
//		ud.m_iStage4Clear = [unarchiver decodeBoolForKey:@"m_iStage4Clear"];
//		ud.m_iStage5Clear = [unarchiver decodeBoolForKey:@"m_iStage5Clear"];
//		ud.m_iStage6Clear = [unarchiver decodeBoolForKey:@"m_iStage6Clear"];
//		ud.m_iStage7Clear = [unarchiver decodeBoolForKey:@"m_iStage7Clear"];
		
		ud.m_iStageNum = [unarchiver decodeIntForKey:@"m_iStageNum"];
		[unarchiver finishDecoding];
		
		[unarchiver release];
		[data2 release];

		m_iStageNum = ud.m_iStageNum;
		
		srand(time(NULL));
		
		//MBackground* sBg = [MBackground sharedBG ];
		switch (m_iStageNum) 
		{
			case 1:
				m_background = [MBackground spriteWithFile:@"ip_map1.png"];
				break;
			case 2:
				m_background = [MBackground spriteWithFile:@"ip_map2.png"];
				break;
			case 3:
				m_background = [MBackground spriteWithFile:@"ip_map3.png"];
				break;
			case 4:
				m_background = [MBackground spriteWithFile:@"ip_map4.png"];
				break;
			case 5:
				m_background = [MBackground spriteWithFile:@"ip_map5.png"];
				break;
			case 6:
				m_background = [MBackground spriteWithFile:@"ip_map6.png"];
				break;
			case 7:
				m_background = [MBackground spriteWithFile:@"ip_map7.png"];
				break;
		}
		[m_background setGameMain:self];
		
		m_background.position = ccp(480,320/2);
		[self addChild:m_background z:0];
		
		quick1 = [[QuickButton1 spriteSheetWithFile:@"sk-all.png" capacity:40]init];
		[quick1 setGameMain:self];
		quick1.position = ccp(51, 278);
		[self addChild:quick1 z:kTagUI];

		[quick1 setItem:1];

		quick2 = [[QuickButton2 spriteSheetWithFile:@"sk-all.png" capacity:40]init];
		[quick2 setGameMain:self];
		quick2.position = ccp(51, 241);
		[self addChild:quick2 z:kTagUI];
		[quick2 setItem:2];

		quick3 = [[QuickButton3 spriteSheetWithFile:@"sk-all.png" capacity:40]init];
		[quick3 setGameMain:self];
		quick3.position = ccp(51, 204);
		[self addChild:quick3 z:kTagUI];
		[quick3 setItem:3];

		AttackButton *attackButton = [[AttackButton spriteSheetWithFile:@"go-all.png" capacity:2]init];
		[attackButton setBackground:m_background];
		attackButton.position = ccp(457,252);
		[self addChild:attackButton z:kTagUI];

		DefenceButton *defenceButton = [[DefenceButton spriteSheetWithFile:@"back-all.png" capacity:2]init];
		[defenceButton setBackground:m_background];
		defenceButton.position = ccp(457,206);
		[self addChild:defenceButton z:kTagUI];

		StopButton *stopButton = [[StopButton spriteSheetWithFile:@"stop-all.png" capacity:2]init];
		stopButton.position = ccp(464,304);
		[self addChild:stopButton z:kTagUI];
		
//		CGSize winSize = [[CCDirector sharedDirector] winSize];
//		CCSprite *player = [CCSprite spriteWithFile:@"player.png" rect:CGRectMake(0, 0, 50, 55)];
//		player.position = ccp(player.contentSize.width/2, winSize.height/2);
//		[self addChild:player z:kTagChar];

		leftSlot = [MLeftSlot spriteWithFile:@"right_slot.png" rect:CGRectMake(0, 0, 40, 40)];
		[leftSlot setBackground:m_background];
		[leftSlot initItem];
		leftSlot.position = ccp(leftSlot.contentSize.width/2+210,leftSlot.contentSize.height/2);
		[self addChild:leftSlot z:kTagUI];

		rightSlot = [MRightSlot spriteWithFile:@"left_slot.png" rect:CGRectMake(0, 0, 40, 40)];
		[rightSlot setBackground:m_background];
		[rightSlot initItem];
		rightSlot.position = ccp(480-rightSlot.contentSize.width/2,rightSlot.contentSize.height/2);
		[self addChild:rightSlot z:kTagUI];

		///
		[leftSlot setRightSlot:rightSlot];
		[rightSlot setLeftSlot:leftSlot];
		[m_background setRightSlot:rightSlot];
		[m_background setLeftSlot:leftSlot];
		///
		
		// 머니라벨
		moneyImg = [CCSprite spriteWithFile:@"gold-coin.png" rect:CGRectMake(0, 0, 19, 19)];
		moneyImg.position = ccp(11,310);
		[self addChild:moneyImg z:1];

		CCLabel* label = [[CCLabel alloc] initWithString:@"0" fontName:@"Arial" fontSize:13];
		self.moneyLabel = label;
		self.moneyLabel.anchorPoint = CGPointZero;
		self.moneyLabel.position = ccp(20,300);
		[self addChild:self.moneyLabel z:1];
		[label release];
		
		// 스테이지
		stageImg = [CCSprite spriteWithFile:@"stage-1.png" rect:CGRectMake(0, 0, 53, 14)];
		stageImg.position = ccp(236,310);
		[self addChild:stageImg z:1];
				
		[self setGameStageNumber:m_iStageNum];
		
		[self schedule:@selector(gameLogic:) interval:0.1];
		
		
//		MUserData* ud = [MUserData sharedUserData];

		NSMutableData *data1 = [[NSMutableData alloc] init];
		NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:data1];
		[archiver encodeInt:0 forKey:@"m_iBow1Level"];
		[archiver encodeInt:0 forKey:@"m_iBow2Level"];
		[archiver encodeInt:0 forKey:@"m_iBow3Level"];
		[archiver encodeInt:0 forKey:@"m_iBow4Level"];
		[archiver encodeInt:0 forKey:@"m_iBow5Level"];
		
		[archiver encodeInt:0 forKey:@"m_iShield1Level"];
		[archiver encodeInt:0 forKey:@"m_iShield2Level"];
		[archiver encodeInt:0 forKey:@"m_iShield3Level"];
		[archiver encodeInt:0 forKey:@"m_iShield4Level"];
		[archiver encodeInt:0 forKey:@"m_iShield5Level"];
		
		[archiver encodeInt:0 forKey:@"m_iSword1Level"];
		[archiver encodeInt:0 forKey:@"m_iSword2Level"];
		[archiver encodeInt:0 forKey:@"m_iSword3Level"];
		[archiver encodeInt:0 forKey:@"m_iSword4Level"];
		[archiver encodeInt:0 forKey:@"m_iSword5Level"];
		
		[archiver encodeInt:0 forKey:@"m_iCastleLevel"];
		[archiver encodeInt:0 forKey:@"m_iIronNum"];
		[archiver encodeInt:0 forKey:@"m_iWoodNum"];
		
		[archiver encodeBool:FALSE forKey:@"m_bWood1"];
		[archiver encodeBool:FALSE forKey:@"m_bIron1"];
		[archiver encodeBool:FALSE forKey:@"m_bIron2"];
		[archiver encodeBool:FALSE forKey:@"m_bIron3"];
		
		[archiver encodeBool:FALSE forKey:@"m_bWood1Sold"];
		[archiver encodeBool:FALSE forKey:@"m_bIron1Sold"];
		[archiver encodeBool:FALSE forKey:@"m_bIron2Sold"];
		[archiver encodeBool:FALSE forKey:@"m_bIron3Sold"];
		
		[archiver encodeInt:0 forKey:@"m_iSkill1Level"];
		[archiver encodeInt:0 forKey:@"m_iSkill2Level"];
		[archiver encodeInt:0 forKey:@"m_iSkill3Level"];
		[archiver encodeInt:0 forKey:@"m_iSkill4Level"];
		[archiver encodeInt:0 forKey:@"m_iSkill5Level"];
		[archiver encodeInt:0 forKey:@"m_iSkill6Level"];
		
		[archiver encodeInt:0 forKey:@"m_iQuickSlot1"];
		[archiver encodeInt:0 forKey:@"m_iQuickSlot2"];
		[archiver encodeInt:0 forKey:@"m_iQuickSlot3"];
		
		[archiver encodeInt:0 forKey:@"m_iQuickSlot1Num"];
		[archiver encodeInt:0 forKey:@"m_iQuickSlot2Num"];
		[archiver encodeInt:0 forKey:@"m_iQuickSlot3Num"];
				
		[archiver finishEncoding];
		[data1 writeToFile:[self dataFilePath1] atomically:YES];
		[archiver release];
		[data1 release];
		
		
		m_skillAnimation1 = 0;
		m_skillAnimation2 = 0;
		m_skillAnimation3 = 0;
		
//		m_iStageNum = 0;		
	}
	
	return self;
}

-(void) setGameStageNumber:(int)num
{
	CCLabel* label1;
	if(num == 1)
	{
		label1 = [[CCLabel alloc] initWithString:@"01" fontName:@"Arial" fontSize:13];
	}
	else if(num == 2)
	{
		label1 = [[CCLabel alloc] initWithString:@"02" fontName:@"Arial" fontSize:13];
	}
	else if(num == 3)
	{
		label1 = [[CCLabel alloc] initWithString:@"03" fontName:@"Arial" fontSize:13];
	}
	else if(num == 4)
	{
		label1 = [[CCLabel alloc] initWithString:@"04" fontName:@"Arial" fontSize:13];
	}	
	else if(num == 5)
	{
		label1 = [[CCLabel alloc] initWithString:@"05" fontName:@"Arial" fontSize:13];
	}
	else if(num == 6)
	{
		label1 = [[CCLabel alloc] initWithString:@"06" fontName:@"Arial" fontSize:13];
	}
	else if(num == 7)
	{
		label1 = [[CCLabel alloc] initWithString:@"07" fontName:@"Arial" fontSize:13];
	}
	
	self.stageLabel = label1;
	self.stageLabel.anchorPoint = CGPointZero;
	self.stageLabel.position = ccp(265,300);
	[self addChild:self.stageLabel z:1];
	[label1 release];	

//	[moneyLabel release];
//	[self unschedule:@selector(gameLogic:)];
//	[[CCTextureCache sharedTextureCache] removeUnusedTextures];	
}


-(void) dealloc
{
	[super dealloc];
}

-(void) setSkillAnim:(int)type
{
	switch (type) 
	{
		case 1:
			m_skillAnimation1 = 1;
			break;
		case 2:
			m_skillAnimation2 = 1;
			break;
		case 3:
			m_skillAnimation3 = 1;
			break;
		default:
			break;
	}
}

-(void) WinGame
{
	MStageData* ud = [MStageData sharedStageData];

	switch (m_iStageNum) 
	{
		case 1:
			ud.m_iStage1Clear = TRUE;
			break;
		case 2:
			ud.m_iStage2Clear = TRUE;
			break;
		case 3:
			ud.m_iStage3Clear = TRUE;
			break;
		case 4:
			ud.m_iStage4Clear = TRUE;
			break;
		case 5:
			ud.m_iStage5Clear = TRUE;
			break;
		case 6:
			ud.m_iStage6Clear = TRUE;
			break;
		case 7:
			ud.m_iStage7Clear = TRUE;
			break;
	}
	
	NSMutableData *data2 = [[NSMutableData alloc] init];
	NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:data2];
	[archiver encodeBool:ud.m_iStage1Clear forKey:@"m_iStage1Clear"];
	[archiver encodeBool:ud.m_iStage2Clear forKey:@"m_iStage2Clear"];
	[archiver encodeBool:ud.m_iStage3Clear forKey:@"m_iStage3Clear"];
	[archiver encodeBool:ud.m_iStage4Clear forKey:@"m_iStage4Clear"];	
	[archiver encodeBool:ud.m_iStage5Clear forKey:@"m_iStage5Clear"];
	[archiver encodeBool:ud.m_iStage6Clear forKey:@"m_iStage6Clear"];
	[archiver encodeBool:ud.m_iStage7Clear forKey:@"m_iStage7Clear"];

	[archiver encodeBool:ud.m_iStageNum forKey:@"m_iStageNum"];

	[archiver finishEncoding];
	[data2 writeToFile:[self dataFilePath2] atomically:YES];
	[archiver release];
	[data2 release];
	
	[[SimpleAudioEngine sharedEngine] playEffect:@"dog.aiff"];
	CCScene *s1 = [CCScene node];
	
	int walkKill = [m_background getiWalkKill];
	int bowKill = [m_background getiBowKill];
	int horseKill = [m_background getiHorseKill];
	int tankKill = [m_background getiTankKill];
	int castleHP = [m_background getiCastleHP];
	int pointNum = walkKill*20+bowKill*10+horseKill*30+tankKill*40+castleHP*10;
	int goldNum = [m_background getMoney];
	int totalNum = pointNum+goldNum;
	
	MResult* result = [MResult node];
	[result setWalkKillNum:walkKill];
	[result setBowKillNum:bowKill];
	[result setHorseKillNum:horseKill];
	[result setTankKillNum:tankKill];
	[result setCastleHpNum:castleHP];
	
	[result setPointNum:pointNum];
	[result setGoldNum:goldNum];
	[result setTotalNum:totalNum];
	
	[s1 addChild:result];
	[[CCDirector sharedDirector] replaceScene:[CCFlipXTransition transitionWithDuration:1 scene:s1]];
}

-(int) getStageNum
{
	return m_iStageNum;
}
@end
