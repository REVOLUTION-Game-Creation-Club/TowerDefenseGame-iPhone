//
//  MTower.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 11..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MCastle.h"
#import "MStateMachine.h"
#import "MCastleAttack.h"
#import "MCastleWait.h"
#import "MEWalkman.h"

@implementation MCastle

-(id) init
{
	if( (self=[super init] )) 
	{
		m_iHealthPoint = 500; // 체력
		m_iHPMax = 500;
		m_iDepencePoint = 0; // 방어력
		m_iAttackPoint = 0; // 공격력
		m_fAttackSpeed = 0;	// 공격속도
		m_iPrice = 0; // 생산가격
		m_fSight = 300;
		
		m_stateMachine = [[MStateMachine alloc] init];
		[m_stateMachine setOwner:self];
		m_attackState = [[MCastleAttack alloc] init];
		m_waitState = [[MCastleWait alloc] init];
		
		m_spriteTower = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(0,0,30,248)];
		m_spriteTower.position = CGPointMake(-15, 0);
		[self addChild:m_spriteTower z:0 tag:0];
		
		for(int i = 0; i <21; i++)
		{
			m_hpSprite[i] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(0,248+2*i,20,2)];
			[m_hpSprite[i] setPosition:CGPointMake(0, 75)];
			[self addChild:m_hpSprite[i] z:1 tag:0];
			m_hpSprite[i].visible = FALSE;
		}
		
		m_hpSprite[0].visible = TRUE;
				
		m_ptTarget = CGPointMake(100, 100);
		//[m_attackState Enter:self];
		[m_stateMachine setCurrentState:m_waitState];
	}
	return self;
}

-(void) dealloc
{
	[m_attackState release];
	[m_waitState release];
	[m_stateMachine release];
	[super dealloc];
}
						  
-(void) suffer:(int)hp;
{
	m_iHealthPoint--;
	int h = m_iHealthPoint*20.0/(float)m_iHPMax;
	
	for(int i = 1; i < 21; i++)
	{
		if( i == h)
		{
			m_hpSprite[20-i].visible = TRUE;
		}
		else 
		{
			m_hpSprite[20-i].visible = FALSE;
		}
	}
}

-(void) setTarget:(CGPoint)pt
{
	m_ptTarget = pt;
}

-(CGPoint) getTarget
{
	return m_ptTarget;
}

-(void) update
{
	[m_stateMachine update];
}

-(void) attack
{
	[m_stateMachine changeState:m_attackState];
}

-(void) wait
{
	[m_stateMachine changeState:m_waitState];
}

-(BOOL) isInSight:(CGPoint)pt
{
	float dx = pt.x - self.position.x;
	float dy = pt.y - self.position.y;
	
	if(sqrt(dx*dx+dy*dy) < m_fSight)
		return TRUE;
	
	return FALSE;
}

-(void) setPositionTower:(CGPoint)pt
{
	[m_spriteTower setPosition:pt];
}

-(void) setTargetUnit:(MEWalkman*)unit
{
	m_targetUnit = unit;
}

-(MEWalkman*) getTargetUnit
{
	return m_targetUnit;
}

-(void) setBackground:(MBackground*)bg
{
	m_background = bg;
}

-(MBackground*)getBackground
{
	return m_background;
}

@end
