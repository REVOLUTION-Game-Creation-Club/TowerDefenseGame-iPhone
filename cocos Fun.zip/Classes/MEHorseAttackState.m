//
//  MEHorseAttackState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 27..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MEHorseAttackState.h"
#import "MEHorseman.h"

@implementation MEHorseAttackState

- (void)Enter:(id)owner
{
	MEHorseman *horseman = owner;
	m_iCount = 0;
	
	[horseman unvisibleAll];
}

- (void)Execute:(id)owner
{
	MEHorseman *horseman = owner;
	if(m_iCount==0)
	{
		[horseman AttackAnimation];
	}
	m_iCount++;
	
	if(m_iCount == 60)
	{
		m_iCount = 0;
		MUnit *enemy = [horseman getTargetUnit];
		if(enemy)
		{
			[enemy suffer:1];
		}		
	}
	[horseman setFlipX:TRUE];
}

- (void)Exit:(id)owner
{
	
}

- (NSString*)name
{
	return @"MHorseAttackState";
}

@end
