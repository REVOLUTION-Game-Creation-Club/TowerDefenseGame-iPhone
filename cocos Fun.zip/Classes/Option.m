//
//  Option.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 16..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Option.h"
#import "Menu.h"
#import "MUserData.h"

@implementation Option

-(id)init
{
	if( (self=[super init] )) 
	{
		m_sprite = [CCSprite spriteWithFile:@"option.png" rect:CGRectMake(0,0,480,320)];
		m_sprite.position = ccp(480/2,320/2);
		[self addChild:m_sprite z:0];
		
		m_easy = [CCSprite spriteWithFile:@"easy.png" rect:CGRectMake(0,0,76,18)];
		m_easy.position = ccp(301,163);
		[self addChild:m_easy z:0];
		
		m_easyOn = [CCSprite spriteWithFile:@"easyOn.png" rect:CGRectMake(0,0,76,18)];
		m_easyOn.position = ccp(301,163);
		[self addChild:m_easyOn z:0];
		m_easyOn.visible = FALSE;

		m_normal = [CCSprite spriteWithFile:@"normal.png" rect:CGRectMake(0,0,76,18)];
		m_normal.position = ccp(301,128);
		[self addChild:m_normal z:0];

		m_normalOn = [CCSprite spriteWithFile:@"normalOn.png" rect:CGRectMake(0,0,76,18)];
		m_normalOn.position = ccp(301,128);
		[self addChild:m_normalOn z:0];

		m_hard = [CCSprite spriteWithFile:@"hard.png" rect:CGRectMake(0,0,76,18)];
		m_hard.position = ccp(301,93);
		[self addChild:m_hard z:0];
		
		m_hardOn = [CCSprite spriteWithFile:@"hardOn.png" rect:CGRectMake(0,0,76,18)];
		m_hardOn.position = ccp(301,93);
		[self addChild:m_hardOn z:0];
		m_hardOn.visible = FALSE;
		//
		m_ok = [CCSprite spriteWithFile:@"ok.png" rect:CGRectMake(0,0,57,37)];
		m_ok.position = ccp(185,22);
		[self addChild:m_ok z:0];

		m_okOn = [CCSprite spriteWithFile:@"okOn.png" rect:CGRectMake(0,0,57,37)];
		m_okOn.position = ccp(185,22);
		[self addChild:m_okOn z:0];

		m_cancel = [CCSprite spriteWithFile:@"cancel.png" rect:CGRectMake(0,0,57,37)];
		m_cancel.position = ccp(295,22);
		[self addChild:m_cancel z:0];

		m_cancelOn = [CCSprite spriteWithFile:@"cancelOn.png" rect:CGRectMake(0,0,57,37)];
		m_cancelOn.position = ccp(295,22);
		[self addChild:m_cancelOn z:0];

		//
		m_soundOn = [CCSprite spriteWithFile:@"soundOn.png" rect:CGRectMake(0,0,30,18)];
		m_soundOn.position = ccp(179,145);
		[self addChild:m_soundOn z:0];

		m_soundOnOn = [CCSprite spriteWithFile:@"soundOnOn.png" rect:CGRectMake(0,0,30,18)];
		m_soundOnOn.position = ccp(179,145);
		[self addChild:m_soundOnOn z:0];
		
		m_soundOff = [CCSprite spriteWithFile:@"soundOff.png" rect:CGRectMake(0,0,30,18)];
		m_soundOff.position = ccp(179,106);
		[self addChild:m_soundOff z:0];

		m_soundOffOn = [CCSprite spriteWithFile:@"soundOffOn.png" rect:CGRectMake(0,0,30,18)];
		m_soundOffOn.position = ccp(179,106);
		[self addChild:m_soundOffOn z:0];
		m_soundOffOn.visible = FALSE;
		
		m_bSoundOn = TRUE;
		m_iGameLevel = 2;
	}
	
	return self;
}

- (void)onEnter
{
	[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
	[super onEnter];

/*	
	MUserData* ud = [MUserData sharedUserData];
	NSData *data1 = [[NSMutableData alloc] initWithContentsOfFile:[self dataFilePath]];
	NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:data1];

	ud.m_bSoundOn = [unarchiver decodeIntForKey:@"m_bSoundOn"];
	ud.m_iGameLevel = [unarchiver decodeIntForKey:@"m_iGameLevel"];
	
	[unarchiver finishDecoding];
	
	[unarchiver release];
	[data1 release];
*/
	// on, off
	if(m_bSoundOn == TRUE)
	{
		[self SoundOn:TRUE];
	}
	else
	{
		[self SoundOn:FALSE];
	}
	
	/// easy, normal, hard
	if(m_iGameLevel == 1)
	{
		[self SetGameLevel:1];
	}
	else if(m_iGameLevel == 2)
	{
		[self SetGameLevel:2];
	}
	else if(m_iGameLevel == 3)
	{
		[self SetGameLevel:3];
	}
	
}

- (void)onExit
{
	
	[[CCTouchDispatcher sharedDispatcher] removeDelegate:self];
	[super onExit];
}

- (void)SoundOn:(BOOL)on
{
	if(on== TRUE)
	{
		m_bSoundOn = TRUE;
		m_soundOnOn.visible = TRUE;
		m_soundOffOn.visible = FALSE;		
	}
	else 
	{
		m_bSoundOn = FALSE;
		m_soundOnOn.visible = FALSE;
		m_soundOffOn.visible = TRUE;		
	}
}

- (void)SetGameLevel:(int)level
{
	if(level == 1)
	{
		m_iGameLevel = 1;
		m_easyOn.visible = TRUE;
		m_normalOn.visible = FALSE;
		m_hardOn.visible = FALSE;
	}
	else if(level == 2)
	{
		m_iGameLevel = 2;
		m_easyOn.visible = FALSE;
		m_normalOn.visible = TRUE;
		m_hardOn.visible = FALSE;
	}
	else if(level == 3)
	{
		m_iGameLevel = 3;
		m_easyOn.visible = FALSE;
		m_normalOn.visible = FALSE;
		m_hardOn.visible = TRUE;		
	}
}

- (NSString*)dataFilePath
{
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	return [documentsDirectory stringByAppendingPathComponent:@"archive"];
}

- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{	
	
	CGPoint touch_pt = [self convertTouchToNodeSpaceAR:touch];
	
	// on, off
	if(CGRectContainsPoint(CGRectMake(179-240-30/2,145-160-18/2,30,18), touch_pt))
	{
		[self SoundOn:TRUE];
	}
	else if(CGRectContainsPoint(CGRectMake(179-240-30/2,106-160-18/2,30,18), touch_pt))
	{
		[self SoundOn:FALSE];
	}

	/// easy, normal, hard
	else if(CGRectContainsPoint(CGRectMake(301-240-76/2,163-160-18/2,76,18), touch_pt))
	{
		[self SetGameLevel:1];
	}
	else if(CGRectContainsPoint(CGRectMake(301-240-76/2,128-160-18/2,76,18), touch_pt))
	{
		[self SetGameLevel:2];
	}
	else if(CGRectContainsPoint(CGRectMake(301-240-76/2,93-160-18/2,76,18), touch_pt))
	{
		[self SetGameLevel:3];
	}
	
	//	ok, cancel
	else if(CGRectContainsPoint(CGRectMake(185-240-57/2,22-160-37/2,57,37), touch_pt))
	{
		MUserData* ud = [MUserData sharedUserData];
		
		NSMutableData *data = [[NSMutableData alloc] init];
		NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:data];
		[archiver encodeBool:ud.m_bSoundOn forKey:@"m_bSoundOn"];
		[archiver encodeInt:ud.m_iGameLevel forKey:@"m_iGameLevel"];
		
		[archiver finishEncoding];
		[data writeToFile:[self dataFilePath] atomically:YES];
		[archiver release];
		[data release];
		
		
		 CCScene *s = [CCScene node];
		 
		 [s addChild:[Menu node]];
		 [[CCDirector sharedDirector] replaceScene:[CCFlipXTransition transitionWithDuration:1 scene:s]];		
	}
	else if(CGRectContainsPoint(CGRectMake(295-240-57/2,22-160-37/2,57,37), touch_pt))
	{
		CCScene *s = [CCScene node];
		
		[s addChild:[Menu node]];
		[[CCDirector sharedDirector] replaceScene:[CCFlipXTransition transitionWithDuration:1 scene:s]];		
	}
	
	/*
	CCScene *s = [CCScene node];
	
	[s addChild:[Menu node]];
	[[CCDirector sharedDirector] replaceScene:[CCFlipXTransition transitionWithDuration:1 scene:s]];
	*/
	
	return YES;
}

@end
