//
//  UnitButton.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 11..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@class MBackground;

@interface MUnitButton : CCSpriteSheet <CCTargetedTouchDelegate> 
{
	CCSprite* m_sprite[13];
	BOOL bProudceOK;
	
	MBackground* m_background;
}

-(id) init;
-(void) produce:(int)percent;
-(void)unvisibleAll;
-(void) produceComplete;

-(void) setBackground:(MBackground*)bg;

@end
