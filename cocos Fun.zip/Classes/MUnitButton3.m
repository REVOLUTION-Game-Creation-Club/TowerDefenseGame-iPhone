//
//  MUnitButton3.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 21..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MUnitButton3.h"
#import "MBackground.h"

@implementation MUnitButton3

-(id) init
{
	if( (self=[super init] )) 
	{
		bProudceOK = TRUE;

		m_sprite[0] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(0,0,28,23)];
		[self addChild:m_sprite[0] z:0 tag:0];
		m_sprite[1] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(28,0,28,23)];
		[self addChild:m_sprite[1] z:0 tag:0];
		m_sprite[2] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(56,0,28,23)];
		[self addChild:m_sprite[2] z:0 tag:0];
		m_sprite[3] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(84,0,28,23)];
		[self addChild:m_sprite[3] z:0 tag:0];
		m_sprite[4] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(112,0,28,23)];
		[self addChild:m_sprite[4] z:0 tag:0];
		
		m_sprite[5] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(0,23,28,23)];
		[self addChild:m_sprite[5] z:0 tag:0];
		m_sprite[6] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(28,23,28,23)];
		[self addChild:m_sprite[6] z:0 tag:0];
		m_sprite[7] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(56,23,28,23)];
		[self addChild:m_sprite[7] z:0 tag:0];
		m_sprite[8] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(84,23,28,23)];
		[self addChild:m_sprite[8] z:0 tag:0];
		m_sprite[9] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(112,23,28,23)];
		[self addChild:m_sprite[9] z:0 tag:0];
		
		m_sprite[10] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(0,46,28,23)];
		[self addChild:m_sprite[10] z:0 tag:0];
		m_sprite[11] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(28,46,28,23)];
		[self addChild:m_sprite[11] z:0 tag:0];
		m_sprite[12] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(56,46,28,23)];
		[self addChild:m_sprite[12] z:0 tag:0];
		
		[self unvisibleAll];
		m_sprite[0].visible = TRUE;
	}
	return self;
}

- (CGRect)rect
{
//	CGSize s = [self.texture contentSize];	
	return CGRectMake(-14, -11, 28, 23);
}

- (void)onEnter
{
	[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
	[super onEnter];
}

- (void)onExit
{
	[[CCTouchDispatcher sharedDispatcher] removeDelegate:self];
	[super onExit];
}

- (BOOL)containsTouchLocation:(UITouch *)touch
{
	//NSLog(@"touch(%f,%f",pt.x, pt.y);
	
	return CGRectContainsPoint(self.rect, [self convertTouchToNodeSpaceAR:touch]);
}


- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{
	if ( ![self containsTouchLocation:touch] ) return NO;
	
	
	if(bProudceOK)
	{
		if([m_background reduceMoney:200])
		{
			bProudceOK = FALSE;
			[m_background produceMyHorseman];
		}
	}
	
//	[m_background produceEnemyHorseman];
	
	return YES;
}

-(void)unvisibleAll
{
	for(int i = 0; i < 13; i++)
	{
		m_sprite[i].visible = FALSE;
	}
}

-(void) produce:(int)percent
{
	for(int i = 0; i <13; i++)
	{
		if(percent == i)
		{
			[self unvisibleAll];
			m_sprite[i].visible = TRUE;
			return;
		}
	}
}

-(void) produceComplete
{
	bProudceOK = TRUE;
}

-(void) setBackground:(MBackground*)bg
{
	m_background = bg;
}

@end
