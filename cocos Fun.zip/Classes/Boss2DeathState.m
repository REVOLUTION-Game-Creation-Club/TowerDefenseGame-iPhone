//
//  Boss2DeathState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 24..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Boss2DeathState.h"
#import "Boss2.h"

@implementation Boss2DeathState

- (void)Enter:(id)owner
{
	m_iCount = 0;
	Boss2 *boss2 = owner;
	[boss2 unvisibleAll];
}

- (void)Execute:(id)owner
{
	Boss2 *boss2 = owner;
	if(m_iCount == 0)
	{
		[boss2 DeathAnimation];
	}
	m_iCount++;
	
	if(m_iCount == 30)
		m_iCount = 0;
}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"Boss1DeathState";
}

@end
