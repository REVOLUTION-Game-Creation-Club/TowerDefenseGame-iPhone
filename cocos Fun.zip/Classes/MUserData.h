//
//  MUserData.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 30..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MUserData : NSObject
{
	int m_iBow1Level;
	int m_iBow2Level;
	int m_iBow3Level;
	int m_iBow4Level;
	int m_iBow5Level;
	
	int m_iSword1Level;
	int m_iSword2Level;
	int m_iSword3Level;
	int m_iSword4Level;
	int m_iSword5Level;
	
	int m_iShield1Level;
	int m_iShield2Level;
	int m_iShield3Level;
	int m_iShield4Level;
	int m_iShield5Level;
		
	int m_iCastleLevel;
	
	int m_iIronNum;
	int m_iWoodNum;

	BOOL m_bWood1;
	BOOL m_bIron1;
	BOOL m_bIron2;
	BOOL m_bIron3;
	
	BOOL m_bWood1Sold;
	BOOL m_bIron1Sold;
	BOOL m_bIron2Sold;
	BOOL m_bIron3Sold;
	
	int m_iSkill1Level;
	int m_iSkill2Level;
	int m_iSkill3Level;
	int m_iSkill4Level;
	int m_iSkill5Level;
	int m_iSkill6Level;

	int m_iQuickSlot1;
	int m_iQuickSlot2;
	int m_iQuickSlot3;

	int m_iQuickSlot1Num;
	int m_iQuickSlot2Num;
	int m_iQuickSlot3Num;
		
	BOOL m_bSoundOn;
	int m_iGameLevel; // 1. easy, 2. normal, 3. hard
		
	int m_iMoney;
}

@property int m_iBow1Level;
@property int m_iBow2Level;
@property int m_iBow3Level;
@property int m_iBow4Level;
@property int m_iBow5Level;

@property int m_iSword1Level;
@property int m_iSword2Level;
@property int m_iSword3Level;
@property int m_iSword4Level;
@property int m_iSword5Level;

@property int m_iShield1Level;
@property int m_iShield2Level;
@property int m_iShield3Level;
@property int m_iShield4Level;
@property int m_iShield5Level;

@property int m_iCastleLevel;

@property int m_iIronNum;
@property int m_iWoodNum;

@property BOOL m_bWood1;
@property BOOL m_bIron1;
@property BOOL m_bIron2;
@property BOOL m_bIron3;

@property BOOL m_bWood1Sold;
@property BOOL m_bIron1Sold;
@property BOOL m_bIron2Sold;
@property BOOL m_bIron3Sold;

@property int m_iSkill1Level;
@property int m_iSkill2Level;
@property int m_iSkill3Level;
@property int m_iSkill4Level;
@property int m_iSkill5Level;
@property int m_iSkill6Level;

@property int m_iQuickSlot1;
@property int m_iQuickSlot2;
@property int m_iQuickSlot3;

@property int m_iQuickSlot1Num;
@property int m_iQuickSlot2Num;
@property int m_iQuickSlot3Num;

@property BOOL m_bSoundOn;
@property int m_iGameLevel;

@property int m_iMoney;

+ (MUserData*)sharedUserData;

-(id)init;

@end
