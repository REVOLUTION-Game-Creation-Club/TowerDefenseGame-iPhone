//
//  MoveState.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 11..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MState.h"

@interface MWalkMoveState : MState
{
	int m_iCount;
}

- (void)Enter:(id)owner;
- (void)Execute:(id)owner;
- (void)Exit:(id)owner;
- (NSString*)name;

@end
