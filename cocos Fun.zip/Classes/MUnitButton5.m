//
//  MUnitButton5.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 18..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MUnitButton5.h"
#import "MBackground.h"

@implementation MUnitButton5

-(id) init
{
	if( (self=[super init] )) 
	{		
		m_sprite = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(0,0,28,23)];
		[self addChild:m_sprite z:0 tag:0];
	}
	return self;
}

- (void)onEnter
{
	[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
	[super onEnter];
}

- (void)onExit
{
	[[CCTouchDispatcher sharedDispatcher] removeDelegate:self];
	[super onExit];
}

- (CGRect)rect
{
	//	CGSize s = [self.texture contentSize];	
	return CGRectMake(-14, -11, 28, 23);
}

- (BOOL)containsTouchLocation:(UITouch *)touch
{
	//NSLog(@"touch(%f,%f",pt.x, pt.y);
	
	return CGRectContainsPoint(self.rect, [self convertTouchToNodeSpaceAR:touch]);
}


- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{
	if ( ![self containsTouchLocation:touch] ) return NO;
	
	//[m_background produceBoss1];
	[m_background produceBoss2];
//	[m_background produceBoss3];
//	[m_background produceBoss4];
//	[m_background produceBoss5];
//	[m_background produceBoss6];
//	[m_background produceBoss7];
	
	return YES;
}

-(void) setBackground:(MBackground*)bg
{
	m_background = bg;
}

@end
