//
//  MManual.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 15..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Manual1.h"
#import "Manual2.h"

@implementation Manual1

-(id)init
{
	if( (self=[super init] )) 
	{
		m_sprite = [CCSprite spriteWithFile:@"ex1.png" rect:CGRectMake(0,0,480,320)];
		m_sprite.position = ccp(480/2,320/2);
		[self addChild:m_sprite z:0];
	}

	return self;
}

- (void)onEnter
{
	[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
	[super onEnter];
}

- (void)onExit
{
	[[CCTouchDispatcher sharedDispatcher] removeDelegate:self];
	[super onExit];
}

- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{	
	CCScene *s = [CCScene node];
	
	[s addChild:[Manual2 node]];
	[[CCDirector sharedDirector] replaceScene:[CCFlipXTransition transitionWithDuration:1 scene:s]];
	
	return YES;
}

@end
