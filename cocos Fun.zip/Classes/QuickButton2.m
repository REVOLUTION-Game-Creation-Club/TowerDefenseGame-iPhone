//
//  QuickButton2.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 17..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "QuickButton2.h"
#import "MGameMain1.h"


@implementation QuickButton2

- (id)init
{
	if((self=[super init] ))
	{
		m_selectItem = -1;
		
		for(int i = 0; i < 6; i++)
		{
			for(int j = 0; j < 11; j++)
			{
				m_sprite[i][j] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(36*j,36*i,36,36)];
				[self addChild:m_sprite[i][j] z:0 tag:0];
				m_sprite[i][j].visible = FALSE;
			}
		}
	}
	
	return self;
}

- (void)setItem:(int)itemNo
{
	m_selectItem = itemNo;
	
	for(int i = 0; i<6; i++)
	{
		if(i == itemNo)
		{
			m_sprite[i][0].visible = TRUE;
		}
		else
		{
			m_sprite[i][0].visible = FALSE;
		}
	}
}

-(void) produce:(int)percent
{
	for(int i = 0; i < 11; i++)
	{
		if(i == percent)
		{
			m_sprite[m_selectItem][i].visible = TRUE;
		}
		else
		{
			m_sprite[m_selectItem][i].visible = FALSE;			
		}
		
	}
}


- (CGRect)rect
{
	//	CGSize s = [self.texture contentSize];	
	return CGRectMake(-14, -11, 28, 23);
}

- (void)onEnter
{
	[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
	[super onEnter];
}

- (void)onExit
{
	[[CCTouchDispatcher sharedDispatcher] removeDelegate:self];
	[super onExit];
}

- (BOOL)containsTouchLocation:(UITouch *)touch
{
	//NSLog(@"touch(%f,%f",pt.x, pt.y);
	
	return CGRectContainsPoint(self.rect, [self convertTouchToNodeSpaceAR:touch]);
}


- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{
	if ( ![self containsTouchLocation:touch] ) return NO;
	
	[m_gameMain setSkillAnim:2];

	return YES;
}

-(void) trigger
{
	switch(m_selectItem)
	{
		case 0:
			break;
		case 1:
			break;
		case 2:
			break;
		case 3:
			break;
		case 4:
			break;
		case 5:
			break;
	}	
}

-(void) setGameMain:(MGameMain1*)gm
{
	m_gameMain = gm;
}

@end
