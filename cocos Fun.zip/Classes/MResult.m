//
//  MResult.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 26..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MResult.h"
#import "MStore.h"
#import "MGameMain1.h"
#import "NextButton.h"

@implementation MResult

@synthesize walkmanLabel;
@synthesize bowmanLabel;
@synthesize horsemanLabel;
@synthesize tankLabel;
@synthesize castleLabel;

@synthesize walkScoreLabel;
@synthesize bowScoreLabel;
@synthesize horseScoreLabel;
@synthesize tankScoreLabel;
@synthesize castleScoreLabel;

@synthesize pointLabel;
@synthesize goldLabel;
@synthesize totalLabel;

-(id)init
{
	if( (self=[super init] )) 
	{
		m_sprite = [CCSprite spriteWithFile:@"result.png" rect:CGRectMake(0,0,480,320)];
		m_sprite.position = ccp(480/2,320/2);
		[self addChild:m_sprite z:0];
		/*
		CCLabel* label1 = [[CCLabel alloc] initWithString:@"" fontName:@"Arial" fontSize:13];
		self.bowmanLabel = label1;
		self.bowmanLabel.anchorPoint = CGPointZero;
		self.bowmanLabel.position = ccp(115-10,220-10);
		[self addChild:self.bowmanLabel z:1];
		[label1 release];

		CCLabel* label11 = [[CCLabel alloc] initWithString:@"" fontName:@"Arial" fontSize:13];
		self.bowScoreLabel = label11;
		self.bowScoreLabel.anchorPoint = CGPointZero;
		self.bowScoreLabel.position = ccp(195-20,220-10);
		[self addChild:self.bowScoreLabel z:1];
		[label11 release];
		
		CCLabel* label2 = [[CCLabel alloc] initWithString:@"" fontName:@"Arial" fontSize:13];
		self.walkmanLabel = label2;
		self.walkmanLabel.anchorPoint = CGPointZero;
		self.walkmanLabel.position = ccp(115-10,177-10);
		[self addChild:self.walkmanLabel z:1];
		[label2 release];

		CCLabel* label22 = [[CCLabel alloc] initWithString:@"" fontName:@"Arial" fontSize:13];
		self.walkScoreLabel = label22;
		self.walkScoreLabel.anchorPoint = CGPointZero;
		self.walkScoreLabel.position = ccp(195-20,177-10);
		[self addChild:self.walkScoreLabel z:1];
		[label22 release];
		
		CCLabel* label3 = [[CCLabel alloc] initWithString:@"" fontName:@"Arial" fontSize:13];
		self.horsemanLabel = label3;
		self.horsemanLabel.anchorPoint = CGPointZero;
		self.horsemanLabel.position = ccp(115-10,137-10);
		[self addChild:self.horsemanLabel z:1];
		[label3 release];

		CCLabel* label33 = [[CCLabel alloc] initWithString:@"" fontName:@"Arial" fontSize:13];
		self.horseScoreLabel = label33;
		self.horseScoreLabel.anchorPoint = CGPointZero;
		self.horseScoreLabel.position = ccp(195-20,137-10);
		[self addChild:self.horseScoreLabel z:1];
		[label33 release];
		
		CCLabel* label4 = [[CCLabel alloc] initWithString:@"" fontName:@"Arial" fontSize:13];
		self.tankLabel = label4;
		self.tankLabel.anchorPoint = CGPointZero;
		self.tankLabel.position = ccp(325-10,208-10);
		[self addChild:self.tankLabel z:1];
		[label4 release];

		CCLabel* label44 = [[CCLabel alloc] initWithString:@"" fontName:@"Arial" fontSize:13];
		self.tankScoreLabel = label44;
		self.tankScoreLabel.anchorPoint = CGPointZero;
		self.tankScoreLabel.position = ccp(409-20,208-10);
		[self addChild:self.tankScoreLabel z:1];
		[label44 release];
		
		CCLabel* label5 = [[CCLabel alloc] initWithString:@"" fontName:@"Arial" fontSize:13];
		self.castleLabel = label5;
		self.castleLabel.anchorPoint = CGPointZero;
		self.castleLabel.position = ccp(318-20,147-10);
		[self addChild:self.castleLabel z:1];
		[label5 release];

		CCLabel* label55 = [[CCLabel alloc] initWithString:@"" fontName:@"Arial" fontSize:13];
		self.castleScoreLabel = label55;
		self.castleScoreLabel.anchorPoint = CGPointZero;
		self.castleScoreLabel.position = ccp(409-20,147-10);
		[self addChild:self.castleScoreLabel z:1];
		[label55 release];
		
		CCLabel* label100 = [[CCLabel alloc] initWithString:@"" fontName:@"Arial" fontSize:13];
		self.pointLabel = label100;
		self.pointLabel.anchorPoint = CGPointZero;
		self.pointLabel.position = ccp(272-40,75-10);
		[self addChild:self.pointLabel z:1];
		[label100 release];

		CCLabel* label101 = [[CCLabel alloc] initWithString:@"" fontName:@"Arial" fontSize:13];
		self.goldLabel = label101;
		self.goldLabel.anchorPoint = CGPointZero;
		self.goldLabel.position = ccp(272-40,55-10);
		[self addChild:self.goldLabel z:1];
		[label101 release];

		CCLabel* label102 = [[CCLabel alloc] initWithString:@"" fontName:@"Arial" fontSize:13];
		self.totalLabel = label102;
		self.totalLabel.anchorPoint = CGPointZero;
		self.totalLabel.position = ccp(272-40,35-10);
		[self addChild:self.totalLabel z:1];
		[label102 release];
		*/
		nextButton = [[NextButton spriteSheetWithFile:@"nextButton.png" capacity:2]init];
		nextButton.position = ccp(429,41);
		[self addChild:nextButton z:kTagUI];
		
	}
	
	return self;
}

-(void) setWalkKillNum:(int)num
{
	NSString *str = [NSString stringWithFormat:@"%d",num];

	CCLabel* label1;
	label1 = [[CCLabel alloc] initWithString:str fontName:@"Arial" fontSize:13];
	self.walkmanLabel = label1;
	self.walkmanLabel.anchorPoint = CGPointZero;
	self.walkmanLabel.position = ccp(115-10,177-10);
	[self addChild:self.walkmanLabel z:1];
	[label1 release];		
	//[str release];
	
	NSString *str2 = [NSString stringWithFormat:@"%d",num*20];

	CCLabel* label22 = [[CCLabel alloc] initWithString:str2 fontName:@"Arial" fontSize:13];
	self.walkScoreLabel = label22;
	self.walkScoreLabel.anchorPoint = CGPointZero;
	self.walkScoreLabel.position = ccp(195-20,177-10);
	[self addChild:self.walkScoreLabel z:1];
	[label22 release];
	
}

-(void) setBowKillNum:(int)num
{
	NSString *str = [NSString stringWithFormat:@"%d",num];
	
	CCLabel* label1;
	label1 = [[CCLabel alloc] initWithString:str fontName:@"Arial" fontSize:13];
	self.bowmanLabel = label1;
	self.bowmanLabel.anchorPoint = CGPointZero;
	self.bowmanLabel.position = ccp(115-10,220-10);
	[self addChild:self.bowmanLabel z:1];
	[label1 release];		
	//[str release];	

	NSString *str2 = [NSString stringWithFormat:@"%d",num*10];

	CCLabel* label11 = [[CCLabel alloc] initWithString:str2 fontName:@"Arial" fontSize:13];
	self.bowScoreLabel = label11;
	self.bowScoreLabel.anchorPoint = CGPointZero;
	self.bowScoreLabel.position = ccp(195-20,220-10);
	[self addChild:self.bowScoreLabel z:1];
	[label11 release];	
}

-(void) setHorseKillNum:(int)num
{
	NSString *str = [NSString stringWithFormat:@"%d",num];
	
	CCLabel* label1;
	label1 = [[CCLabel alloc] initWithString:str fontName:@"Arial" fontSize:13];
	self.horsemanLabel = label1;
	self.horsemanLabel.anchorPoint = CGPointZero;
	self.horsemanLabel.position = ccp(115-10,137-10);
	[self addChild:self.horsemanLabel z:1];
	[label1 release];

	NSString *str2 = [NSString stringWithFormat:@"%d",num*30];

	CCLabel* label33 = [[CCLabel alloc] initWithString:str2 fontName:@"Arial" fontSize:13];
	self.horseScoreLabel = label33;
	self.horseScoreLabel.anchorPoint = CGPointZero;
	self.horseScoreLabel.position = ccp(195-20,137-10);
	[self addChild:self.horseScoreLabel z:1];
	[label33 release];
}

-(void) setTankKillNum:(int)num
{
	NSString *str = [NSString stringWithFormat:@"%d",num];
	
	CCLabel* label1;
	label1 = [[CCLabel alloc] initWithString:str fontName:@"Arial" fontSize:13];
	self.tankLabel = label1;
	self.tankLabel.anchorPoint = CGPointZero;
	self.tankLabel.position = ccp(325-10,208-10);
	[self addChild:self.tankLabel z:1];
	[label1 release];	

	NSString *str2 = [NSString stringWithFormat:@"%d",num*40];

	CCLabel* label44 = [[CCLabel alloc] initWithString:str2 fontName:@"Arial" fontSize:13];
	self.tankScoreLabel = label44;
	self.tankScoreLabel.anchorPoint = CGPointZero;
	self.tankScoreLabel.position = ccp(409-20,208-10);
	[self addChild:self.tankScoreLabel z:1];
	[label44 release];
}

-(void) setCastleHpNum:(int)num
{
	NSString *str = [NSString stringWithFormat:@"%d",num];

	CCLabel* label5 = [[CCLabel alloc] initWithString:str fontName:@"Arial" fontSize:13];
	self.castleLabel = label5;
	self.castleLabel.anchorPoint = CGPointZero;
	self.castleLabel.position = ccp(318-20,147-10);
	[self addChild:self.castleLabel z:1];
	[label5 release];

	NSString *str2 = [NSString stringWithFormat:@"%d",num*10];

	CCLabel* label55 = [[CCLabel alloc] initWithString:str2 fontName:@"Arial" fontSize:13];
	self.castleScoreLabel = label55;
	self.castleScoreLabel.anchorPoint = CGPointZero;
	self.castleScoreLabel.position = ccp(409-20,147-10);
	[self addChild:self.castleScoreLabel z:1];
	[label55 release];
	
}

-(void) setPointNum:(int)num
{
	NSString *str = [NSString stringWithFormat:@"%d",num];

	CCLabel* label100 = [[CCLabel alloc] initWithString:str fontName:@"Arial" fontSize:13];
	self.pointLabel = label100;
	self.pointLabel.anchorPoint = CGPointZero;
	self.pointLabel.position = ccp(272-40,75-10);
	[self addChild:self.pointLabel z:1];
	[label100 release];	
}

-(void) setGoldNum:(int)num
{
	NSString *str = [NSString stringWithFormat:@"%d",num];

	CCLabel* label101 = [[CCLabel alloc] initWithString:str fontName:@"Arial" fontSize:13];
	self.goldLabel = label101;
	self.goldLabel.anchorPoint = CGPointZero;
	self.goldLabel.position = ccp(272-40,55-10);
	[self addChild:self.goldLabel z:1];
	[label101 release];	
}

-(void) setTotalNum:(int)num
{
	NSString *str = [NSString stringWithFormat:@"%d",num];
	
	CCLabel* label102 = [[CCLabel alloc] initWithString:str fontName:@"Arial" fontSize:13];
	self.totalLabel = label102;
	self.totalLabel.anchorPoint = CGPointZero;
	self.totalLabel.position = ccp(272-40,35-10);
	[self addChild:self.totalLabel z:1];
	[label102 release];	
}

@end
