//
//  Manual5.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 15..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Manual5.h"
#import "Manual6.h"

@implementation Manual5

-(id)init
{
	if( (self=[super init] )) 
	{
		CCSprite* menuBG = [CCSprite spriteWithFile:@"ex5.png" rect:CGRectMake(0,0,480,320)];
		menuBG.position = ccp(480/2,320/2);
		[self addChild:menuBG z:0];		
	}
	
	return self;
}

- (void)onEnter
{
	[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
	[super onEnter];
}

- (void)onExit
{
	[[CCTouchDispatcher sharedDispatcher] removeDelegate:self];
	[super onExit];
}

- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{	
	CCScene *s = [CCScene node];
	
	[s addChild:[Manual6 node]];
	[[CCDirector sharedDirector] replaceScene:[CCFlipXTransition transitionWithDuration:1 scene:s]];
	
	return YES;
}


@end
