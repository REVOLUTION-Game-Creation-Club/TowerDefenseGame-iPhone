//
//  Boss3DeathState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 24..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Boss3DeathState.h"
#import "Boss3.h"

@implementation Boss3DeathState

- (void)Enter:(id)owner
{
	m_iCount = 0;
	Boss3 *boss3 = owner;
	[boss3 unvisibleAll];
}

- (void)Execute:(id)owner
{
	Boss3 *boss3 = owner;
	if(m_iCount == 0)
	{
		[boss3 DeathAnimation];
	}
	m_iCount++;
	
	if(m_iCount == 30)
		m_iCount = 0;
	
}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"Boss3DeathState";
}

@end
