//
//  Vector2D.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 11..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Vector2D.h"


@implementation Vector2D

@end
