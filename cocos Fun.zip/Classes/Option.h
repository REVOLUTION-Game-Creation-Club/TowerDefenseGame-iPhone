//
//  Option.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 16..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface Option : CCLayer <CCTargetedTouchDelegate> 
{
	CCSprite* m_sprite; // 배경
	
	CCSprite* m_easy;
	CCSprite* m_easyOn;
	CCSprite* m_normal;
	CCSprite* m_normalOn;
	CCSprite* m_hard;
	CCSprite* m_hardOn;
	
	CCSprite* m_ok;
	CCSprite* m_okOn;
	CCSprite* m_cancel;
	CCSprite* m_cancelOn;
	
	CCSprite* m_soundOn;
	CCSprite* m_soundOnOn;
	CCSprite* m_soundOff;
	CCSprite* m_soundOffOn;
	
	BOOL m_bSoundOn;
	int m_iGameLevel;
}

-(id)init;
- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event;
- (void)SoundOn:(BOOL)on;
- (void)SetGameLevel:(int)level;

- (NSString*)dataFilePath;

@end
