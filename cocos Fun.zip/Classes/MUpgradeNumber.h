//
//  MUpgradeNumber.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 1..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "cocos2d.h"

@interface MUpgradeNumber : CCSpriteSheet
{
	CCSprite* m_sprite[10];
}

-(id)init;
-(void)setNumber:(int)n;

@end
