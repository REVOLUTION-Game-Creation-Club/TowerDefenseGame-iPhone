//
//  MEWalkChaseState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 27..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MEWalkChaseState.h"
#import "MEWalkman.h"

@implementation MEWalkChaseState

- (void)Enter:(id)owner
{
	//rot = 0;
	m_iCount = 0;
	MEWalkman *walkman = owner;
	[walkman unvisibleAll];
}

- (void)Execute:(id)owner
{
	MEWalkman *walkman = owner;
	if(m_iCount == 0)
	{
		[walkman MoveAnimation];
	}
	m_iCount++;
	
	if(m_iCount == 30)
		m_iCount = 0;
	
	CGPoint pt = [walkman getChasePoint];
	
	float dx = pt.x - walkman.position.x;
	float dy = pt.y - walkman.position.y;
	
	dx=dx/sqrt(dx*dx+dy*dy);
	dy=dy/sqrt(dx*dx+dy*dy);
	if(dx <0)
	{
		[walkman setFlipX:TRUE];
	}
	//rot = rot+10;
	//NSLog(@"%f\n",rot);
	//[walkman setAnchorPoint:CGPointMake(0.25, 0.75)];
	//[walkman setRotation:180];
	[walkman setRotation:atan(dy/dx)*-180/3.14];
	[walkman setPosition:CGPointMake(walkman.position.x+dx, walkman.position.y+dy)];	
}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"MChaseState";
}

@end
