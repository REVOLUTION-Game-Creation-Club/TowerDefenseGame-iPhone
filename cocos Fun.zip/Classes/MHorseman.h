//
//  Horseman.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 11..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MUnit.h"

@class MHorseWaitState;
@class MHorseAttackState;
@class MStateMachine;
@class MState;
@class MHorseChaseState;
@class MHorseProduceState;
@class MHorseMoveState;
@class MLeftSlot;

@interface MHorseman : MUnit 
{
	CCSprite*			m_spriteWait[4];
	CCSprite*			m_spriteMove[4];
	CCSprite*			m_spriteAttack[4];
	CCSprite*			m_spriteDeath[4];

	CCSprite*			m_hpSprite[21];
	
	float				m_fRadius;
	float				m_fSight;
	CGPoint				m_ptChasePoint;
	int					m_iHPMax;
	MStateMachine*		m_stateMachine;
	MHorseWaitState*	m_waitState;
	MHorseAttackState*	m_attackState;
	MHorseChaseState*	m_chaseState;
	MHorseProduceState*	m_produceState;
	MHorseMoveState*	m_moveState;
	
	MLeftSlot*			m_leftSlot;

	MUnit*			m_target;
}

-(id) init;
-(void) update;
-(void) dealloc;

-(void) changeState:(MState*)new_state;
-(BOOL) isInRadius:(CGPoint)pt;
-(BOOL) isInRadiusCastle:(CGPoint)pt;
-(BOOL) isInSight:(CGPoint)pt;

- (void)wait;
- (void)attack;
- (void)chase:(CGPoint)pt;

-(CGPoint) getChasePoint;
-(void) suffer:(int)hp;

-(void) WaitAnimation;
-(void) MoveAnimation;
-(void) AttackAnimation;

-(void) setFlipX:(BOOL)b;

-(void) changeWaitState;

-(void) wait;
-(void) go;
-(void) unvisibleAll;

-(void) dead;
-(MLeftSlot*) getLeftSlot;

-(void) setLeftSlot:(MLeftSlot*)slot;
-(MLeftSlot*) getLeftSlot;

-(NSString*) name;

-(void) setTargetUnit:(MUnit*)pt;
-(MUnit*) getTargetUnit;

@end
