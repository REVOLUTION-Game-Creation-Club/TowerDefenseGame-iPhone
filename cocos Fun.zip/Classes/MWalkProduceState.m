//
//  MProduceState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 14..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MWalkProduceState.h"
#import "MWalkman.h"
#import "MLeftSlot.h"

@implementation MWalkProduceState

- (void)Enter:(id)owner
{
	m_iProduceTime = 0;
	MWalkman *walkman = owner;
	[walkman setPosition:CGPointMake(58,160)];
	[walkman unvisibleAll];
}

- (void)Execute:(id)owner
{
	//
	MWalkman *walkman = owner;
	
	MLeftSlot *left = [walkman getLeftSlot];
	
	m_iProduceTime++;
	
	for(int i = 1; i < 13; i++)
	{
		if(m_iProduceTime <5*i*3)
		{
			[left item1Produce:i];
			break;
		}
	}
	
	if(m_iProduceTime >= 60*3)
	{
		MWalkman *walkman = owner;
		m_iProduceTime = 0;
		[left item1Produce:0];
		[walkman changeWaitState];
		[left produce1Complete];
	}
}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"MWalkProduceState";
}

@end
