//
//  Boss3MoveState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 24..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Boss3MoveState.h"
#import "Boss3.h"

@implementation Boss3MoveState

- (void)Enter:(id)owner
{
	m_iCount = 0;
	Boss3* boss3 = owner;
	[boss3 unvisibleAll];
}

- (void)Execute:(id)owner
{
	Boss3 *boss3 = owner;
	if(m_iCount==0)
	{
		[boss3 MoveAnimation];
	}
	m_iCount++;
	
	if(m_iCount == 30)
		m_iCount = 0;
	//
	
	//CGPoint pt = [sprite getPosition];
	
	float y = boss3.position.y;
	if(boss3.position.y >= (320-boss3.contentSize.height/2))
	{
		y = 320 - boss3.contentSize.height/2;
	}
	
	//[boss3 setFlipX:FALSE];
	
	[boss3 setRotation:0];
	[boss3 setPosition:CGPointMake(boss3.position.x-0.33, y)];
}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"Boss1MoveState";
}

@end
