//
//  MManual.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 15..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface Manual1 : CCLayer <CCTargetedTouchDelegate> 
{
	CCSprite* m_sprite;
}

-(id)init;
- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event;
@end
