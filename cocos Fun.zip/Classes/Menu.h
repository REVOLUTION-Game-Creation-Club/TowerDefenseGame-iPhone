//
//  MenuMain.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 3..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface Menu : CCLayer 
{
	
}

-(void)cbMenu:(id)sender;

@end
