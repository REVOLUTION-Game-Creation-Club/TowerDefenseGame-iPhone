//
//  MTankAttackState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 25..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MTankAttackState.h"
#import "MBackground.h"
#import "MTank.h"
#import "MEWalkman.h"
#import "MBackground.h"

@implementation MTankAttackState

- (id)init
{
	if( (self=[super init] )) 
	{
	}
	
	return self;
}

- (void)Enter:(id)owner
{
	MTank *tank = owner;

	m_arrow = [CCSprite spriteWithFile:@"arrow.png" rect:CGRectMake(0,0,10,1)];
	//MBackground *sBG = [MBackground sharedBG];
	MBackground *bg = [tank getBackground];
	[bg addChild:m_arrow z:3 tag:0];		
	
	
	
	[m_arrow setPosition:CGPointMake(tank.position.x, tank.position.y)];
	m_arrow.visible = TRUE;
	m_iCount = 0;
	[tank unvisibleAll];
}

- (void)Execute:(id)owner
{
	MTank *tank = owner;
	if(m_iCount==0)
	{
		[tank AttackAnimation];
	}
	m_iCount++;
	if(m_iCount == 30)
		m_iCount = 0;
	
	//
	
	CGPoint pt = [tank getTarget];
	
	float dx = pt.x - m_arrow.position.x;
	float dy = pt.y - m_arrow.position.y;
	
	dx = dx / 10;
	dy = dy / 10;
	
	NSLog(@"%f %f \n", dx, dy);
	[m_arrow setPosition:CGPointMake(m_arrow.position.x+dx, m_arrow.position.y+dy)];
	[m_arrow setRotation:atan(dy/dx)*-180/3.14];
	
	[tank setRotation:atan(dy/dx)*-180/3.14];
	
	if((m_arrow.position.x < pt.x+8)&&(m_arrow.position.x > pt.x-8)&&
	   (m_arrow.position.y < pt.y+8)&&(m_arrow.position.y > pt.y-8))
	{
		m_arrow.visible = FALSE;
		[m_arrow setPosition:CGPointMake(tank.position.x, tank.position.y)];
		MUnit *enemy = [tank getTargetUnit];
		if(enemy)
		{
			[enemy suffer:1];
		}
		else 
		{
			[tank go];
		}
		
		[self Enter:owner];
		
//		[tank wait];
	}
}

- (void)Exit:(id)owner
{
	MTank *tank = owner;
	[tank unvisibleAll];
}

- (NSString*)name
{
	return @"MTankAttackState";
}

@end
