//
//  MEHorseman.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 28..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MUnit.h"

@class MStateMachine;
@class MState;
@class MEHorseChaseState;
@class MEHorseWaitState;
@class MEHorseAttackState;
@class MEHorseMoveState;

@interface MEHorseman : MUnit 
{
	CCSprite*			m_spriteWait[5];
	CCSprite*			m_spriteMove[4];
	CCSprite*			m_spriteAttack[7];
	CCSprite*			m_spriteDeath[4];

	CCSprite* m_hpSprite[21];
	float				m_fRadius;
	float				m_fSight;
	CGPoint				m_ptChasePoint;
	int					m_iHPMax;
	MStateMachine*		m_stateMachine;
	MEHorseWaitState*	m_waitState;
	MEHorseAttackState*	m_attackState;
	MEHorseChaseState*	m_chaseState;
	MEHorseMoveState*	m_moveState;
	
	MUnit*			m_target;
}

-(id) init;
-(void) update;
-(void) dealloc;

-(void) changeState:(MState*)new_state;
-(BOOL) isInRadius:(CGPoint)pt;
-(BOOL) isInSight:(CGPoint)pt;

-(void) wait;
-(void) go;
- (void)attack;
- (void)chase:(CGPoint)pt;

-(CGPoint) getChasePoint;
-(void) suffer:(int)hp;

-(void) WaitAnimation;
-(void) MoveAnimation;
-(void) AttackAnimation;
-(void) DeathAnimation;

-(void) setFlipX:(BOOL)b;

-(void) changeWaitState;
-(void) unvisibleAll;

-(void) setTargetUnit:(MUnit*)pt;
-(MUnit*) getTargetUnit;

@end
