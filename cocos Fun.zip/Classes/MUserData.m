//
//  MUserData.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 30..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MUserData.h"


@implementation MUserData

@synthesize m_iBow1Level;
@synthesize m_iBow2Level;
@synthesize m_iBow3Level;
@synthesize m_iBow4Level;
@synthesize m_iBow5Level;

@synthesize m_iSword1Level;
@synthesize m_iSword2Level;
@synthesize m_iSword3Level;
@synthesize m_iSword4Level;
@synthesize m_iSword5Level;

@synthesize m_iShield1Level;
@synthesize m_iShield2Level;
@synthesize m_iShield3Level;
@synthesize m_iShield4Level;
@synthesize m_iShield5Level;

@synthesize m_iCastleLevel;

@synthesize m_iIronNum;
@synthesize m_iWoodNum;

@synthesize m_bWood1;
@synthesize m_bIron1;
@synthesize m_bIron2;
@synthesize m_bIron3;

@synthesize m_bWood1Sold;
@synthesize m_bIron1Sold;
@synthesize m_bIron2Sold;
@synthesize m_bIron3Sold;

@synthesize m_iSkill1Level;
@synthesize m_iSkill2Level;
@synthesize m_iSkill3Level;
@synthesize m_iSkill4Level;
@synthesize m_iSkill5Level;
@synthesize m_iSkill6Level;

@synthesize m_iQuickSlot1;
@synthesize m_iQuickSlot2;
@synthesize m_iQuickSlot3;

@synthesize m_iQuickSlot1Num;
@synthesize m_iQuickSlot2Num;
@synthesize m_iQuickSlot3Num;

@synthesize m_bSoundOn;
@synthesize m_iGameLevel;

@synthesize m_iMoney;

static MUserData* g_sharedUserData = nil;

+ (MUserData*)sharedUserData 
{
	if (!g_sharedUserData)
		g_sharedUserData = [[MUserData alloc] init];
	
	return g_sharedUserData;
}

-(id)init
{
	if((self = [super init]))
	{		
		m_iBow1Level = 0;
		m_iBow2Level = 0;
		m_iBow3Level = 0;
		m_iBow4Level = 0;
		m_iBow5Level = 0;
		
		m_iSword1Level = 0;
		m_iSword2Level = 0;
		m_iSword3Level = 0;
		m_iSword4Level = 0;
		m_iSword5Level = 0;
		
		m_iShield1Level = 0;
		m_iShield2Level = 0;
		m_iShield3Level = 0;
		m_iShield4Level = 0;
		m_iShield5Level = 0;
		
		//item[ITEM_MAX];
		
		m_iCastleLevel = 0;
		
		m_iIronNum = 0;
		m_iWoodNum = 0;
		
		m_bWood1Sold = FALSE;
		m_bIron1Sold = FALSE;
		m_bIron2Sold = FALSE;
		m_bIron3Sold = FALSE;

		m_iQuickSlot1 = 0;
		m_iQuickSlot2 = 0;
		m_iQuickSlot3 = 0;
		
		m_iQuickSlot1Num = 0;
		m_iQuickSlot2Num = 0;
		m_iQuickSlot3Num = 0;
		
		m_iMoney = 10000;

		//self = [NSKeyedUnarchiver unarchiveObjectWithData:freezeDried];
	}
	
	return self;
}

/*
- (void) encodeWithCoder:(NSCoder*)coder
{
	[coder encodeInt:m_iBow1Level forKey:@"m_iBow1Level"];
	[coder encodeInt:m_iBow2Level forKey:@"m_iBow2Level"];
	[coder encodeInt:m_iBow3Level forKey:@"m_iBow3Level"];
	[coder encodeInt:m_iBow4Level forKey:@"m_iBow4Level"];
	[coder encodeInt:m_iBow5Level forKey:@"m_iBow5Level"];
}

- (id) initWithCoder:(NSCoder*)decoder
{
//	if(self = [super init])
	{
		self.m_iBow1Level = [decoder decodeIntForKey:@"m_iBow1Level"];
		self.m_iBow2Level = [decoder decodeIntForKey:@"m_iBow2Level"];
		self.m_iBow3Level = [decoder decodeIntForKey:@"m_iBow3Level"];
		self.m_iBow4Level = [decoder decodeIntForKey:@"m_iBow4Level"];
		self.m_iBow5Level = [decoder decodeIntForKey:@"m_iBow5Level"];
	}
	
	return self;
}

- (id) copyWithZone:(NSZone*)zone
{
	MUserData *copy = [[[self class] allocWithZone: zone] init];
	copy.m_iBow1Level = self.m_iBow1Level;
	copy.m_iBow2Level = self.m_iBow2Level;
	copy.m_iBow3Level = self.m_iBow3Level;
	copy.m_iBow4Level = self.m_iBow4Level;
	copy.m_iBow5Level = self.m_iBow5Level;
	
	return copy;
}
 */

@end
