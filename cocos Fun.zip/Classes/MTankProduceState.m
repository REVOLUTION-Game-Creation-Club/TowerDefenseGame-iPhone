//
//  MTankProduceState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 25..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MTankProduceState.h"
#import "MLeftSlot.h"
#import "MTank.h"


@implementation MTankProduceState

- (void)Enter:(id)owner
{
	m_iProduceTime = 0;
	MTank *tank = owner;
	[tank setPosition:CGPointMake(58,160)];
	[tank unvisibleAll];
}

- (void)Execute:(id)owner
{
	//
	
	MTank *tank = owner;
	MLeftSlot *left = [tank getLeftSlot];
	
	m_iProduceTime++;
	for(int i = 1; i < 13; i++)
	{
		if(m_iProduceTime <5*i*30)
		{
			[left item4Produce:i];
			break;
		}
	}
	if(m_iProduceTime == 60*30)
	{
		MTank *tank = owner;
		m_iProduceTime = 0;
		[left item4Produce:0];
		[tank changeWaitState];
		[left produce4Complete];
	}
}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"MTankProduceState";
}

@end
