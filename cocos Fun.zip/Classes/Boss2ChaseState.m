//
//  Boss2ChaseState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 24..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Boss2ChaseState.h"
#import "Boss2.h"

@implementation Boss2ChaseState

- (void)Enter:(id)owner
{
	//rot = 0;
	m_iCount = 0;
	Boss2 *boss2 = owner;
	[boss2 unvisibleAll];
}

- (void)Execute:(id)owner
{
	Boss2 *boss2 = owner;
	if(m_iCount == 0)
	{
		[boss2 MoveAnimation];
	}
	m_iCount++;
	
	if(m_iCount == 30)
		m_iCount = 0;
	
	CGPoint pt = [boss2 getChasePoint];
	
	float dx = pt.x - boss2.position.x;
	float dy = pt.y - boss2.position.y;
	
	dx=dx/sqrt(dx*dx+dy*dy);
	dy=dy/sqrt(dx*dx+dy*dy);
	if(dx <0)
	{
		[boss2 setFlipX:FALSE];
	}
	//rot = rot+10;
	//NSLog(@"%f\n",rot);
	//[walkman setAnchorPoint:CGPointMake(0.25, 0.75)];
	//[walkman setRotation:180];
	[boss2 setRotation:atan(dy/dx)*-180/3.14];
	[boss2 setPosition:CGPointMake(boss2.position.x+dx, boss2.position.y+dy)];	
}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"Boss2ChaseState";
}

@end
