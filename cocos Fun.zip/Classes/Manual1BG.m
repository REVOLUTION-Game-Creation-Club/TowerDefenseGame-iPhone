//
//  Manual1BG.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 16..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Manual1BG.h"
#import "Manual2.h"
#import "cocos2d.h"

@implementation Manual1BG

- (id)init
{
	if( (self=[super init] )) 
	{
	}
	return self;
}

- (void)onEnter
{
	[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
	[super onEnter];
}

- (void)onExit
{
	[[CCTouchDispatcher sharedDispatcher] removeDelegate:self];
	[super onExit];
}

- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{
	CCScene *s = [CCScene node];
	
	[s addChild:[Manual2 node]];
	[[CCDirector sharedDirector] replaceScene:[CCFlipXTransition transitionWithDuration:1 scene:s]];
	
	return YES;
}

@end
