//
//  MHorseWaitState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 21..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MHorseWaitState.h"
#import "MHorseman.h"
#import "MBackground.h"

@implementation MHorseWaitState

- (void)Enter:(id)owner
{
	m_iCount = 0;	
	MHorseman *horseman = owner;
	switch ([horseman getFormation]) 
	{
		case STYLE_NO:
			x = 100;
			y = rand()%220+50;
			break;
		case STYLE_1:
			x = rand()%50+200;
			y = rand()%160+80;
			break;
		case STYLE_2:
			switch(rand()%3)
			{
				case 0:
					x = rand()%100+200;
					y = rand()%50+90;
					break;
				case 1:
					x = rand()%100+200;
					y = rand()%50+180;
					break;
				case 2:
					x = rand()%60+240;
					y = rand()%40+140;					
					break;
			}
			break;
		case STYLE_3:
			x = rand()%100+280;
			y = rand()%160+80;
			break;
		case STYLE_4:
			x = rand()%50+160;
			y = rand()%240+40;
			break;			
	}	
}

- (void)Execute:(id)owner
{
	MHorseman *horseman = owner;
	if(m_iCount==0)
	{
		[horseman WaitAnimation];
	}
	m_iCount++;

	if(m_iCount == 60)
		m_iCount = 0;
	
	//
	
	MHorseman* sprite = owner;
	
	if(( sprite.position.x > x-1)&&(sprite.position.y < y+1)&&
	   ( sprite.position.x < x+1)&&(sprite.position.y > y-1))
	{
		[sprite setFlipX:FALSE];
		[sprite setRotation:0];
		[sprite setPosition:CGPointMake(x, y)];
	}
	
	else 
	{
		float dx = x - sprite.position.x;
		float dy = y - sprite.position.y;
		
		dx=dx/sqrt(dx*dx+dy*dy);
		dy=dy/sqrt(dx*dx+dy*dy);
/*		if(dx <0)
		{
			[sprite setFlipX:TRUE];
		}
		if(dy <0)
		{
			[sprite setFlipY:TRUE];
		}
*/		
		[sprite setRotation:atan(dy/dx)*-90/3.14];
		[sprite setPosition:CGPointMake(sprite.position.x+dx*1.5, sprite.position.y+dy*1.5)];
	}
	
}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"MHorseWaitState";
}

@end
