//
//  MEBowState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 27..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MEBowMoveState.h"
#import "MEBowman.h"

@implementation MEBowMoveState

- (void)Enter:(id)owner
{
	MEBowman *ebowman = owner;

	m_iCount = 0;
	[ebowman unvisibleAll];
}

- (void)Execute:(id)owner
{
	MEBowman *ebowman = owner;
	if(m_iCount==0)
	{
		[ebowman MoveAnimation];
	}
	m_iCount++;
	
	if(m_iCount == 30)
		m_iCount = 0;
	
	//CGPoint pt = [sprite getPosition];
	MEBowman* sprite = owner;
	
	float y = sprite.position.y;
	if(sprite.position.y >= (320 -sprite.contentSize.height/2))
	{
		y = 320 - sprite.contentSize.height/2;
	}
	
	[sprite setFlipX:TRUE];
	
	
	[sprite setRotation:0];
	[sprite setPosition:CGPointMake(sprite.position.x-0.33, y)];
}

- (void)Exit:(id)owner
{
	MEBowman* ebowman = owner;
	[ebowman unvisibleAll];
}

- (NSString*)name
{
	return @"MMoveState";
}

@end
