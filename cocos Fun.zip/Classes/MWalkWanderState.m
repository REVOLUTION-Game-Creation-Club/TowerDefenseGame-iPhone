//
//  MWanderState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 16..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MWalkWanderState.h"
#import "cocos2d.h"
#import "MWalkman.h"

@implementation MWalkWanderState

- (void)Enter:(id)owner
{
	m_iCount = 0;
	MWalkman *walkman = owner;
	[walkman unvisibleAll];
}

- (void)Execute:(id)owner
{
	MWalkman *walkman = owner;
	if(m_iCount==0)
	{
		[walkman MoveAnimation];
	}
	m_iCount++;
	
	if(m_iCount == 30)
		m_iCount = 0;
	//
	
	float dx = rand()%10;
	float dy = rand()%10;
	float sign = rand()%4;
		
	if(sign == 0)
	{
		dx *= -1;
		dy *= -1;
	}
	else if(sign == 1)
	{
		dx *= -1;
	}
	else if(sign == 2)
	{
		dy *= -1;
	}
		
	dx = dx/sqrt(dx*dx+dy*dy);
	dy = dy/sqrt(dx*dx+dy*dy);		

	
	CCSprite* sprite = owner;
	
	if ((sprite.position.x+dx <= 960-sprite.contentSize.width/2) &&
		(sprite.position.x+dx >= sprite.contentSize.width/2) &&
		(sprite.position.y+dy <= 320-sprite.contentSize.height/2) &&
		(sprite.position.y+dy >= sprite.contentSize.height/2))
	{
		[sprite setPosition:CGPointMake(sprite.position.x+dx,sprite.position.y+dy)];	
	}
}

- (void)Exit:(id)owner
{
	
}

- (NSString*)name
{
	return @"MWanderState";
}

@end
