//
//  MTankMoveState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 28..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MTankMoveState.h"
#import "MTank.h"

@implementation MTankMoveState

- (void)Enter:(id)owner
{
}

- (void)Execute:(id)owner
{
	MTank *tank = owner;
	if(m_iCount==0)
	{
		[tank MoveAnimation];
	}
	m_iCount++;

	if(m_iCount == 30)
		m_iCount = 0;

	//CGPoint pt = [sprite getPosition];
	MTank* sprite = owner;
	
	float y = sprite.position.y;
	if(sprite.position.y >= (320 -sprite.contentSize.height/2))
	{
		y = 320 - sprite.contentSize.height/2;
	}
	
	[sprite setFlipX:FALSE];
	
	
	[sprite setRotation:0];
	[sprite setPosition:CGPointMake(sprite.position.x+0.33, y)];
}

- (void)Exit:(id)owner
{
	MTank* tank = owner;
	[tank unvisibleAll];
}

- (NSString*)name
{
	return @"MMoveState";
}

@end
