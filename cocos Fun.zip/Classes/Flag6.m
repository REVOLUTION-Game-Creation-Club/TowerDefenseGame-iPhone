//
//  Flag6.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 26..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Flag6.h"


@implementation Flag6

-(id) init
{
	if( (self=[super init] )) 
	{
		m_sprite[0] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(0,0,46,53)];
		[self addChild:m_sprite[0] z:0 tag:0];
		m_sprite[0].visible = FALSE;
		m_sprite[1] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(46,0,46,53)];
		[self addChild:m_sprite[1] z:0 tag:0];
		m_sprite[1].visible = FALSE;
		m_sprite[2] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(92,0,46,53)];
		[self addChild:m_sprite[2] z:0 tag:0];
		m_sprite[2].visible = FALSE;
		m_sprite[3] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(138,0,46,53)];
		[self addChild:m_sprite[3] z:0 tag:0];
		m_sprite[3].visible = FALSE;
		m_sprite[4] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(184,0,46,53)];
		[self addChild:m_sprite[4] z:0 tag:0];
		m_sprite[4].visible = FALSE;
		m_sprite[5] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(230,0,46,53)];
		[self addChild:m_sprite[5] z:0 tag:0];
		m_sprite[5].visible = FALSE;
		
		
		m_clear[0] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(276,0,42,53)];
		[self addChild:m_clear[0] z:0 tag:0];
		m_clear[0].visible = FALSE;
		m_clear[1] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(318,0,44,53)];
		[self addChild:m_clear[1] z:0 tag:0];
		m_clear[1].visible = FALSE;
		m_clear[2] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(362,0,42,53)];
		[self addChild:m_clear[2] z:0 tag:0];
		m_clear[2].visible = FALSE;
		m_clear[3] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake(404,0,44,53)];
		[self addChild:m_clear[3] z:0 tag:0];
		m_clear[3].visible = FALSE;
		
		m_bClear = FALSE;
		
		[self schedule:@selector(FlagAnim:) interval:0.5];
	}
	return self;
}

-(void)FlagAnim:(ccTime)dt
{
	if(m_bClear == FALSE)
	{
		[self FlagSelectAnim];
	}
	else 
	{
		[self FlagClearAnim];
	}
}

-(void)setClear:(BOOL)b
{
	[self unVisibleAll];
	m_bClear = b;
}

-(void)unVisibleAll
{
	for(int i = 0; i <6; i++)
	{
		m_sprite[i].visible = FALSE;
	}
	for(int i = 0; i <4; i++)
	{
		m_clear[i].visible = FALSE;
	}
}
-(void)FlagSelectAnim
{
	static int count = 0;
	if(count == 0)
	{
		m_sprite[0].visible = TRUE;
		m_sprite[1].visible = FALSE;
		m_sprite[2].visible = FALSE;
		m_sprite[3].visible = FALSE;
		m_sprite[4].visible = FALSE;
		m_sprite[5].visible = FALSE;
		
		count++;
	}
	else if(count == 1)
	{
		m_sprite[0].visible = FALSE;
		m_sprite[1].visible = TRUE;
		m_sprite[2].visible = FALSE;
		m_sprite[3].visible = FALSE;
		m_sprite[4].visible = FALSE;
		m_sprite[5].visible = FALSE;
		
		count++;
	}
	else if(count == 2)
	{
		m_sprite[0].visible = FALSE;
		m_sprite[1].visible = FALSE;
		m_sprite[2].visible = TRUE;
		m_sprite[3].visible = FALSE;
		m_sprite[4].visible = FALSE;
		m_sprite[5].visible = FALSE;
		count++;
	}
	else if(count == 3)
	{
		m_sprite[0].visible = FALSE;
		m_sprite[1].visible = FALSE;
		m_sprite[2].visible = FALSE;
		m_sprite[3].visible = TRUE;
		m_sprite[4].visible = FALSE;
		m_sprite[5].visible = FALSE;
		count++;
	}
	else if(count == 4)
	{
		m_sprite[0].visible = FALSE;
		m_sprite[1].visible = FALSE;
		m_sprite[2].visible = FALSE;
		m_sprite[3].visible = FALSE;
		m_sprite[4].visible = TRUE;
		m_sprite[5].visible = FALSE;
		count++;
	}
	else if(count == 5)
	{
		m_sprite[0].visible = FALSE;
		m_sprite[1].visible = FALSE;
		m_sprite[2].visible = FALSE;
		m_sprite[3].visible = FALSE;
		m_sprite[4].visible = FALSE;
		m_sprite[5].visible = TRUE;
		count = 0;
	}
}

-(void)FlagClearAnim
{
	static int count = 0;
	if(count == 0)
	{
		m_clear[0].visible = TRUE;
		m_clear[1].visible = FALSE;
		m_clear[2].visible = FALSE;
		m_clear[3].visible = FALSE;
		
		count++;
	}
	else if(count == 1)
	{
		m_clear[0].visible = FALSE;
		m_clear[1].visible = TRUE;
		m_clear[2].visible = FALSE;
		m_clear[3].visible = FALSE;
		
		count++;
	}
	else if(count == 2)
	{
		m_clear[0].visible = FALSE;
		m_clear[1].visible = FALSE;
		m_clear[2].visible = TRUE;
		m_clear[3].visible = FALSE;
		
		count++;
	}
	else if(count == 3)
	{
		m_clear[0].visible = FALSE;
		m_clear[1].visible = FALSE;
		m_clear[2].visible = FALSE;
		m_clear[3].visible = TRUE;
		
		count=0;
	}
}

@end
