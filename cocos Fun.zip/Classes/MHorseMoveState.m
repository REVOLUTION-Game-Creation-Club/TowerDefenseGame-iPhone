//
//  MHorseMoveState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 28..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MHorseMoveState.h"
#import "MHorseman.h"

@implementation MHorseMoveState

- (void)Enter:(id)owner
{
	m_iCount = 0;
}

- (void)Execute:(id)owner
{
	MHorseman *horseman = owner;
	if(m_iCount==0)
	{
		[horseman MoveAnimation];
	}
	m_iCount++;

	if(m_iCount == 30)
		m_iCount = 0;

	//
	
	//CGPoint pt = [sprite getPosition];
	MHorseman* sprite = owner;
	
	float y = sprite.position.y;
	if(sprite.position.y >= (320 -sprite.contentSize.height/2))
	{
		y = 320 - sprite.contentSize.height/2;
	}
	
	[sprite setFlipX:FALSE];
	
	
	[sprite setRotation:0];
	[sprite setPosition:CGPointMake(sprite.position.x+1.0, y)];
}

- (void)Exit:(id)owner
{
	MHorseman* horseman = owner;
	[horseman unvisibleAll];
}

- (NSString*)name
{
	return @"MMoveState";
}

@end
