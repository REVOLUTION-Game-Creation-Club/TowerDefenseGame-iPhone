//
//  Boss4DeathState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 24..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Boss4DeathState.h"
#import "Boss4.h"

@implementation Boss4DeathState

- (void)Enter:(id)owner
{
	m_iCount = 0;
	Boss4 *boss4 = owner;
	[boss4 unvisibleAll];
}

- (void)Execute:(id)owner
{
	Boss4 *boss4 = owner;
	if(m_iCount == 0)
	{
		[boss4 DeathAnimation];
	}
	m_iCount++;
	
	if(m_iCount == 30)
		m_iCount = 0;
}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"Boss1DeathState";
}

@end
