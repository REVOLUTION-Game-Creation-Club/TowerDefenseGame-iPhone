//
//  MTower.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 11..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MUnit.h"

@class MStateMachine;
@class MCastleAttack;
@class MCastleWait;
@class MEWalkman;
@class MBackground;

@interface MCastle : MUnit 
{
	MEWalkman		*m_targetUnit;
	CGPoint		m_ptTarget;
	MStateMachine *m_stateMachine;
	MCastleAttack *m_attackState;
	MCastleWait	*m_waitState;
	
	CCSprite* m_spriteTower;
	CCSprite*			m_hpSprite[21];
	int m_iHPMax;
	float m_fSight;
	
	MBackground* m_background;
}

-(void) suffer:(int)hp;
-(void) setTarget:(CGPoint)pt;
-(CGPoint) getTarget;

-(void) setTargetUnit:(MEWalkman*)unit;
-(MEWalkman*) getTargetUnit;

-(void) update;
-(void) attack;
-(void) wait;
-(BOOL) isInSight:(CGPoint)pt;
-(void) setPositionTower:(CGPoint)pt;

-(void) setBackground:(MBackground*)bg;
-(MBackground*)getBackground;
@end
