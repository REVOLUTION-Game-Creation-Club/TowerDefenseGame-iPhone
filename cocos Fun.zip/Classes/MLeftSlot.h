//
//  GameUI.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 9..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
@class MUnitButton;
@class MUnitButton2;
@class MUnitButton3;
@class MUnitButton4;
@class MUnitButton5;
@class MBackground;
@class MRightSlot;

@interface MLeftSlot : CCSprite <CCTargetedTouchDelegate>
{
	BOOL bFold;
	CCSprite* bar;
	MUnitButton* item;
	MUnitButton2* item2;
	MUnitButton3* item3;
	MUnitButton4* item4;
	MUnitButton5* item5;
	
	MBackground* m_background;
	MRightSlot* m_rightSlot;
}

//+ (MLeftSlot*)sharedLeft;

-(void)initItem;

-(void)item1Produce:(int)percent;
-(void)item2Produce:(int)percent;
-(void)item3Produce:(int)percent;
-(void)item4Produce:(int)percent;
-(void)fold;
-(void) produce1Complete;
-(void) produce2Complete;
-(void) produce3Complete;
-(void) produce4Complete;

-(void) setBackground:(MBackground*)bg;
-(void) setRightSlot:(MRightSlot*)slot;

@end