//
//  untitled.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 7..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MQuickIcon.h"


@implementation MQuickIcon

-(id)init
{
	if( (self=[super init] )) 
	{		
		for(int i = 0; i < 12; i++)
		{
			m_sprite[i] = [CCSprite spriteWithTexture:self.texture rect:CGRectMake((i%2)?0:40,40*(i/2),40,40)];
			m_sprite[i].position = ccp(0,0);
			[self addChild:m_sprite[i] z:0 tag:0];
			m_sprite[i].visible = FALSE;
		}
		sel = -1;
		[self schedule:@selector(render) interval:0.5];
	}
	

	return self;
}

-(void)render
{
	if (sel == -1)
		return;
	
	if(m_sprite[sel*2].visible)
	{
		m_sprite[sel*2].visible = FALSE;
		m_sprite[sel*2+1].visible = TRUE;
	}
	else 
	{
		m_sprite[sel*2].visible = TRUE;
		m_sprite[sel*2+1].visible = FALSE;		
	}

}

-(void)setIcon:(int)n
{
	n--;
	sel = n;
	for(int i = 0; i < 6; i++)
	{
		if(i == n)
		{
			m_sprite[i*2].visible = TRUE;
			m_sprite[i*2+1].visible = TRUE;
		}
		else
		{
			m_sprite[i*2].visible = FALSE;
			m_sprite[i*2+1].visible = FALSE;
		}
	}
}

@end
