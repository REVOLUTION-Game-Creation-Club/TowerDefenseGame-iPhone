//
//  Boss1ChaseState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 24..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Boss1ChaseState.h"
#import "Boss1.h"

@implementation Boss1ChaseState

- (void)Enter:(id)owner
{
	//rot = 0;
	m_iCount = 0;
	Boss1 *boss1 = owner;
	[boss1 unvisibleAll];
}

- (void)Execute:(id)owner
{
	Boss1 *boss1 = owner;
	if(m_iCount == 0)
	{
		[boss1 MoveAnimation];
	}
	m_iCount++;
	
	if(m_iCount == 30)
		m_iCount = 0;
	
	CGPoint pt = [boss1 getChasePoint];
	
	float dx = pt.x - boss1.position.x;
	float dy = pt.y - boss1.position.y;
	
	dx=dx/sqrt(dx*dx+dy*dy);
	dy=dy/sqrt(dx*dx+dy*dy);
	if(dx <0)
	{
		[boss1 setFlipX:FALSE];
	}
	//rot = rot+10;
	//NSLog(@"%f\n",rot);
	//[walkman setAnchorPoint:CGPointMake(0.25, 0.75)];
	//[walkman setRotation:180];
	[boss1 setRotation:atan(dy/dx)*-180/3.14];
	[boss1 setPosition:CGPointMake(boss1.position.x+dx, boss1.position.y+dy)];	
}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"Boss1ChaseState";
}

@end
