//
//  MStageData.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 28..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface MStageData : NSObject
{
	BOOL m_iStage1Clear;
	BOOL m_iStage2Clear;
	BOOL m_iStage3Clear;
	BOOL m_iStage4Clear;
	BOOL m_iStage5Clear;
	BOOL m_iStage6Clear;
	BOOL m_iStage7Clear;	
	
	int m_iStageNum;
}

@property BOOL m_iStage1Clear;
@property BOOL m_iStage2Clear;
@property BOOL m_iStage3Clear;
@property BOOL m_iStage4Clear;
@property BOOL m_iStage5Clear;
@property BOOL m_iStage6Clear;
@property BOOL m_iStage7Clear;

@property int m_iStageNum;

+ (MStageData*)sharedStageData;
-(id)init;

@end
