//
//  EntityManager.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 11..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
@class MBaseEntity;

@interface MEntityManager : NSObject 
{
	//map<int, MBaseEntity> m_EntityMap;
}

- (void) entityManager;
- (void) registerEntity:(MBaseEntity*)entity;
- (MBaseEntity*) getEntityFromID:(int)id1;
- (void) removeEntity:(MBaseEntity*)entity;
- (void) reset;

@end
