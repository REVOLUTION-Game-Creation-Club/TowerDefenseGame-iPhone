//
//  untitled.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 7..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface MQuickIcon : CCSpriteSheet
{
	CCSprite* m_sprite[12];
	int sel;
}

-(id)init;
-(void)setIcon:(int)n;


@end
