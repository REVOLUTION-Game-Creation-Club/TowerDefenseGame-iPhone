//
//  Bowman.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 6. 11..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

//#import <Foundation/Foundation.h>
#import "MUnit.h"

@class MBowWaitState;
@class MStateMachine;
@class MBowAttackState;
@class MState;
@class MEWalkman;
@class MBowProduceState;
@class MBowMoveState;
@class MLeftSlot;
@class MBackground;
@class MLeftSlot;

@interface MBowman : MUnit 
{
	CCSprite*			m_spriteWait[5];
	CCSprite*			m_spriteMove[4];
	CCSprite*			m_spriteAttack[5];
	CCSprite*			m_spriteDeath[4];

	CCSprite*			m_hpSprite[21];

	float				m_fRadius;
	float				m_fSight;
	int					m_iHPMax;
	MStateMachine*		m_stateMachine;
	MBowWaitState*		m_waitState;
	MBowAttackState*	m_attackState;
	MBowProduceState*	m_produceState;
	MBowMoveState*		m_moveState;
	MUnit*			m_target;
	CGPoint				m_ptTarget;
	
	MBackground*		m_background;
	MLeftSlot*			m_leftSlot;
}

-(id) init;
-(void) update;
-(void) dealloc;

-(void) changeState:(MState*)new_state;
-(BOOL) isInRadius:(CGPoint)pt;
-(BOOL) isInSight:(CGPoint)pt;

-(void) setTarget:(CGPoint)pt;
-(CGPoint) getTarget;

-(void)setTargetUnit:(MUnit*)enemy;
- (MUnit*)getTargetUnit;
- (void)wait;
- (void)attack;
-(void) WaitAnimation;
-(void) MoveAnimation;
-(void) AttackAnimation;
-(void) DeathAnimation;

-(void) setFlipX:(BOOL)b;
-(void) unvisibleAll;

-(void) changeWaitState;
-(void) suffer:(int)hp;

-(void) wait;
-(void) go;
-(void)setLeftSlot:(MLeftSlot*)slot;
-(MLeftSlot*) getLeftSlot;

-(void) setBackground:(MBackground*)bg;
-(MBackground*)getBackground;

-(NSString*) name;

@end
