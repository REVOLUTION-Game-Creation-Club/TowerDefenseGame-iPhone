//
//  QuickButton.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 22..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@class MGameMain1;

@interface QuickButton3 : CCSpriteSheet <CCTargetedTouchDelegate> 
{
	CCSprite* m_sprite[6][11];
	int m_selectItem;
	
	MGameMain1 *m_gameMain;

}

- (void)setItem:(int)itemNo;
-(void) produce:(int)percent;
-(void) trigger;
-(void) setGameMain:(MGameMain1*)gm;

@end
