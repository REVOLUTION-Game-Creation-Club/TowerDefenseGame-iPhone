//
//  Boss5AttackState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 24..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Boss5AttackState.h"
#import "Boss5.h"

@implementation Boss5AttackState

- (void)Enter:(id)owner
{
	m_iCount = 0;
	Boss5 *boss5 = owner;
	[boss5 unvisibleAll];
}

- (void)Execute:(id)owner
{
	Boss5 *boss5 = owner;
	if(m_iCount == 0)
	{
		[boss5 AttackAnimation];
	}
	m_iCount++;
	
	if(m_iCount == 30)
	{
		m_iCount = 0;
		MUnit *enemy = [boss5 getTargetUnit];
		if(enemy)
		{
			//[enemy suffer:1];
		}
	}
	
	[boss5 setFlipX:TRUE];
}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"Boss5AttackState";
}

@end
