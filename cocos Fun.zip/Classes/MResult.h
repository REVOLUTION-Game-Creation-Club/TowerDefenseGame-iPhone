//
//  MResult.h
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 26..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@class NextButton;

@interface MResult : CCLayer
{
	CCSprite* m_sprite;
	
	CCLabel *walkmanLabel;
	CCLabel *bowmanLabel;
	CCLabel *horsemanLabel;
	CCLabel *tankLabel;
	CCLabel *castleLabel;

	CCLabel *walkScoreLabel;
	CCLabel *bowScoreLabel;
	CCLabel *horseScoreLabel;
	CCLabel *tankScoreLabel;
	CCLabel *castleScoreLabel;
	
	CCLabel *pointLabel;
	CCLabel *goldLabel;
	CCLabel *totalLabel;
	
	NextButton *nextButton;
}

@property (nonatomic, retain) CCLabel *walkmanLabel;
@property (nonatomic, retain) CCLabel *bowmanLabel;
@property (nonatomic, retain) CCLabel *horsemanLabel;
@property (nonatomic, retain) CCLabel *tankLabel;
@property (nonatomic, retain) CCLabel *castleLabel;

@property (nonatomic, retain) CCLabel *walkScoreLabel;
@property (nonatomic, retain) CCLabel *bowScoreLabel;
@property (nonatomic, retain) CCLabel *horseScoreLabel;
@property (nonatomic, retain) CCLabel *tankScoreLabel;
@property (nonatomic, retain) CCLabel *castleScoreLabel;

@property (nonatomic, retain) CCLabel *pointLabel;
@property (nonatomic, retain) CCLabel *goldLabel;
@property (nonatomic, retain) CCLabel *totalLabel;

-(void) setWalkKillNum:(int)num;
-(void) setBowKillNum:(int)num;
-(void) setHorseKillNum:(int)num;
-(void) setTankKillNum:(int)num;
-(void) setCastleHpNum:(int)num;
-(void) setPointNum:(int)num;
-(void) setGoldNum:(int)num;
-(void) setTotalNum:(int)num;

@end
