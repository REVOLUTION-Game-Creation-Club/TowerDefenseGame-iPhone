//
//  MEWalkMoveState.m
//  cocos Fun
//
//  Created by 신 동인 on 10. 7. 27..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MEWalkMoveState.h"
#import "MEWalkman.h"

@implementation MEWalkMoveState

- (void)Enter:(id)owner
{
	m_iCount = 0;
	MEWalkman* walkman = owner;
	[walkman unvisibleAll];
}

- (void)Execute:(id)owner
{
	MEWalkman *walkman = owner;
	if(m_iCount==0)
	{
		[walkman MoveAnimation];
	}
	m_iCount++;
	
	if(m_iCount == 30)
		m_iCount = 0;
	//
	
	//CGPoint pt = [sprite getPosition];
	
	float y = walkman.position.y;
	if(walkman.position.y >= (320 -walkman.contentSize.height/2))
	{
		y = 320 - walkman.contentSize.height/2;
	}
	
	[walkman setFlipX:TRUE];
	
	
	[walkman setRotation:0];
	[walkman setPosition:CGPointMake(walkman.position.x-0.33, y)];
}

- (void)Exit:(id)owner
{
}

- (NSString*)name
{
	return @"MMoveState";
}

@end
